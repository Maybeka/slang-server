from pathlib import Path
import sys,json,os
from collections import Counter
out=Path(__file__).resolve().parent;sys.path.insert(0,str(out.parent.parent/'source/tests/method_scope'))
from protocol import Client
from fixture import change,position
root=out/'spi';config=root/'.slang/server.json';saved=config.read_bytes();cfg=json.loads(saved);cfg['experimentalMethodScopeOverlay']=True;config.write_text(json.dumps(cfg))
scenario=json.loads((out/'spi-scenario.json').read_text());target=root/scenario['target'];original=target.read_text();uri=target.as_uri();report=[]
try:
    for version,binary in [('before',out/'baseline-counted'),('after',out.parent.parent/'build/bin/slang_server_counted')]:
        log=out/f'uvm-parses-{version}.csv';assert not log.exists();client=Client(binary,root,{'SLANG_SERVER_PARSE_COUNT_LOG':str(log)})
        def counts():
            return Counter(row.split(',')[1] for row in log.read_text().splitlines() if row.split(',')[0]==str(client.process.pid)) if log.exists() else Counter()
        try:
            client.notify('textDocument/didOpen',{'textDocument':{'uri':uri,'version':1,'languageId':'systemverilog','text':original}})
            params={'textDocument':{'uri':uri},'position':position(original,original.index(scenario['query'])+scenario['queryDelta'])}
            assert client.request('textDocument/completion',params)[0]
            client.wait(lambda m:m.get('method')=='textDocument/publishDiagnostics' and m['params'].get('uri')==uri and m['params'].get('version')==1)
            before=counts();rows=[]
            for step in range(1,10):
                text=original.replace(scenario['before'],scenario['after']) if step%2 else original
                assert client.request('textDocument/completion',params,[change(uri,step+1,text)])[0]
                after_query=counts();client.wait(lambda m:m.get('method')=='textDocument/publishDiagnostics' and m['params'].get('uri')==uri and m['params'].get('version')==step+1)
                state=client.state();assert not state['active'] and state['accepted']==0
                delta=after_query-before;assert delta['other']>=1 and delta['mini-shape']==0,delta
                rows.append(dict(step=step,mainParseDelta=dict(delta),decline=state['decline']));before=counts()
            report.append(dict(version=version,rows=rows))
        finally:client.close()
finally:config.write_bytes(saved)
(out/'uvm-counts.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS: real UVM uses main native parses on all nine edits; no mini path')
