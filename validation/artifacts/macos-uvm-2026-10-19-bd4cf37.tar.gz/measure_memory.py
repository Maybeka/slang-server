"""Independent repeated process peak RSS observations; discard latency samples."""
import sys,json,os,tempfile,random,hashlib
from pathlib import Path
out=Path(__file__).resolve().parent;source=out.parent.parent/'source'
sys.path.insert(0,str(source/'tests/method_scope'))
from benchmark import run
from project_benchmark import run as project_run
plan=json.loads((out/'comparison-plan.json').read_text()); rows=[]
cells=[(repetition,classes,method,version,arm) for repetition in range(3) for classes in (5000,10000,'uvm') for method in ('completion','definition') for version in plan['binaries'] for arm in ('native','method')]
random.Random(20261021).shuffle(cells)
assert not (out/'memory-summary.json').exists()
for index,(rep,classes,method,version,arm) in enumerate(cells):
    name=f'memory-{classes}-{method}-{version}-{arm}-{rep}';usage=out/(name+'.json')
    os.environ['SLANG_MEMORY_BINARY']=plan['binaries'][version]['path'];os.environ['SLANG_MEMORY_LOG']=str(usage)
    if classes=='uvm':
        root=out/'spi';config=root/'.slang/server.json';saved=config.read_bytes()
        try:result=project_run(out/'memory-launch.py',root,json.loads((out/'spi-scenario.json').read_text()),arm=='method',method)
        finally:config.write_bytes(saved)
        assert len(result['rows'])==10
    else:
        with tempfile.TemporaryDirectory(prefix=name+'-',dir=out.parent/'tmp') as tmp:
            result=run(out/'memory-launch.py',Path(tmp).resolve(),arm,method,plan['fixtures'][str(classes)])
        assert len(result['rows'])==9 and all(r['outcome']=='success' for r in result['rows'])
    row=dict(repetition=rep,classes=classes,method=method,version=version,arm=arm,**json.loads(usage.read_text()))
    assert row['childExitCode']==0 and row['maximumResidentSetSizeBytes']>0;rows.append(row)
    (out/'memory-summary.json').write_text(json.dumps({'metric':'Darwin os.wait4 child ru_maxrss bytes; per process maximum, not aggregate parent and diagnostic worker, not heap retained at a fixed version','scope':'3 independent observations per scenario/query/version/arm; timings discarded; test status command collected after timing is included in process peak; no population confidence claim','rows':rows},indent=2)+'\n')
    if index%12==11:print(index+1,'/',len(cells),flush=True)
