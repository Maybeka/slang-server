import json,sys,random,hashlib
from pathlib import Path
out=Path(__file__).resolve().parent;source=out.parent.parent/'source'
sys.path.insert(0,str(source/'tests/method_scope'))
from project_benchmark import run
from benchmark import describe
p=json.loads((out/'comparison-plan.json').read_text());scenario=json.loads((out/'spi-scenario.json').read_text());root=out/'spi';config=root/'.slang/server.json';saved=config.read_bytes()
plan=out/'uvm-comparison-plan.json';output=out/'uvm-comparison-results.json'
if sys.argv[1]=='plan':
    assert not plan.exists();rng=random.Random(20261022);cells=[]
    for method in ('completion','definition'):
        for block in range(20):
            arms=[(v,a) for v in p['binaries'] for a in ('native','method')];rng.shuffle(arms)
            cells.extend(dict(method=method,block=block,version=v,arm=a) for v,a in arms)
    plan.write_text(json.dumps({'seed':20261022,'binaries':p['binaries'],'scenario':scenario,'schedule':cells,'driverSha256':hashlib.sha256((source/'tests/method_scope/project_benchmark.py').read_bytes()).hexdigest()},indent=2)+'\n');sys.exit()
plan_data=json.loads(plan.read_text());assert not output.exists();report={'planSha256':hashlib.sha256(plan.read_bytes()).hexdigest(),'runs':[]};output.write_text(json.dumps(report,indent=2)+'\n')
for name,expected in scenario['files'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected
try:
    for index,cell in enumerate(plan_data['schedule']):
        b=plan_data['binaries'][cell['version']];assert hashlib.sha256(Path(b['path']).read_bytes()).hexdigest()==b['sha256']
        r=run(Path(b['path']),root,scenario,cell['arm']=='method',cell['method']);r.update(cell);report['runs'].append(r);output.write_text(json.dumps(report,indent=2)+'\n')
        if index%20==19:print(index+1,'/',len(plan_data['schedule']),flush=True)
    report['summary']={f'{m}/{v}/{a}':{metric:describe([r[metric] for r in selected]) for metric in ('editResponseSumMs','sequenceWithDiagnosticsMs')}|{'steps':{str(s):describe([r['rows'][s]['latencyMs'] for r in selected]) for s in range(10)},'startupThroughFirstResponseMs':describe([r['rows'][0]['startupThroughFirstResponseMs'] for r in selected])} for m in ('completion','definition') for v in p['binaries'] for a in ('native','method') for selected in [[r for r in report['runs'] if (r['method'],r['version'],r['arm'])==(m,v,a)]]}
    output.write_text(json.dumps(report,indent=2)+'\n')
finally:config.write_bytes(saved)
