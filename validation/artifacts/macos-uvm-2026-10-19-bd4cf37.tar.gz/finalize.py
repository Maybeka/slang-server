import json,hashlib,statistics,tarfile,subprocess,platform
from pathlib import Path
out=Path(__file__).resolve().parent;source=out.parent.parent/'source';validation=source/'validation'
def read(name):return json.loads((out/name).read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
manifest=read('spi-manifest.json')
for name,expected in manifest['files'].items():assert sha(out/'spi'/name)==expected,name
identity=read('identity.json');acceptance=read('acceptance.json');synthetic=read('comparison-results.json');uvm=read('uvm-comparison-results.json');memory=read('memory-summary.json');paired=read('paired-analysis.json')
assert len(acceptance)==8 and all(x['exitCode']==0 for x in acceptance)
assert len(synthetic['runs'])==320 and len(uvm['runs'])==160 and len(memory['rows'])==72
assert sha(out.parent.parent/'build/bin/slang-server')==identity['binaries']['slang-server']['sha256']
# Compare complete real-project oracle bodies across arms, repetitions AND versions.
oracles=[read('uvm-baseline-oracle-v2.json'),read('uvm-after-oracle.json')]
for oracle in oracles:assert oracle['oracleEqual'] and len(oracle['runs'])==8
oracle_summaries=[]
for method in ('completion','definition'):
    fingerprints=[]
    for oracle in oracles:
        for run in oracle['runs']:
            if run['method']!=method:continue
            bodies=[{k:r[k] for k in ('result','resolved','diagnostics') if k in r} for r in run['rows']]
            fingerprints.append(hashlib.sha256(json.dumps(bodies,sort_keys=True,separators=(',',':')).encode()).hexdigest())
    assert len(set(fingerprints))==1,(method,fingerprints)
    example=next(r for r in oracles[0]['runs'] if r['method']==method)
    oracle_summaries.append({'method':method,'freshProcesses':len(fingerprints),'versionsEach':10,'orderedBodiesAndAllResolvesSha256':fingerprints[0],'completionItemsPerVersion':[len(r['result']) for r in example['rows']] if method=='completion' else None,'equalAcrossAllArmsAndBothVersions':True})
compact={'scope':'full ordered completion JSON, every resolved item, definition and diagnostics, ten versions, both arms, baseline and product; physical source handles witnessed by bytes; unknown macro handles compared exactly; not a macro freshness certificate','checks':oracle_summaries,'localRawFiles':{name:{'sha256':sha(out/name),'bytes':(out/name).stat().st_size,'published':False} for name in ('uvm-baseline-oracle-v2.json','uvm-after-oracle.json')},'reasonRawNotPublished':'resolved source fragments from a separate local educational project; project sources and response bodies remain local'}
(out/'real-oracle-summary.json').write_text(json.dumps(compact,indent=2)+'\n')
plan=read('uvm-comparison-plan.json');public_plan={k:v for k,v in plan.items() if k!='scenario'};public_plan['scenarioSha256']=sha(out/'spi-scenario.json');public_plan['localOriginalPlanSha256']=sha(out/'uvm-comparison-plan.json');public_plan['externalInputs']='local scenario and original project remain untracked; static source inventory and pinned UVM are described by the report'
(out/'uvm-public-plan.json').write_text(json.dumps(public_plan,indent=2)+'\n')
mem_summary={}
for c in (5000,10000,'uvm'):
    for m in ('completion','definition'):
        for v in ('before','after'):
            for a in ('native','method'):
                selected=[r['maximumResidentSetSizeBytes'] for r in memory['rows'] if (r['classes'],r['method'],r['version'],r['arm'])==(c,m,v,a)]
                assert len(selected)==3
                mem_summary[f'{c}/{m}/{v}/{a}']={'n':3,'medianBytes':statistics.median(selected),'rangeBytes':[min(selected),max(selected)]}
for r in uvm['runs']:
    assert not r['status']['active'] and r['status']['accepted']==0
    assert len(r['rows'])==10 and all(not x['diagnostics'] for x in r['rows'])
for r in synthetic['runs']:assert len(r['rows'])==9 and all(x['outcome']=='success' and not x['diagnostics'] for x in r['rows'])
selected=['identity.json','acceptance.json','ctest.log','pytest.log','transport.log','oracle-10000-final.log','oracle-10000-final.json','counts-10000.json','counts-10000.log','held.json','held.log','real-oracle-summary.json','uvm-counts.json','uvm-counts.log','uvm-parses-before.csv','uvm-parses-after.csv','integrity-before.log','integrity-after.log','comparison-plan.json','comparison-results.json','uvm-public-plan.json','uvm-comparison-results.json','paired-analysis.json','memory-summary.json','static-checks.log','spi-compile-timescale.log','compare_versions.py','uvm_timing_pair.py','measure_memory.py','memory-launch.py','uvm_counts.py','analyze.py','finalize.py']
archive=validation/'artifacts/macos-uvm-2026-10-19-bd4cf37.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as tf:
    for name in selected:tf.add(out/name,arcname=name)
with tarfile.open(archive) as tf:
    for name in selected:assert hashlib.sha256(tf.extractfile(name).read()).hexdigest()==sha(out/name)
report={'schemaVersion':1,'scope':'Mac real UVM fallback measurements plus restricted synthetic method optimization; experimental flags remain default false','identity':identity,'implementation':['Store only resolved fields, not a second CompletionItem and duplicate identity JSON','Immutable contiguous outer DTO vector and sorted method slot indices; accepted edits publish only replacement method DTOs','Reserve exact native item capacity; clear temporary symbol identity index before diagnostic snapshot; no AST or symbol sharing and no freshness check removed'],'acceptance':acceptance,'realProjectOracle':compact,'realUvmParserCounts':read('uvm-counts.json'),'synthetic':{'processes':320,'timedRequests':2880,'observationsPerQueryVersionArmStep':20,'design':'20 complete randomized blocks per size/query; four cells per block (two binaries times two arms); fixed seven include edges with 5000 or 10000 synthetic classes; fresh process per cell; recorded plan before replay','summary':synthetic['summary'],'pairedMeanAnalysis':paired['synthetic']},'realUvm':{'processes':160,'timedRequests':1600,'observationsPerQueryVersionArmStep':20,'design':'20 randomized complete blocks per query; two binaries times two arms; actual full local SPI/APB/AHB lab with pinned official UVM 1.2; no synthetic extra classes or planted certifiable method','summary':uvm['summary'],'pairedMeanAnalysis':paired['uvm'],'overlayAcceptedEdits':0,'decline':'unsupported source-loading flag (--timescale 1ns/1ps); macros/inheritance also remain outside certificate support','interpretation':'all nine edits take native fallback; no real UVM local speedup established; step 9 does not exercise reuse exhaustion', 'observedExperimentalCost':'new-binary completion nine-response paired mean penalty 27.105 ms (exploratory 95% interval 4.504..59.179 ms), with slow outliers retained; definition difference is uncertain. This is an observed enabled-experiment penalty, not proof that the new DTO changes cause it; their accepted path is never reached here','timingDefinitions':'step 0 includes didOpen and first query; startupThroughFirstResponse includes initialize; editResponseSum is steps 1..9; sequenceWithDiagnostics includes initial query and all versioned diagnostic waits; do not compare these directly to synthetic prewarmed first-edit metrics'},'memory':{'metric':memory['metric'],'scope':memory['scope'],'summary':mem_summary},'statisticsLimits':['n20 per timing cell: empirical p95 withheld; no production tail or population guarantee','Paired percentile bootstrap: 10000 resamples of complete blocks, exploratory mean savings; not median/tail confidence and no family-wise adjustment','No core affinity, fixed frequency, dedicated host, OS file-cache flushing or other-app shutdown; no concurrent build/test/memory workloads during recorded latency replays; fresh processes do not imply cold filesystem caches','Darwin wait4 server-child ru_maxrss includes the test status collection; it does not measure the simultaneous server + diagnostic worker + client total; three observations per cell, not retained heap instrumentation','Static server analysis on macOS; no Linux rerun or simulator/GUI editor acceptance','Local UVM lab is educational, not a production design; the restricted synthetic fixture is separate'],'artifact':{'path':str(archive.relative_to(source)),'bytes':archive.stat().st_size,'sha256':sha(archive),'files':{n:{'sha256':sha(out/n),'bytes':(out/n).stat().st_size} for n in selected},'notPublished':['handoff.md','binaries and build objects','real project/UVM source trees','full real-project oracle response bodies']}}
(validation/'macos-uvm-2026-10-19.json').write_text(json.dumps(report,indent=2)+'\n')
print('Wrote report and verified archive',archive.stat().st_size)
for label,data in [('SYNTHETIC',synthetic),('UVM',uvm)]:
    print(label)
    for key,val in data['summary'].items():
        print(key,{k:v for k,v in val.items() if k!='steps'},'first',val['steps'].get('1' if label=='SYNTHETIC' else '0'))
print('MEMORY',mem_summary)
