import json,random,statistics,math
from pathlib import Path
out=Path(__file__).resolve().parent

def contrast(samples,seed):
    rng=random.Random(seed); n=len(samples);point=statistics.mean(samples)
    means=sorted(statistics.mean(rng.choices(samples,k=n)) for _ in range(10000))
    return {'blocks':n,'meanSavingsMs':point,'exploratoryPercentile95IntervalMs':[means[249],means[9749]],'positiveBlocks':sum(x>0 for x in samples),'scope':'complete blocks resampled; exploratory paired mean, not a median or tail confidence interval; no multiplicity correction'}

def synth():
    data=json.loads((out/'comparison-results.json').read_text());groups={}
    for classes in (5000,10000):
        for method in ('completion','definition'):
            r={(x['block'],x['version'],x['arm']):x for x in data['runs'] if x['classes']==classes and x['method']==method}
            for metric in ('interactiveSumMs','sequenceMs','firstMs','acceptedSumMs','fallbackMs'):
                def value(x):
                    if metric=='firstMs':return x['rows'][0]['latencyMs']
                    if metric=='fallbackMs':return x['rows'][8]['latencyMs']
                    if metric=='acceptedSumMs':return sum(y['latencyMs'] for y in x['rows'][1:8])
                    return x[metric]
                contrasts={
                    'afterNativeMinusMethod':[value(r[b,'after','native'])-value(r[b,'after','method']) for b in range(20)],
                    'beforeMethodMinusAfterMethod':[value(r[b,'before','method'])-value(r[b,'after','method']) for b in range(20)],
                    'methodImprovementMinusNativeImprovement':[(value(r[b,'before','method'])-value(r[b,'after','method']))-(value(r[b,'before','native'])-value(r[b,'after','native'])) for b in range(20)]}
                for name,samples in contrasts.items():groups[f'{classes}/{method}/{metric}/{name}']=contrast(samples,20261023)
    return groups

def uvm():
    data=json.loads((out/'uvm-comparison-results.json').read_text());groups={}
    for method in ('completion','definition'):
        r={(x['block'],x['version'],x['arm']):x for x in data['runs'] if x['method']==method}
        for metric in ('editResponseSumMs','sequenceWithDiagnosticsMs'):
            samples=[r[b,'after','native'][metric]-r[b,'after','method'][metric] for b in range(20)]
            groups[f'{method}/{metric}/afterNativeMinusMethod']=contrast(samples,20261024)
    return groups
report={'synthetic':synth(),'uvm':uvm()}
(out/'paired-analysis.json').write_text(json.dumps(report,indent=2)+'\n')
for k,v in report['synthetic'].items():
    if 'interactiveSumMs' in k or 'firstMs/beforeMethod' in k:print(k,v)
print('UVM',report['uvm'])
