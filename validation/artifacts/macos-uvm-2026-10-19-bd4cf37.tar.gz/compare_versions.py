"""Predeclared randomized complete blocks; no concurrent builds during replay."""
import sys,json,random,hashlib,tempfile,time
from pathlib import Path
out=Path(__file__).resolve().parent
source=out.parent.parent/'source'
sys.path.insert(0,str(source/'tests/method_scope'))
from benchmark import run, describe

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
plan_path=out/'comparison-plan.json'; result_path=out/'comparison-results.json'
if sys.argv[1]=='plan':
    assert not plan_path.exists()
    bins={'before':str(out/'baseline-server'),'after':str(out.parent.parent/'build/bin/slang-server')}
    rng=random.Random(20261020);schedule=[]
    for classes in (5000,10000):
        for method in ('completion','definition'):
            for block in range(20):
                cells=[(v,a) for v in bins for a in ('native','method')];rng.shuffle(cells)
                schedule += [dict(classes=classes,method=method,block=block,version=v,arm=a) for v,a in cells]
    plan={'seed':20261020,'scope':'fresh process per cell; 20 randomized complete blocks per size/query; latency before send through complete response body; no p95 at n20','binaries':{k:{'path':v,'sha256':sha(Path(v))} for k,v in bins.items()},'drivers':{str(p.relative_to(source)):sha(p) for p in (source/'tests/method_scope').glob('*.py')},'fixtures':{str(c):json.loads((out.parent/f'release-{c}-plan.json').read_text()) for c in (5000,10000)},'schedule':schedule}
    plan_path.write_text(json.dumps(plan,indent=2)+'\n');print('planned',len(schedule));sys.exit()
plan=json.loads(plan_path.read_text());assert not result_path.exists()
for v,b in plan['binaries'].items():assert sha(Path(b['path']))==b['sha256']
for p,h in plan['drivers'].items():assert sha(source/p)==h
report={'planSha256':sha(plan_path),'runs':[],'startedUnix':time.time()}
result_path.write_text(json.dumps(report,indent=2)+'\n')
for index,cell in enumerate(plan['schedule']):
    with tempfile.TemporaryDirectory(prefix='comparison-',dir=out.parent/'tmp') as tmp:
        result=run(Path(plan['binaries'][cell['version']]['path']),Path(tmp).resolve(),cell['arm'],cell['method'],plan['fixtures'][str(cell['classes'])])
    assert len(result['rows'])==9 and all(r['outcome']=='success' for r in result['rows'])
    report['runs'].append({**cell,**result})
    result_path.write_text(json.dumps(report,indent=2)+'\n')
    if index%20==19:print(index+1,'/',len(plan['schedule']),flush=True)
report['completedUnix']=time.time()
report['summary']={f'{c}/{m}/{v}/{a}':{metric:describe([r[metric] for r in selected]) for metric in ('interactiveSumMs','sequenceMs','coldPreparationMs')}|{'steps':{str(s):describe([r['rows'][s-1]['latencyMs'] for r in selected]) for s in range(1,10)}} for c in (5000,10000) for m in ('completion','definition') for v in plan['binaries'] for a in ('native','method') for selected in [[r for r in report['runs'] if (r['classes'],r['method'],r['version'],r['arm'])==(c,m,v,a)]]}
result_path.write_text(json.dumps(report,indent=2)+'\n')
