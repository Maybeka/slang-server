from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

root = Path('/workspace/slang-clean-ca5eb2e')
out = Path('/workspace/clean-checkout-evidence')
python = '/workspace/slang-python/cpython-3.12.6-linux-x86_64-gnu/bin/python3'
binary = root/'build/bin/slang-server'
assert Path.cwd() == root
assert json.loads((out/'build-resources.json').read_text())['exitCode'] == 0
assert 'CMAKE_HOME_DIRECTORY:INTERNAL='+str(root) in (root/'build/CMakeCache.txt').read_text()
assert '9dfd335' in subprocess.check_output([str(binary),'--version'],text=True)
steps = [
 ('ctest', ['ctest','--test-dir','build','--output-on-failure','--no-tests=error','-j4']),
 ('pytest', [python,'-m','pytest','tests/system','tests/method_scope','--binary',str(binary),'-q']),
 ('transport', ['bash','tests/transport/run-diagnostic-transport-tests.sh']),
 ('oracle', [python,'tests/method_scope/check.py','--binary',str(binary),'--output',str(out/'oracle.json')]),
 ('counts', [python,'tests/method_scope/count.py','--binary',str(root/'build/bin/slang_server_counted'),'--output',str(out/'counts.json')]),
 ('held', [python,'tests/method_scope/held_diagnostics.py','--binary',str(root/'build/bin/diagnostic_test_server'),'--output',str(out/'held.json')]),
 ('ctest-inventory', ['ctest','--test-dir','build','--show-only=json-v1']),
 ('clang-format', ['clang-format','--dry-run','--Werror','src/document/MethodScopeOverlay.cpp','tests/cpp/MethodScopeOverlayTests.cpp']),
 ('ruff-lint', ['ruff','check','tests/method_scope','restoration/checkout-dependencies.py']),
 ('ruff-format', ['ruff','format','--check','tests/method_scope','restoration/checkout-dependencies.py']),
 ('post-build-integrity', ['python3','restoration/prepare-main-sdk.py','--deps-root','/workspace/slang-deps']),
 ('benchmark-plan', [python,'tests/method_scope/benchmark.py','--binary',str(binary),'--plan',str(out/'benchmark-plan.json'),'--output',str(out/'benchmark.json'),'--seed','20261018','--blocks','3','--plan-only']),
 ('benchmark', [python,'tests/method_scope/benchmark.py','--binary',str(binary),'--plan',str(out/'benchmark-plan.json'),'--output',str(out/'benchmark.json')]),
]
results=[]
for name, command in steps:
    start=time.monotonic()
    with (out/(name+'.log')).open('w') as log:
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
    results.append({'name':name,'command':command,'cwd':str(root),'exitCode':result.returncode,'elapsedSeconds':time.monotonic()-start})
    (out/'execution.json').write_text(json.dumps(results,indent=2)+'\n')
    print(name, result.returncode, flush=True)
    if result.returncode:
        sys.exit(result.returncode)
shutil.copyfile(root/'build/CMakeCache.txt',out/'CMakeCache.txt')
identity={'gitHead':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
          'version':subprocess.check_output([str(binary),'--version'],text=True).strip(),
          'binaries':{}}
for name in ('slang-server','slang_server_counted','diagnostic_test_server'):
    p=root/'build/bin'/name
    identity['binaries'][name]={'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(out/'binary-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
(out/'source-state-after.txt').write_text(subprocess.check_output(['git','status','--porcelain=v1'],text=True))
assert (out/'source-state-before.txt').read_text()==(out/'source-state-after.txt').read_text()
print('PASS: all independent clean-checkout acceptance commands',flush=True)
