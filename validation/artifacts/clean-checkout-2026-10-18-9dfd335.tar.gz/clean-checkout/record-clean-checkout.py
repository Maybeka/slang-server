from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

source = Path('/workspace/slang-clean-ca5eb2e')
repo = Path('/workspace/slang-server')
out = Path('/workspace/clean-checkout-evidence')
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def read(name):
    return json.loads((out/name).read_text())

steps = read('execution.json')
assert len(steps) == 13 and all(s['exitCode'] == 0 for s in steps)
build = read('build-resources.json')
assert build['exitCode'] == 0
assert read('no-preexisting-build-objects.json')['objectOrLibraryFilesBeforeBuild'] == 0
assert len(read('ctest-inventory.log')['tests']) == 607
assert '11 passed' in (out/'pytest.log').read_text()
assert 'RESULT 32 passed, 0 failed' in (out/'transport.log').read_text()
assert '100% tests passed' in (out/'ctest.log').read_text()
assert (out/'source-state-before.txt').read_text() == (out/'source-state-after.txt').read_text()
identity = read('binary-identity.json')
assert identity['gitHead'] == '9dfd3359d0bcf9062b12aa0d8cfa60403926fcb0'
bench = read('benchmark.json')
assert len(bench['runs']) == 24
assert sum(len(r['rows']) for r in bench['runs']) == 216
assert all(s['outcome']=='success' for r in bench['runs'] for s in r['rows'])
source_files = {}
for name in subprocess.check_output(['git','-C',str(source),'ls-files'],text=True).splitlines():
    p = source/name
    if p.is_file():
        source_files[name] = {'bytes':p.stat().st_size, 'sha256':sha(p)}
(out/'source-sha256.json').write_text(json.dumps({'commit':identity['gitHead'],'files':source_files},indent=2)+'\n')
for name in ('run-clean-acceptance.py','record-clean-checkout.py'):
    shutil.copyfile(Path(__file__).parent/name, out/name)
shutil.copyfile(repo/'docs/start/building.md',out/'revised-building-guide.md')
files = {p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(out.iterdir()) if p.is_file()}
archive = repo/'validation/artifacts/clean-checkout-2026-10-18-9dfd335.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as tar:
    for name in files:
        tar.add(out/name,arcname='clean-checkout/'+name)
with tarfile.open(archive) as tar:
    for name, expected in files.items():
        data = tar.extractfile('clean-checkout/'+name).read()
        assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256'], name
report = {
    'schema':1,'dateUtc':'2026-10-18','testedCommit':identity['gitHead'],
    'scope':'Actual independent checkout full build and complete documented Linux acceptance; this is not configuration-only evidence.',
    'environment':read('environment.json'), 'pythonEnvironment':read('python-environment.json'),
    'build':build, 'buildPlanIsolation':read('build-plan-isolation.json'),
    'preexistingObjectOrLibraryFiles':0, 'binaryIdentity':identity,
    'sourceTreeUnchangedByBuildAndTests':True,
    'sdkPatchedFilesVerifiedBeforeAndAfter':708, 'offlineDependencyFilesVerifiedBeforeAndAfter':1296,
    'tests':{'ctest':{'registered':607,'passed':607,'includesSdkUnitAndTidy':True},
             'pytest':{'passed':11,'skipped':0,'includesLuaContract':True},
             'transport':{'passed':32,'failed':0},
             'nativeOracle':'PASS full ordered completion JSON, binding changes, declaration/all-reference renames, stale handles and first/middle/last method selection',
             'counts':read('counts.json'),'heldDiagnostics':read('held.json')},
    'performanceRecipeReplay':{'processes':24,'requests':216,'allSuccessful':True,'nPerArmPerStep':6,
        'summary':bench['summary'],'interpretation':'Fresh replay of the documented preregistered synthetic recipe. Reused host/tool/dependency sources are explicitly recorded. Not a production UVM result or a basis to broaden performance claims.'},
    'neovim':read('environment.json')['neovim'],
    'guideCorrections':['Nix is a tool provider and must use the same pinned dependency/full acceptance recipe.',
                        'Upstream compiler support versions are not represented as validation results for this patched fork.'],
    'limits':['Existing compiler/CMake/Ninja/Python runtime and frozen-version Python packages reused.',
              'Four hash-verified FetchContent source directories reused; no previous product objects, libraries or binaries reused.',
              'No fresh uv sync or complete OS/tool installation replay.',
              'No existing Neovim executable, so real headless LSP attach/initialize/query smoke was not executed. Lua API contract passed; interactive LazyVim remains unverified.',
              'GCC 13, Linux arm64, production UVM and Nix environment unverified.',
              'Source pins, patches and retrieval methods provide online recovery; fully offline Git/tool reconstruction is not established.'],
    'execution':steps,
    'artifact':{'path':str(archive.relative_to(repo)),'bytes':archive.stat().st_size,'sha256':sha(archive),'rawFiles':files},
}
(repo/'validation/clean-checkout-2026-10-18.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'commit':identity['gitHead'],'buildElapsedSeconds':build['elapsedSeconds'],
 'ctest':607,'pytest':11,'transport':32,'artifactBytes':archive.stat().st_size,'artifactSha256':sha(archive)},indent=2))
