#include "slang/util/Bag.h"
#include "slang/driver/SourceLoader.h"
slang::Bag makeBag(){return slang::Bag{slang::driver::SourceOptions{}};}
