#!/Users/xn/Documents/Codex/2026-10-19/handoff-md-package-include/source/.venv/bin/python
import json, os, sys
from pathlib import Path
server = '/Users/xn/Documents/Codex/2026-10-19/handoff-md-package-include/build/bin/slang-server'
pid = os.posix_spawn(server, [server, *sys.argv[1:]], os.environ)
_, status, usage = os.wait4(pid, 0)
Path(os.environ["SLANG_MEMORY_LOG"]).write_text(json.dumps({"childExitCode": os.waitstatus_to_exitcode(status), "maximumResidentSetSizeBytes": usage.ru_maxrss, "userCpuSeconds": usage.ru_utime, "systemCpuSeconds": usage.ru_stime}, indent=2) + "\n")
sys.exit(os.waitstatus_to_exitcode(status))
