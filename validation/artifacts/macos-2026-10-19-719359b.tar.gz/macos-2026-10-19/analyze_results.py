"""Paired ABBA/BAAB block bootstrap, never pool different fixture sizes."""
import argparse
import hashlib
import json
import random
import statistics
from pathlib import Path

p = argparse.ArgumentParser(description=__doc__)
p.add_argument("input", type=Path)
p.add_argument("output", type=Path)
p.add_argument("--seed", type=int, default=20261019)
a = p.parse_args()
data = json.loads(a.input.read_text())
assert all(row["outcome"] == "success" for run in data["runs"] for row in run["rows"])
assert len(data["runs"]) == len(data["plan"]["order"])
rng = random.Random(a.seed)
answer = {"inputSha256": hashlib.sha256(a.input.read_bytes()).hexdigest(), "classes": data["plan"]["classes"], "bootstrapSeed": a.seed, "replicates": 10000, "note": "Percentile bootstrap CI for paired mean differences (native minus method), resampling complete balanced blocks; empirical p95 is separate, no tail CI or production guarantee.", "comparisons": {}}
for method in ("completion", "definition"):
    runs = [r for r in data["runs"] if r["method"] == method]
    for metric in ("first", "accepted2to8", "fallback", "interactiveSumMs", "sequenceMs", "coldPreparationMs"):
        def value(run):
            if metric == "first": return run["rows"][0]["latencyMs"]
            if metric == "fallback": return run["rows"][8]["latencyMs"]
            if metric == "accepted2to8": return statistics.mean(row["latencyMs"] for row in run["rows"][1:8])
            return run[metric]
        deltas = []
        for block in sorted({r["block"] for r in runs}):
            means = {}
            for arm in ("native", "method"):
                group = [r for r in runs if r["block"] == block and r["arm"] == arm]
                assert len(group) == 2
                means[arm] = statistics.mean(value(r) for r in group)
            deltas.append(means["native"] - means["method"])
        boot = sorted(statistics.mean(rng.choices(deltas, k=len(deltas))) for _ in range(10000))
        answer["comparisons"][method + "/" + metric] = {"blocks": len(deltas), "samplesPerArm": len(runs)//2, "pairedMeanSavingsMs": statistics.mean(deltas), "bootstrap95PercentCI": [boot[249], boot[9749]], "blocksWithPositiveSavings": sum(d > 0 for d in deltas)}
a.output.write_text(json.dumps(answer, indent=2) + "\n")
