#include "slang/util/Bag.h"
#include "slang/driver/SourceLoader.h"
#include <cstdio>
slang::Bag makeBag();
int main(){auto b=makeBag();auto p=b.get<slang::driver::SourceOptions>();std::printf("size=%zu recognized=%d\n",b.size(),bool(p));return p?0:1;}
