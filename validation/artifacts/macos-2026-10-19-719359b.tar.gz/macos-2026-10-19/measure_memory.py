"""Separate wait4 RSS observations; do not use these response timings."""
import json, os, sys, tempfile
from pathlib import Path
out = Path(__file__).resolve().parent
sys.path.insert(0, str(out.parent / "source/tests/method_scope"))
from benchmark import run
rows = []
for classes in (5000, 10000):
    plan = json.loads((out / f"release-{classes}-plan.json").read_text())
    for method in ("completion", "definition"):
        for arm in ("native", "method"):
            name = f"memory-{classes}-{method}-{arm}"
            usage = out / (name + ".json")
            os.environ["SLANG_MEMORY_LOG"] = str(usage)
            with tempfile.TemporaryDirectory(prefix=name + "-", dir=out / "tmp") as tmp:
                result = run(out / "memory-launch.py", Path(tmp).resolve(), arm, method, plan)
            assert len(result["rows"]) == 9 and all(r["outcome"] == "success" for r in result["rows"])
            row = {"classes": classes, "method": method, "arm": arm, **json.loads(usage.read_text())}
            assert row["childExitCode"] == 0 and row["maximumResidentSetSizeBytes"] > 0
            rows.append(row)
            print(name, row["maximumResidentSetSizeBytes"], flush=True)
(out / "memory-summary.json").write_text(json.dumps({"metric": "Darwin os.wait4 child ru_maxrss in bytes; not simultaneous aggregate parent/worker/client RSS", "scope": "one separate observation per fixture/query/arm, no confidence claim; response timings from these wrapper runs are discarded", "rows": rows}, indent=2) + "\n")
