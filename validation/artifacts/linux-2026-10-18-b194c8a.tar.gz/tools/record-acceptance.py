from pathlib import Path
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys

root = Path('/workspace/slang-server')
out = Path('/workspace/rebuild-evidence')
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*args):
    return subprocess.check_output(['git', '-C', str(root), *args], text=True).strip()

commit = git('rev-parse', 'HEAD')
source = {}
for name in git('ls-files').splitlines():
    p = root / name
    if p.is_file():
        source[name] = {'bytes': p.stat().st_size, 'sha256': sha(p)}
(out/'acceptance-source-sha256.json').write_text(json.dumps({'commit': commit, 'files': source}, indent=2)+'\n')
shutil.copyfile(root/'build/CMakeCache.txt', out/'acceptance-CMakeCache.txt')
info = {
    'testedProductCommit': commit,
    'baseline': '1f05b9efe29b7d856d8bf703b40b3229ebd6ef43',
    'platform': platform.platform(),
    'machine': platform.machine(),
    'python': sys.version,
    'compiler': subprocess.check_output(['/usr/bin/g++-14', '--version'], text=True).splitlines()[0],
    'cmake': subprocess.check_output(['/workspace/slang-tools/bin/cmake', '--version'], text=True).splitlines()[0],
    'ninja': subprocess.check_output(['/workspace/slang-tools/bin/ninja', '--version'], text=True).strip(),
    'binaryVersion': subprocess.check_output([str(root/'build/bin/slang-server'), '--version'], text=True).strip(),
    'submodules': git('submodule', 'status').splitlines(),
    'workingTree': git('status', '--porcelain=v1'),
    'binaries': {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in
                 [root/'build/bin'/name for name in ('slang-server', 'slang_server_counted', 'diagnostic_test_server')]},
    'cgroup': {p: Path(p).read_text().strip() for p in
               ('/sys/fs/cgroup/cpu.max', '/sys/fs/cgroup/memory.max') if Path(p).is_file()},
    'cleanCheckout': {
        'commit': 'ca5eb2e', 'isolatedSourceCheckout': True,
        'sdk708AndDependencies1296Verified': True, 'cmakeConfigurationPassed': True,
        'fullBuildInThatDirectory': False,
        'notes': 'Initial local reflect-cpp history clone failed on a missing object; a fresh public upstream clone at the exact gitlink succeeded. SDK patch was applied to a pristine independent SDK checkout. Test runtime and pinned dependency directories were reused; uv sync was not repeated.'
    },
    'editor': {'luaContractPassed': True, 'actualNeovimOrLazyVimSession': False},
}
(out/'acceptance-build-info.json').write_text(json.dumps(info, indent=2)+'\n')
inventory = json.loads((out/'acceptance-ctest-inventory.json').read_text())
assert len(inventory['tests']) == 607
assert not (out/'acceptance-normal-instrumentation.txt').read_text()
assert '__wrap_' in (out/'acceptance-counted-instrumentation.txt').read_text()
bench = json.loads((out/'acceptance-benchmark.json').read_text())
assert len(bench['runs']) == 24
assert sum(len(run['rows']) for run in bench['runs']) == 216
assert all(row['outcome']=='success' for run in bench['runs'] for row in run['rows'])
files = sorted(out.glob('acceptance-*')) + [out/'clean-checkout-configure.log', out/'multi-include-cpp-final.log']
report = {
    'schema': 1, 'dateUtc': '2026-10-18', 'testedProductCommit': commit,
    'baseline': info['baseline'], 'platform': info['platform'],
    'compiler': info['compiler'], 'python': '3.12.6', 'buildType': 'Release', 'mimalloc': False,
    'sdkBase': '151a801ceaf6faf23d79a42d210ff67e50eb4660',
    'sdkPatchSha256': sha(root/'restoration/slang.patch'),
    'sdkVerifiedFiles': 708, 'offlineDependencyVerifiedFiles': 1296,
    'dependencies': {d['name']: d['commit'] for d in json.loads((root/'restoration/offline-dependencies.json').read_text())['dependencies']},
    'tests': {'ctest': {'registered': 607, 'passed': 607, 'includesSdkUnitAndTidy': True},
              'pytest': {'passed': 11, 'skipped': 0}, 'transport': {'passed': 32, 'failed': 0},
              'targetedMethodCpp': {'cases': 9, 'assertions': 295},
              'nativeOracle': 'PASS full ordered JSON, nine-version binding changes, two local declaration/all-reference renames with stale handles, earlier/combine/later method edits',
              'parserCounts': json.loads((out/'acceptance-counts.json').read_text()),
              'heldDiagnostics': json.loads((out/'acceptance-held.json').read_text()),
              'staticChecks': 'clang-format 20.1.8 dry run, ruff 0.13.0 lint and format check passed'},
    'binaries': info['binaries'], 'normalBinaryHasParserInstrumentation': False,
    'performance': {
        'workload': bench['plan']['workload'], 'freshProcesses': 24, 'samplesPerArmPerStep': 6,
        'requests': 216, 'allOutcomesSuccessful': True, 'seed': bench['plan']['seed'],
        'metric': bench['plan']['metric'], 'summary': bench['summary'],
        'interpretation': 'In this synthetic class/package/multi-include fixture, accepted edits 2-8 have lower overlay medians; first certification and ninth native fallback are slower. Whole-sequence measurements include diagnostics and do not consistently improve. Small n, not UVM or a historical F1/F2 replica; no general performance claim.',
    },
    'defaults': {'experimentalMethodScopeOverlay': False, 'fastCwdSnapshotChecks': False},
    'cleanCheckout': info['cleanCheckout'], 'editor': info['editor'],
    'limits': ['No production UVM execution', 'GCC 13 not available / untested', 'Linux arm64 untested',
               'No interactive Neovim/LazyVim session', 'Variable-length edits and new/deleted locals remain native fallback'],
    'rawEvidence': {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in files},
}
(root/'validation/linux-2026-10-18.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({'commit': commit, 'rootFiles':len(source), 'rawEvidenceFiles':len(files), 'ctest':607, 'performanceRequests':216}))
