from pathlib import Path
import json,sys
p=Path(__file__).resolve().parent;root=p.parent.parent;sys.path.insert(0,str(root/'source/tests/method_scope'));from protocol import Client
folder=p/'synthetic';folder.mkdir(exist_ok=True);(folder/'.slang').mkdir(exist_ok=True)
text='''package p;
virtual class ancestor;
 int aaa_base;
 extern function int base_ext(int x);
 function int base_inline(); return 1; endfunction
 pure virtual task base_pure();
endclass
class middle extends ancestor;
 int bbb_middle;
 task base_pure(); endtask
endclass
class child extends middle;
 int zzz_local;
 extern function int local_ext(int x);
 function int local_inline(); return 2; endfunction
endclass
function int ancestor::base_ext(int x); return x; endfunction
function int child::local_ext(int x); return x; endfunction
endpackage
module top;
 p::child obj;
 initial begin obj.; end
endmodule
''';file=folder/'test.sv';file.write_text(text);uri=file.as_uri();idx=text.index('obj.;')+4;pos=dict(line=text.count('\n',0,idx),character=idx-text.rfind('\n',0,idx)-1)
results=[]
for arm,binary,prefix in [('native-original',root/'build/bin/slang-server',False),('current-off',root/'build-uvm/bin/slang-server',False),('current-on',root/'build-uvm/bin/slang-server',True)]:
 (folder/'.slang/server.json').write_text(json.dumps(dict(experimentalUvmPrefixCache=prefix,experimentalMethodScopeOverlay=False,fastCwdSnapshotChecks=False)))
 c=Client(binary,folder)
 try:
  c.notify('textDocument/didOpen',dict(textDocument=dict(uri=uri,version=1,languageId='systemverilog',text=text)))
  items=c.request('textDocument/completion',dict(textDocument=dict(uri=uri),position=pos,context=dict(triggerKind=2,triggerCharacter='.')))[0];items=items.get('items',[]) if isinstance(items,dict) else items
  summaries=[]
  for item in items:
   if item['label'] not in ['aaa_base','bbb_middle','zzz_local','base_ext','base_inline','base_pure','local_ext','local_inline']:continue
   resolved=c.request('completionItem/resolve',item)[0]
   summaries.append(dict(label=item['label'],kind=item.get('kind'),sortText=item.get('sortText'),detail=item.get('labelDetails'),insertText=item.get('insertText'),resolvedKind=resolved.get('kind'),resolvedInsertText=resolved.get('insertText'),data=item.get('data')))
  results.append(dict(arm=arm,items=summaries));print(arm,json.dumps(summaries),flush=True)
 finally:c.close()
(p/'after-first-two.json').write_text(json.dumps(results,indent=2)+'\n')
