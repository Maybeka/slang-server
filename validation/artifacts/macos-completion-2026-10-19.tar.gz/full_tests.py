from pathlib import Path
import subprocess,sys,os,json,time
p=Path(__file__).resolve().parent;r=p.parent.parent;s=r/'source';b=r/'build-uvm';tmp=p/'tmp';tmp.mkdir(exist_ok=True);rows=[]
for name,args,cwd in [('ctest',['/opt/homebrew/bin/ctest','--test-dir',str(b),'--output-on-failure','--no-tests=error','-j2'],s),('sdk',[str(b/'bin/unittests')],b/'external/slang/tests/unittests'),('python',[sys.executable,'-m','pytest','tests/system','tests/method_scope','--binary',str(b/'bin/slang-server'),'-q'],s)]:
 t=time.monotonic()
 with (p/(name+'.log')).open('w') as f:x=subprocess.run(args,cwd=cwd,env=dict(os.environ,TMPDIR=str(tmp)),stdout=f,stderr=subprocess.STDOUT)
 rows.append(dict(name=name,command=args,returncode=x.returncode,seconds=time.monotonic()-t));(p/'full-tests.json').write_text(json.dumps(rows,indent=2)+'\n');print(rows[-1],flush=True)
 if x.returncode:sys.exit(x.returncode)
