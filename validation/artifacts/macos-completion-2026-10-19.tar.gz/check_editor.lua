vim.cmd.edit(vim.fn.argv(0))
vim.defer_fn(function()
  local ok, err = pcall(function()
    assert(vim.wait(15000, function()
      for _, c in ipairs(vim.lsp.get_clients({bufnr=0,name="slang_server"})) do
        if c.initialized then return true end
      end
      return false
    end, 50), "slang_server did not attach")
    local clients = vim.lsp.get_clients({bufnr=0,name="slang_server"})
    assert(#clients == 1 and clients[1].config.cmd[1] == vim.env.SLANG_SERVER_FORK_BIN)
    assert(clients[1].config.root_dir == vim.fn.getcwd())
    require("lazy").load({plugins={"nvim-cmp"}})
    local rank = require("cmp").get_config().sorting.comparators[1]
    assert(rank({completion_item={sortText="slang-member:0000000000:z"}},
                {completion_item={sortText="slang-member:0000000002:a"}}) == true,
                "class inheritance comparator did not load")
    print(vim.json.encode({outcome="passed",binary=clients[1].config.cmd[1],
                         root=clients[1].config.root_dir,classComparator=true}))
  end)
  if ok then vim.cmd("qa!") else print(tostring(err));vim.cmd("cquit 1") end
end, 500)
