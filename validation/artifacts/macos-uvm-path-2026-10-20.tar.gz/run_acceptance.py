from pathlib import Path
import json, os, subprocess, sys, time
p=Path(__file__).resolve().parent
r=p.parent.parent;s=r/'source';b=r/'build-uvm'
tmp=p/'tmp';tmp.mkdir(exist_ok=True)
env=dict(os.environ,TMPDIR=str(tmp.resolve()))
commands=[('ctest',['/opt/homebrew/bin/ctest','--test-dir',str(b),'--output-on-failure','--no-tests=error','-j2']),('python',[sys.executable,'-m','pytest','tests/system','tests/method_scope','--binary',str(b/'bin/slang-server'),'-q']),('transport',['tests/transport/run-diagnostic-transport-tests.sh'])]
rows=[]
for name,cmd in commands:
 start=time.monotonic()
 with (p/(name+'-final.log')).open('w') as out:result=subprocess.run(cmd,cwd=s,env=env,stdout=out,stderr=subprocess.STDOUT)
 rows.append(dict(name=name,returncode=result.returncode,seconds=time.monotonic()-start,command=cmd));(p/'acceptance.json').write_text(json.dumps(rows,indent=2)+'\n');print(rows[-1],flush=True)
 if result.returncode:sys.exit(result.returncode)
