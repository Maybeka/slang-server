from pathlib import Path
import os,json,subprocess,resource
soft,hard=resource.getrlimit(resource.RLIMIT_NOFILE)
resource.setrlimit(resource.RLIMIT_NOFILE,(max(soft,min(4096,hard)) if hard!=resource.RLIM_INFINITY else max(soft,4096),hard))
p=Path(__file__).resolve().parent;r=p.parent.parent
smoke=r/'untracked/lazyvim-smoke-2026-10-19'
env=dict(os.environ,XDG_CONFIG_HOME=str(smoke/'config'),XDG_STATE_HOME=str(p/'editor-state'),XDG_CACHE_HOME=str(p/'editor-cache'),SLANG_SERVER_FORK_BIN=str(p/'slang-server-uvm-path'))
rows=[]
for name,project,target,entry in [('spi','spi-block','agents/spi_agent/spi_seq_item.svh','uvm_pkg.sv'),('pss','spi-pss','env/pss_env.svh','uvm_pkg.sv'),('ubus','official-ubus','sv/ubus_master_driver.sv','uvm.sv')]:
 root=p/'real/projects'/project;cfg=root/'.slang/server.json';original=cfg.read_bytes();v=json.loads(original);v.update(uvm=dict(sourceDirectory='uvm',entryFile=entry),experimentalUvmPrefixCache=True);cfg.write_text(json.dumps(v))
 try:
  with (p/f'editor-{name}.log').open('w') as out:
   result=subprocess.run(['/opt/homebrew/bin/nvim','--headless',target,'-c','luafile '+str(r/'untracked/completion-members-2026-10-19/check_editor.lua')],cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=40)
  text=(p/f'editor-{name}.log').read_text();assert 'EMFILE' not in text and 'Lua callback:' not in text,(name,text);assert result.returncode==0 and '"outcome":"passed"' in text,(name,text)
  rows.append(dict(project=name,passed=True));print(rows[-1],flush=True)
 finally:cfg.write_bytes(original)
(p/'editor-checks.json').write_text(json.dumps(rows,indent=2)+'\n')
