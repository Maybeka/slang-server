from pathlib import Path
import subprocess,hashlib,json,tarfile,io
p=Path(__file__).resolve().parent;s=p.parent.parent/'source';sdk=s/'external/slang';r=s/'restoration';m=json.loads((r/'main-sdk.json').read_text());base=m['base_commit'];sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
added=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=sdk,text=True).splitlines();assert set(added)=={'include/slang/util/CwdCoordinator.h','source/util/CwdCoordinator.cpp','tests/unittests/SourceSnapshotTests.cpp','tests/unittests/ast/PackageAnalysisTests.cpp'}
patch=subprocess.check_output(['git','diff','--binary','--full-index',base,'--'],cwd=sdk)
for name in added:
 result=subprocess.run(['git','diff','--no-index','--binary','--full-index','--','/dev/null',name],cwd=sdk,stdout=subprocess.PIPE);assert result.returncode==1;patch+=result.stdout
(r/'slang.patch').write_bytes(patch);m['patch_sha256']=sha(r/'slang.patch')
for name in m['files']:m['files'][name]=sha(sdk/name)
(r/'main-sdk.json').write_text(json.dumps(m,indent=2)+'\n')
fresh=p/'sdk-restore-check';fresh.mkdir();data=subprocess.check_output(['git','archive',base],cwd=sdk)
with tarfile.open(fileobj=io.BytesIO(data)) as t:t.extractall(fresh,filter='data')
(fresh/'.git_archival.txt').write_bytes(subprocess.check_output(['git','show',base+':.git_archival.txt'],cwd=sdk))
for args in [['git','apply','--check',str(r/'slang.patch')],['git','apply',str(r/'slang.patch')]]:subprocess.run(args,cwd=fresh,check=True)
for name,h in m['files'].items():assert sha(fresh/name)==h,name
(p/'sdk-restoration.json').write_text(json.dumps(dict(base=base,patchSha256=m['patch_sha256'],filesVerified=len(m['files']),preservedAddedFiles=added),indent=2)+'\n');print('Fresh restore verified',len(m['files']),'files')
