from pathlib import Path
import json,hashlib,tarfile,subprocess
p=Path(__file__).resolve().parent;s=p.parent.parent/'source';v=s/'validation';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
load=lambda name:json.loads((p/name).read_text())
checks=load('acceptance.json');pairs=load('real-oracles.json');entries=load('entry-oracles.json');forced=load('forced-oracles.json');editors=load('editor-checks.json')
assert len(checks)==3 and all(x['returncode']==0 for x in checks)
assert len(pairs)==28 and all(x['equal'] and x['staleEqual'] for x in pairs)
assert len(entries)==14 and all(x['equal'] and x['staleEqual'] for x in entries)
assert len(forced)==3 and all(x['equal'] and x['staleEqual'] and x['retirements']>0 for x in forced)
assert len(editors)==3 and all(x['passed'] for x in editors)
names=['run_acceptance.py','real_oracles.py','entry_oracles.py','forced_oracles.py','run_editor.py','refresh_sdk.py','publish.py','acceptance.json','ctest-final.log','python-final.log','transport-final.log','focused-watch.log','real-oracles.json','entry-oracles.json','forced-oracles.json','reuse-traces.json','real-oracles.log','entry-oracles.log','forced-oracles.log','sdk-restoration.json','editor-checks.json','editor-spi.log','editor-pss.log','editor-ubus.log','forced-W01-compare.tsv','forced-W07-pss-multidoc.tsv','forced-W08-ubus-task.tsv','format.log','format-existing.log']
manifest={name:sha(p/name) for name in names};(p/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=v/'artifacts/macos-uvm-path-2026-10-20.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name in names+['evidence-manifest.json']:tar.add(p/name,arcname=name)
files=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=s,text=True).splitlines()+['src/UvmLibrary.cpp','tests/cpp/UvmLibraryTests.cpp']
files=[n for n in files if (s/n).is_file() and not n.startswith('validation/')]
report=dict(milestone='Phase 1: explicit UVM source selection and compatible preparation',overallGoal='active; generic frozen regions, hover modes, bundled-library decision and integrated performance remain',date='2026-10-20',platform='macOS arm64',baseline='f79fdb98515207efae5975729b5da55883eb6c86',binarySha256=sha(p/'slang-server-uvm-path'),sourceHashes={n:sha(s/n) for n in files},focused=dict(cases=9,assertions=314,passed=True),ctest=[632,632],python=[15,15],transport=[43,43],checks=checks,realProcesses=106,realPairs=pairs,entryComparisons=entries,forcedRetirementComparisons=forced,reuseTraces=load('reuse-traces.json'),headlessEditor=editors,sdkRestoration=load('sdk-restoration.json'),newPerformanceClaim=False,experimentsDefaultOff=True,limitations=['Known native W12 UTF-16 case excluded; negotiated UTF-8 and CRLF included','Only outer diagnostic order normalized; duplicates and ordered relatedInformation preserved','Syntax/macro checkpoint reuse, not semantic or portable disk cache','Configured wrapper or nonprefix roots can decline reuse; original source order retained','Injection may parse initial inputs before adding missing entry; no new latency/memory claim','Private scripts depend on preserved workload/oracle helpers; sources and binaries excluded from archive'],evidence=dict(archive=str(archive.relative_to(v)),bytes=archive.stat().st_size,sha256=sha(archive),manifest=manifest))
(v/'macos-uvm-path-2026-10-20.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(archiveBytes=archive.stat().st_size,binarySha256=report['binarySha256'])))
