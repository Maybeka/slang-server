from pathlib import Path
import json,sys,copy,hashlib
p=Path(__file__).resolve().parent;root=p.parent.parent;dest=p/'real'
sys.path.insert(0,str(root/'untracked/uvm-prefix-prototype-2026-10-19/v5'));import oracle as o
o.p=dest;o.e.out=dest;Parent=o.OracleClient;current={};summary=[];binary=p/'slang-server-uvm-path'
class Client(Parent):
 def __init__(self,*args,**kwargs):
  f=args[1]/'.slang/server.json';cfg=json.loads(f.read_text());cfg['experimentalUvmPrefixCache']=current['cache'];cfg['fastCwdSnapshotChecks']=False
  if current['mode']!='native':cfg['uvm']={'sourceDirectory':'uvm'}
  if current['mode'] in ['explicit','injected']:cfg['uvm']['entryFile']=current['entry']
  f.write_text(json.dumps(cfg))
  if current['cache']:
   env=kwargs.get('extra_env',{}).copy();env.update(SLANG_UVM_GENERATION_EDIT_LIMIT='1',SLANG_UVM_GENERATION_TRACE=str(p/('forced-'+case['id']+'.tsv')));kwargs['extra_env']=env
  super().__init__(*args,**kwargs)
o.OracleClient=Client
def comparable(value):
 rows=o.comparable(value)
 for row in rows:row['diagnostics']=sorted(row['diagnostics'],key=lambda d:json.dumps(d,sort_keys=True))
 return rows
for case in o.e.CASES.values():
 if case['id'] not in ['W01-compare','W07-pss-multidoc','W08-ubus-task']:continue
 filelist=dest/o.e.PROJECTS[case['project']]['root']/'design.f';original=filelist.read_text();entry=next(x.strip().split('/',1)[1] for x in original.splitlines() if x.startswith('uvm/'))
 modes=[('native',False),('explicit',True)]
 
 runs=[]
 try:
  for mode,cache in modes:
   current.update(mode=mode,cache=cache,entry=entry)
   filelist.write_text(''.join(x for x in original.splitlines(keepends=True) if not x.startswith('uvm/')) if mode=='injected' else original)
   result=o.run(case,binary,cache,False);assert result['outcome']=='success',(case['id'],mode,result.get('error'))
   if runs:
    assert comparable(runs[0])==comparable(result),(case['id'],mode,'public differs')
    assert o.public(runs[0]['staleResolves'])==o.public(result['staleResolves']),(case['id'],mode,'stale differs')
   runs.append(result)
 finally:filelist.write_text(original)
 row=dict(case=case['id'],modes=[dict(mode=m,cache=c) for m,c in modes],equal=True,staleEqual=True,states=len(runs[0]['rows']),resolvedItems=sum(len(x['resolved']) for x in runs[0]['rows']))
 trace=(p/('forced-'+case['id']+'.tsv')).read_text();assert '\tretired\t' in trace;row['retirements']=sum('\tretired\t' in x for x in trace.splitlines());summary.append(row);(p/'forced-oracles.json').write_text(json.dumps(summary,indent=2)+'\n');print(row,flush=True)
print('Forced oracles complete',sum(len(x['modes']) for x in summary),'processes',flush=True)
