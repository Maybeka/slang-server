from pathlib import Path
import json,sys,copy,hashlib,shutil
p=Path(__file__).resolve().parent;root=p.parent.parent;old=root/'untracked/uvm-engineering-2026-10-19';dest=p/'real';dest.mkdir(exist_ok=True)
for project in json.loads((old/'projects.json').read_text()):
 d=dest/project['root'];d.mkdir(parents=True,exist_ok=True)
 for name,h in project['files'].items():
  f=old/project['root']/name;assert hashlib.sha256(f.read_bytes()).hexdigest()==h;g=d/name;g.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,g)
 (d/'.slang').mkdir(exist_ok=True);(d/'.slang/server.json').write_text(json.dumps(project['config']))
sys.path.insert(0,str(root/'untracked/uvm-prefix-prototype-2026-10-19/v5'));import oracle as o
o.p=dest;o.e.out=dest;Parent=o.OracleClient;current={};summary=[];binary=p/'slang-server-freshness'
class Client(Parent):
 def __init__(self,*args,**kwargs):
  f=args[1]/'.slang/server.json';cfg=json.loads(f.read_text());cfg['experimentalUvmPrefixCache']=current['cache'];cfg['fastCwdSnapshotChecks']=False
  if current['suppress']:cfg['flags']+=' --suppress-macro-warnings '+str(args[1]/'uvm/**')
  f.write_text(json.dumps(cfg));super().__init__(*args,**kwargs)
o.OracleClient=Client
def comparable(value):
 rows=o.comparable(value)
 for row in rows:row['diagnostics']=sorted(row['diagnostics'],key=lambda d:json.dumps(d,sort_keys=True))
 return rows
for case in o.e.CASES.values():
 if case['id']=='W12-encoding-lines':continue
 for suppress in [False,True]:
  runs=[]
  for cache in [False,True]:
   current.update(cache=cache,suppress=suppress);r=o.run(case,binary,cache,False);assert r['outcome']=='success',(case['id'],current,r.get('error'))
   for row in r['rows']:
    ranked=[i for i in row['completion'] if i.get('sortText','').startswith('slang-member:')];assert [i['sortText'] for i in ranked]==sorted(i['sortText'] for i in ranked)
    for item in ranked:
     if item['label'] in ['do_compare','do_copy','do_print','get_name','get_full_name','convert2string']:assert item['kind']==2,item
   runs.append(r)
  assert comparable(runs[0])==comparable(runs[1]),(case['id'],suppress,'off/on outputs differ')
  assert o.public(runs[0]['staleResolves'])==o.public(runs[1]['staleResolves']),(case['id'],suppress,'stale outputs differ')
  entry=dict(case=case['id'],suppress=suppress,equal=True,staleEqual=True,states=len(runs[0]['rows']),resolvedItems=sum(len(x['resolved']) for x in runs[0]['rows']),warningCounts=[sum(d['severity']==2 for d in x['diagnostics']) for x in runs[0]['rows']],errorCounts=[sum(d['severity']==1 for d in x['diagnostics']) for x in runs[0]['rows']],publicSha256=hashlib.sha256(json.dumps(comparable(runs[0]),sort_keys=True).encode()).hexdigest());summary.append(entry);(p/'real-oracles.json').write_text(json.dumps(summary,indent=2)+'\n');print(entry,flush=True)
print('Real oracles complete',len(summary)*2,'processes',flush=True)
