from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

p = Path(__file__).resolve().parent
r = p.parent.parent
s = r / 'source'
b = r / 'build-uvm'
tmp = p / 'tmp'
tmp.mkdir(exist_ok=True)
env = dict(os.environ, TMPDIR=str(tmp.resolve()))
commands = [
    ('focused', [str(b / 'bin/server_unittests'),
        '[frozen-analysis-oracle],EditingActiveInstancePreservesParentLocalType,Saved full diagnostics lose coverage when a sibling buffer changes']),
    ('ctest', ['/opt/homebrew/bin/ctest', '--test-dir', str(b),
        '--output-on-failure', '--no-tests=error', '-j2']),
    ('python', [sys.executable, '-m', 'pytest', 'tests/system', 'tests/method_scope',
        '--binary', str(b / 'bin/slang-server'), '-q']),
]
rows = []
for name, command in commands:
    start = time.monotonic()
    with (p / (name + '-freshness-final.log')).open('w') as out:
        result = subprocess.run(command, cwd=s, env=env, stdout=out,
            stderr=subprocess.STDOUT)
    rows.append(dict(name=name, command=command, returncode=result.returncode,
        seconds=time.monotonic() - start))
    (p / 'freshness-checks.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(rows[-1], flush=True)
    if result.returncode:
        sys.exit(result.returncode)

files = ['include/ast/ServerCompilation.h', 'src/ServerDriver.cpp',
    'src/ast/ServerCompilation.cpp', 'src/ast/ServerCompilationAnalysis.cpp',
    'tests/cpp/HoverTests.cpp', 'tests/cpp/ActiveInstanceTests.cpp',
    'tests/cpp/DiagTests.cpp']
(p / 'freshness-source.json').write_text(json.dumps({
    'files': {name: hashlib.sha256((s / name).read_bytes()).hexdigest() for name in files},
    'binarySha256': hashlib.sha256((b / 'bin/slang-server').read_bytes()).hexdigest(),
    'tmpdir': str(tmp.resolve()),
    'note': 'Functional prerequisite; not a performance measurement or frozen-cache implementation'
}, indent=2) + '\n')
