from pathlib import Path
p=Path(__file__).resolve().parent;o=p.parent/'uvm-engineering-2026-10-19'
common="""from pathlib import Path
import ast,copy,hashlib,json,random,statistics,sys,os,time,traceback,threading
home=Path(__file__).resolve().parent;p=home.parent/'uvm-engineering-2026-10-19';out=home/'performance'
sys.path.insert(0,str(home.parent/'full-performance-2026-10-19'));import evaluate as e
e.out=p;base=e.configuration
for key in os.environ:assert not key.startswith('SLANG_UVM_'),key
def configuration(project,cell):
 cfg=base(project,cell);cfg['experimentalUvmPrefixCache']=cell.get('prefix',False);return cfg
e.configuration=configuration
arms={'old-on':(p/'product-next/slang-server-v4',True),'new-on':(home/'slang-server-F123c',True),'new-off':(home/'slang-server-F123c',False)}
binaries={a:b for a,(b,_) in arms.items()};binary=home/'slang-server-F123c'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def plan(name,schedule,scope,**extra):
 value=dict(scope=scope,schedule=schedule,binaries={a:dict(path=str(b),sha256=sha(b),prefix=f) for a,(b,f) in arms.items()},driverSha256=sha(Path(__file__)),helperSha256=sha(home.parent/'full-performance-2026-10-19/evaluate.py'),catalogSha256=sha(p/'workloads.json'),projectsSha256=sha(p/'projects.json'),**extra)
 with (out/(name+'-plan.json')).open('x') as f:json.dump(value,f,indent=2)
 for project in e.PROJECTS.values():
  for name,h in project['files'].items():assert sha(p/project['root']/name)==h,name
 return value
def guard(cell,r):
 log=(p/e.PROJECTS[e.CASES[cell['case']]['project']]['root']/'server.stderr').read_text(errors='replace')
 r['isolatedDiagnosticCommit']='Committed isolated diagnostic snapshot' in log
 if not r['isolatedDiagnosticCommit'] or any(x in log for x in ['Using sequential diagnostics','Diagnostic worker rejected job','Diagnostics are running sequentially']):r['outcome']='diagnostic-fallback'
 return r
scope='Fresh sequential processes, unchanged fixed corpus; mirrored shuffled 3-arm blocks n20 per arm/cell. All outliers/failures retained without replacement. No trace/status/sampler or concurrent compilation/tests. Warm filesystem; cold includes process/startup/first query. p95 descriptive only.'
"""
# mechanism control: same transport, same binary, prefix toggle only.
s=common+"""
controls={'reuse':{},'persistent-native':{'SLANG_UVM_WORKER_PREFIX_DISABLE':'1'}};rng=random.Random(2026101940);blocks=[]
for case in ['W01-compare','W07-pss-multidoc','W08-ubus-task']:
 for block in range(4):
  order=list(controls);rng.shuffle(order);blocks.append([dict(case=case,arm=a,block=block) for a in order+order[::-1]])
rng.shuffle(blocks);schedule=[x for b in blocks for x in b];plan('component',schedule,'Same F123c binary, Config on, persistent child in both arms; only worker prefix reuse disabled in persistent-native arm. n8 per arm/case, mirrored balanced pairs. No status/trace/sampler. Exploratory component attribution, no tail claim.',controls=controls)
with (out/'component.jsonl').open('x') as f:
 for i,c in enumerate(schedule):
  r=guard(c,e.run(dict(case=c['case'],method='definition',prefix=True,enabled=False,diagnostics='drained'),binary=binary,status=False,extra_env=controls[c['arm']]))
  r.update(c,index=i);f.write(json.dumps(r,separators=(',',':'))+'\\n');f.flush();assert r['outcome']=='success',(c,r.get('error'))
  if (i+1)%12==0:print('component',i+1,len(schedule),flush=True)
"""
(p/'measure_component.py').write_text(s)
s=common+"""
rng=random.Random(2026101941);blocks=[]
for stage,cases,mode in [('drained',['W01-compare','W07-pss-multidoc','W08-ubus-task','W13-continuous'],'drained'),('burst',['W13-continuous'],'burst')]:
 for case in cases:
  for method in ['completion','definition']:
   for block in range(10):
    order=list(arms);rng.shuffle(order);blocks.append([dict(stage=stage,case=case,method=method,diagnostics=mode,block=block,arm=a) for a in order+order[::-1]])
rng.shuffle(blocks);schedule=[x for b in blocks for x in b];evidence=plan('timing',schedule,scope)
with (out/'timing.jsonl').open('x') as f:
 for i,c in enumerate(schedule):
  b,prefix=arms[c['arm']];assert sha(b)==evidence['binaries'][c['arm']]['sha256']
  r=guard(c,e.run(dict(case=c['case'],method=c['method'],prefix=prefix,enabled=False,diagnostics=c['diagnostics']),binary=b,status=False));r.update(c,index=i)
  f.write(json.dumps(r,separators=(',',':'))+'\\n');f.flush();assert r['outcome']=='success',(c,r.get('error'))
  if (i+1)%30==0:print('timing',i+1,len(schedule),flush=True)
"""
(p/'measure_timing.py').write_text(s)
# Adapt proven rich all-resolve runner.
s=(o/'rich_next.py').read_text();start=s.index('macro=copy.deepcopy');end=s.index("rng=random.Random",start);body=s[start:end]
body=body.replace("cell['arm']=='on'","arms[cell['arm']][1]").replace('e.EvalClient(binary,folder)','e.EvalClient(binaries[cell[\'arm\']],folder)')
s=common+body+"""
rng=random.Random(2026101942);blocks=[]
for case in ['W01-compare','W09-ubus-config','W13-continuous','M-steady','W07-pss-multidoc','W08-ubus-task']:
 for block in range(10):
  order=list(arms);rng.shuffle(order);blocks.append([dict(case=case,arm=a,block=block) for a in order+order[::-1]])
rng.shuffle(blocks);schedule=[x for b in blocks for x in b];evidence=plan('rich',schedule,scope+' Completion and every returned candidate resolved before version diagnostics drain.')
with (out/'rich.jsonl').open('x') as f:
 for i,c in enumerate(schedule):
  r=run(c);r.update(c,index=i);f.write(json.dumps(r,separators=(',',':'))+'\\n');f.flush();assert r['outcome']=='success',(c,r.get('error'))
  if (i+1)%30==0:print('rich',i+1,len(schedule),flush=True)
"""
(p/'measure_rich.py').write_text(s)
# Fallback runner preserves its watched-change and fixture restoration behavior.
s=(o/'fallback_next.py').read_text();body=s[s.index('class Client'):s.index("variants=")];tail=s[s.index("with (out/'fallback.jsonl')"):]
tail=tail.replace("assert sha(binary)==plan['sha256'];r=e.run", "binary,prefix=arms[cell['arm']];assert sha(binary)==evidence['binaries'][cell['arm']]['sha256'];r=e.run").replace("prefix=cell['prefix']","prefix=prefix").replace("if (i+1)%20==0","if (i+1)%30==0")
s=common+"baseConfig=base;Parent=e.EvalClient;cell={}\n"+body+"""
variants=['tail-timescale','tail-resetall','macro-override','nonprefix-order','library-watch','config-watch'];rng=random.Random(2026101943);blocks=[]
for variant in variants:
 for block in range(10):
  order=list(arms);rng.shuffle(order);blocks.append([dict(variant=variant,arm=a,block=block) for a in order+order[::-1]])
rng.shuffle(blocks);schedule=[x for b in blocks for x in b];evidence=plan('fallback',schedule,scope+' Six unsupported/invalidation variants. Watch event batching includes foreground reload cost.')
"""+tail
(p/'measure_fallback.py').write_text(s)
# Long latency adds no product requests, extracts epoch already in opaque completion data.
s=(o/'long_latency_next.py').read_text();body=s[s.index('# Observe'):s.index('rng=random.Random')];body=body.replace("(p.parent/'full-performance", "(home.parent/'full-performance")
s=common+body+"""
rng=random.Random(2026101944);schedule=[]
for rep in range(3):
 cases=['W13-continuous','W07-pss-multidoc','W08-ubus-task'];rng.shuffle(cases)
 for case in cases:
  order=list(arms);rng.shuffle(order);schedule.extend(dict(case=case,rep=rep,arm=a) for a in order)
evidence=plan('long',schedule,'1000-edit completion burst sessions, three arms n3 each case. Existing completion opaque epochs observe natural retirement; no trace/status/sampler. Initial/final diagnostics drained, complete ordinary completion/cached query/selected resolve. All samples retained.',cycles=1000)
with (out/'long.jsonl').open('x') as f:
 for i,c in enumerate(schedule):
  b,prefix=arms[c['arm']];r=guard(c,e.run(dict(case=c['case'],method='completion',prefix=prefix,enabled=False,diagnostics='burst'),binary=b,status=False,cycles=1000))
  epochs=[x.get('completionEpoch') for x in r['rows']];bounds=[j for j in range(1,len(epochs)) if epochs[j]!=epochs[j-1]]
  if prefix:assert epochs and all(isinstance(x,int) for x in epochs) and bounds,(c,epochs[:3])
  else:assert all(x is None for x in epochs)
  r.update(c,index=i,retirementSteps=bounds);f.write(json.dumps(r,separators=(',',':'))+'\\n');f.flush();assert r['outcome']=='success',r.get('error');print('long',i+1,len(schedule),c,'retirements',len(bounds),flush=True)
"""
(p/'measure_long.py').write_text(s)
# Separate memory, no trace needed; final mark explicit. All three versions.
s=common+"""
import memory as m
schedule=[]
for rep in range(3):
 for case in ['W13-continuous','W07-pss-multidoc','W08-ubus-task']:
  for method in ['completion','definition']:
   order=list(arms)
   if rep%2:order.reverse()
   for a in order:schedule.append(dict(stage='short',rep=rep,case=case,method=method,arm=a,diagnostics='drained',cycles=None))
for case in ['W13-continuous','W07-pss-multidoc','W08-ubus-task']:
 for a in arms:schedule.append(dict(stage='long-burst',rep=0,case=case,method='completion',arm=a,diagnostics='burst',cycles=1000))
 for a in arms:schedule.append(dict(stage='long-drained',rep=0,case=case,method='definition',arm=a,diagnostics='drained',cycles=500))
 for a in ['new-on']:schedule.append(dict(stage='idle',rep=0,case=case,method='definition',arm=a,diagnostics='drained',cycles=None))
evidence=plan('memory',schedule,'Separate libproc 20ms RSS runs, no latency conclusions. Short n3; long n1; parent+family peaks, shared pages counted multiple times and 20ms peaks can be missed. 1000 completion burst / 500 definition drained edits. 3 final+6s idle marks demonstrate worker eviction. No general RSS bound.')
with (out/'memory.jsonl').open('x') as f:
 for i,c in enumerate(schedule):
  b,prefix=arms[c['arm']];sampler=m.Sampler()
  def observe(client,step):
   sampler.observe(client,step);last=c['cycles']+1 if c['cycles'] is not None else len(e.CASES[c['case']]['states'])
   if step==last:
    sampler.marks.append(dict(step=step,phase='final',serverPid=client.process.pid,seconds=time.monotonic()-sampler.started,rss=m.rss(client.process.pid)))
    if c['stage']=='idle':
     time.sleep(6);sampler.marks.append(dict(step=step,phase='idle6s',serverPid=client.process.pid,seconds=time.monotonic()-sampler.started,rss=m.rss(client.process.pid)))
  thread=threading.Thread(target=sampler.loop);thread.start()
  try:r=guard(c,e.run(dict(case=c['case'],method=c['method'],prefix=prefix,enabled=False,diagnostics=c['diagnostics']),binary=b,status=False,observer=observe,cycles=c['cycles']))
  finally:sampler.stop.set();thread.join()
  if sampler.limit:r['outcome']='budget-exceeded'
  r.update(c,index=i,memory=dict(intervalMs=20,samples=sampler.samples,marks=sampler.marks,peakFamilyRss=max(x['familyRss'] for x in sampler.samples),limit=sampler.limit));f.write(json.dumps(r,separators=(',',':'))+'\\n');f.flush();print('memory',i+1,len(schedule),c['stage'],c['case'],c['arm'],r['outcome'],flush=True);assert r['outcome'] in ('success','budget-exceeded'),r.get('error')
"""
(p/'measure_memory.py').write_text(s)
for f in p.glob('measure_*.py'):compile(f.read_text(),str(f),'exec')
print('prepared six sequential measurement stages')
