from pathlib import Path
import subprocess,sys,time,json
p=Path(__file__).resolve().parent;records=[]
for name in ['timing','rich','fallback','long','memory']:
 started=time.monotonic()
 with (p/(name+'.log')).open('x') as f:r=subprocess.run([sys.executable,str(p/('measure_'+name+'.py'))],stdout=f,stderr=subprocess.STDOUT)
 records.append(dict(stage=name,returncode=r.returncode,seconds=time.monotonic()-started));(p/'measurement-stages.json').write_text(json.dumps(records,indent=2)+'\n');print(records[-1],flush=True)
 if r.returncode:sys.exit(r.returncode)
