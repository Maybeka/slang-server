from pathlib import Path
import ast,copy,hashlib,json,random,statistics,sys,os,time,traceback,threading
home=Path(__file__).resolve().parent;p=home.parent/'uvm-engineering-2026-10-19';out=home/'performance'
sys.path.insert(0,str(home.parent/'full-performance-2026-10-19'));import evaluate as e
e.out=p;base=e.configuration
for key in os.environ:assert not key.startswith('SLANG_UVM_'),key
def configuration(project,cell):
 cfg=base(project,cell);cfg['experimentalUvmPrefixCache']=cell.get('prefix',False);return cfg
e.configuration=configuration
arms={'old-on':(p/'product-next/slang-server-v4',True),'new-on':(home/'slang-server-F123c',True),'new-off':(home/'slang-server-F123c',False)}
binaries={a:b for a,(b,_) in arms.items()};binary=home/'slang-server-F123c'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def plan(name,schedule,scope,**extra):
 value=dict(scope=scope,schedule=schedule,binaries={a:dict(path=str(b),sha256=sha(b),prefix=f) for a,(b,f) in arms.items()},driverSha256=sha(Path(__file__)),helperSha256=sha(home.parent/'full-performance-2026-10-19/evaluate.py'),catalogSha256=sha(p/'workloads.json'),projectsSha256=sha(p/'projects.json'),**extra)
 with (out/(name+'-plan.json')).open('x') as f:json.dump(value,f,indent=2)
 for project in e.PROJECTS.values():
  for name,h in project['files'].items():assert sha(p/project['root']/name)==h,name
 return value
def guard(cell,r):
 log=(p/e.PROJECTS[e.CASES[cell['case']]['project']]['root']/'server.stderr').read_text(errors='replace')
 r['isolatedDiagnosticCommit']='Committed isolated diagnostic snapshot' in log
 if not r['isolatedDiagnosticCommit'] or any(x in log for x in ['Using sequential diagnostics','Diagnostic worker rejected job','Diagnostics are running sequentially']):r['outcome']='diagnostic-fallback'
 return r
scope='Fresh sequential processes, unchanged fixed corpus; mirrored shuffled 3-arm blocks n20 per arm/cell. All outliers/failures retained without replacement. No trace/status/sampler or concurrent compilation/tests. Warm filesystem; cold includes process/startup/first query. p95 descriptive only.'


rows=[]
for case in ['W13-continuous','W07-pss-multidoc','W08-ubus-task']:
 trace=out/(case+'-phases.tsv');generation=out/(case+'-phase-generations.tsv');assert not trace.exists() and not generation.exists()
 r=e.run(dict(case=case,method='completion',prefix=True,enabled=False,diagnostics='drained'),binary=binary,status=False,cycles=12,extra_env={'SLANG_UVM_GENERATION_EDIT_LIMIT':'3','SLANG_UVM_PHASE_TRACE':str(trace),'SLANG_UVM_GENERATION_TRACE':str(generation)})
 assert r['outcome']=='success',r.get('error');events=trace.read_text().splitlines();assert all(any(phase in x for x in events) for phase in ['retirement-release','retirement-construct','retirement-copy-open','retirement-load-publish']);rows.append(dict(case=case,outcome=r['outcome'],events=events,generations=generation.read_text().splitlines()))
 print(case,'phase events',len(events),flush=True)
(out/'phases.json').write_text(json.dumps(dict(scope='Mechanism-only forced edit limit3,12 edits each case. Optional traces perturb execution; not ordinary latency evidence. load-publish includes nested construct/copy-open timings; never sum overlapping phase fields.',rows=rows),indent=2)+'\n')
