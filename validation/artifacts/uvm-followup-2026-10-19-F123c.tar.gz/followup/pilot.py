from pathlib import Path
import hashlib,json,random,sys,statistics,collections,os
p=Path(__file__).resolve().parent;old=p.parent/'uvm-engineering-2026-10-19';out=p/'performance';sys.path.insert(0,str(p.parent/'full-performance-2026-10-19'));import evaluate as e
e.out=old;base=e.configuration
for key in os.environ:assert not key.startswith('SLANG_UVM_'),key
def configuration(project,cell):
 cfg=base(project,cell);cfg['experimentalUvmPrefixCache']=cell['prefix'];return cfg
e.configuration=configuration
arms={'old-on':(old/'product-next/slang-server-v4',True),'F12-on':(p/'slang-server-F12',True),'new-on':(p/'slang-server-F123b',True),'new-off':(p/'slang-server-F123b',False)}
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();rng=random.Random(2026101931);blocks=[]
for case,method in [('W01-compare','definition'),('W07-pss-multidoc','definition'),('W08-ubus-task','completion'),('W13-continuous','completion')]:
 for block in range(2):
  order=list(arms);rng.shuffle(order);blocks.append([dict(case=case,method=method,arm=a,block=block) for a in order+order[::-1]])
rng.shuffle(blocks);schedule=[c for b in blocks for c in b]
plan=dict(scope='Exploratory readiness pilot only; n4 arm/cell, mirrored shuffled four-arm blocks. No trace/status/sampler, no concurrent build/test. All failures/outliers retained; no precision or tail claim.',binaries={k:dict(path=str(v[0]),sha256=sha(v[0]),prefix=v[1]) for k,v in arms.items()},schedule=schedule)
assert not (out/'pilot-plan.json').exists();(out/'pilot-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
with (out/'pilot.jsonl').open('x') as f:
 for i,c in enumerate(schedule):
  binary,prefix=arms[c['arm']];assert sha(binary)==plan['binaries'][c['arm']]['sha256'];r=e.run(dict(case=c['case'],method=c['method'],prefix=prefix,enabled=False,diagnostics='drained'),binary=binary,status=False)
  log=(old/e.PROJECTS[e.CASES[c['case']]['project']]['root']/'server.stderr').read_text(errors='replace');r['isolatedDiagnosticCommit']='Committed isolated diagnostic snapshot' in log
  if not r['isolatedDiagnosticCommit'] or any(x in log for x in ['Using sequential diagnostics','Diagnostic worker rejected job','Diagnostics are running sequentially']):r['outcome']='diagnostic-fallback'
  r.update(c,index=i);f.write(json.dumps(r,separators=(',',':'))+'\n');f.flush();assert r['outcome']=='success',(c,r.get('error'),log[-1000:])
  if (i+1)%8==0:print('pilot',i+1,'/',len(schedule),flush=True)
groups=collections.defaultdict(list)
for x in (out/'pilot.jsonl').read_text().splitlines():
 r=json.loads(x);groups[r['case'],r['arm']].append(r)
summary=[dict(case=k[0],arm=k[1],firstEditMs=statistics.median(r['firstEditMs'] for r in rs),editSumMs=statistics.median(r['editResponseSumMs'] for r in rs),sequenceMs=statistics.median(r['sequenceWithDiagnosticsMs'] for r in rs)) for k,rs in sorted(groups.items())]
(out/'pilot-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for r in summary:print(r,flush=True)
