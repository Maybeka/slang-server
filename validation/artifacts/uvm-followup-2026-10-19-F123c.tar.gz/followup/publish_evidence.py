from pathlib import Path
import hashlib,json,tarfile,collections
p=Path(__file__).resolve().parent;root=p.parent.parent;s=root/'source';perf=p/'performance';analysis=json.loads((perf/'analysis.json').read_text());sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
assert all(x['returncode']==0 for x in json.loads((p/'final-correctness.json').read_text()))
assert all(x['returncode']==0 for x in json.loads((p/'measurement-stages.json').read_text()))
files=[]
for name in ['candidate-F12.json','candidate-F123a.json','candidate-F123b.json','candidate-F123c.json','final-correctness.json','gates-F123c.json','restoration-check-F123b.json','measurement-stages.json','transport-first.log','snapshot-update-tests.log','session-tests.log','F12-tests.log','final_correctness.py','full_gates_F123c.py','validate_F123c.py','validate_F123c_canonical.py','controls_F123c.py','rollback_F123c.py','pressure_F123c.py','pilot.py','prepare_measurements.py','run_measurements.py','analyze_measurements.py','publish_evidence.py','write_report.py','final_audit.py','final-audit.json','finish_assessment.py']:
 files.append(p/name)
files+=sorted((p/'evidence-helpers').glob('*.py'));files+=sorted(p.glob('measure_*.py'));files+=sorted(p.glob('gate-0*.log'));files+=sorted(p.glob('final-correctness-*.log'))
files+=sorted(perf.glob('*.json'));files+=sorted(perf.glob('*.jsonl'));files+=sorted(perf.glob('*runner.py'));files+=sorted(perf.glob('*phases.tsv'));files+=sorted(perf.glob('*phase-generations.tsv'))
for dirname in ['oracle-F123c-off','oracle-F123c-canonical-on','oracle-F123c-canonical-forced']:
 d=p/dirname;files += [d/'oracle.json',d/'candidate.json'];files+=list(d.glob('*.tsv'))
for dirname in ['replacement-failure-F123c','macro-controls-F123c','pressure-F123c']:
 d=p/dirname;files+=list(d.glob('results.json'));files+=list(d.glob('*.tsv'))
assert all(f.exists() for f in files)
archive=s/'validation/artifacts/uvm-followup-2026-10-19-F123c.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for f in sorted(set(files)):t.add(f,arcname='followup/'+str(f.relative_to(p)),recursive=False)
manifest={str(f.relative_to(p)):dict(sha256=sha(f),bytes=f.stat().st_size) for f in sorted(set(files))}
with tarfile.open(archive) as t:
 for name,v in manifest.items():assert hashlib.sha256(t.extractfile('followup/'+name).read()).hexdigest()==v['sha256']
oracles={}
for mode in ['off','canonical-on','canonical-forced']:
 rows=json.loads((p/('oracle-F123c-'+mode)/'oracle.json').read_text());oracles[mode]=dict(cases=len(rows),completeEqual=all(r['equal'] and r['staleEqual'] for r in rows),diagnosticOrderChanged=[r['case'] for r in rows if not r.get('orderedDiagnosticsEqual',True)])
report=dict(schema=1,baselineCommit='2903a0859aabb1a0cd4242d4c89eac3c0fcd2eaf',candidate=analysis['candidate'],defaultOff=True,platform='macOS 27.0.1 arm64, 24 GiB; no Linux run in this goal',oracles=oracles,diagnosticComparison='Off: original exact array comparison. On/forced: sort only complete diagnostic entries by full JSON, retain duplicates and relatedInformation order. Completion/definition/all resolves/stale results preserve their original comparisons. W08/W09 same-location/code diagnostic entry order changes, no content lost.',functional=json.loads((p/'gates-F123c.json').read_text()),transport='43/43; isolated standalone run before F123c (transport code unchanged)',sdkRestoration=json.loads((p/'restoration-check-F123b.json').read_text()),analysis=analysis,archive=dict(path=str(archive.relative_to(s)),sha256=sha(archive),bytes=archive.stat().st_size),evidenceFiles=manifest,privateCorpus='Workload source bodies, original full oracle bodies, binaries and handoff remain in untracked/. Only source hashes, measurement results and validation scripts are archived.')
(s/'validation/macos-uvm-followup-2026-10-19.json').write_text(json.dumps(report,indent=2)+'\n')
print('Published',len(manifest),'evidence files; archive',archive.stat().st_size,'bytes',sha(archive))
