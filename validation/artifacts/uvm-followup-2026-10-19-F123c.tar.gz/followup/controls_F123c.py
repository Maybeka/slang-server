from pathlib import Path
import copy,json,sys
p=Path('/Users/xn/Documents/Codex/2026-10-19/handoff-md-package-include/untracked/uvm-engineering-2026-10-19');q=p/'product-next';out=Path('/Users/xn/Documents/Codex/2026-10-19/handoff-md-package-include/untracked/uvm-followup-2026-10-19/macro-controls-F123c');v=p.parent/'uvm-prefix-prototype-2026-10-19/v5';sys.path.insert(0,str(v));import oracle as o

_originalComparable=o.comparable
def _semanticComparable(result):
 return [dict(row,diagnostics=sorted(row['diagnostics'],key=lambda d:__import__('json').dumps(d,sort_keys=True))) for row in _originalComparable(result)]
o.comparable=_semanticComparable
o.p=q;o.e.out=q;e=o.e;Parent=o.OracleClient;name='';report=[];instances=[]
class Traced(Parent):
 def __init__(self,*args,**kwargs):
  self.envelopes=[];instances.append(self)
  env=kwargs.get('extra_env',{}).copy()
  if 'SLANG_SERVER_UVM_PREFIX_CACHE' in env:env.update(SLANG_UVM_RESOLVE_CACHE_TRACE=str(out/f'{name}-cache.tsv'),SLANG_UVM_PARSE_TRACE=str(out/f'{name}-parse.tsv'))
  config=args[1]/'.slang/server.json';settings=json.loads(config.read_text());settings['experimentalUvmPrefixCache']='SLANG_SERVER_UVM_PREFIX_CACHE' in env;config.write_text(json.dumps(settings))
  if settings['experimentalUvmPrefixCache']:env.update(SLANG_UVM_GENERATION_EDIT_LIMIT='1',SLANG_UVM_GENERATION_TRACE=str(out/f'{name}-generation.tsv'))
  kwargs['extra_env']=env;super().__init__(*args,**kwargs)
 def request(self,method,params,notifications=()):
  value,received=super().request(method,params,notifications)
  if method=='textDocument/completion' and isinstance(value,dict) and 'items' in value:
   self.envelopes.append({k:v for k,v in value.items() if k!='items'});return value['items'],received
  return value,received
o.OracleClient=Traced
assert not (out/'macro-controls.json').exists()
for kind in ('steady','library-watch','config-watch','library-overlay'):
 name='M-'+kind;case=copy.deepcopy(e.CASES['W01-compare']);case['id']=name
 for state in case['states']:state['completion']=dict(anchor='`uvm_object_utils(spi_seq_item)',token='`uvm_object_utils')
 macro=q/e.PROJECTS[case['project']]['root']/'uvm/macros/uvm_object_defines.svh';saved=macro.read_bytes();marker=b'`define uvm_object_utils(T) \\\n';assert marker in saved;modified=saved.replace(marker,b'// RESOLVE_INVALIDATION_STAMP\n'+marker,1)
 def hook(client,i,project):
  if i:return
  if kind=='library-watch':
   macro.write_bytes(modified);client.notify('workspace/didChangeWatchedFiles',dict(changes=[dict(uri=macro.as_uri(),type=2)]))
  elif kind=='config-watch':
   config=project/'.slang/server.json';value=json.loads(config.read_text());value['flags']+=' -DUVM_RESOLVE_TEST=1';config.write_text(json.dumps(value));client.notify('workspace/didChangeWatchedFiles',dict(changes=[dict(uri=config.as_uri(),type=2)]))
  elif kind=='library-overlay':client.notify('textDocument/didOpen',dict(textDocument=dict(uri=macro.as_uri(),version=1,languageId='systemverilog',text=modified.decode())))
 runs=[]
 for cache,binary in ((False,e.BINARY),(True,Path('/Users/xn/Documents/Codex/2026-10-19/handoff-md-package-include/untracked/uvm-followup-2026-10-19/slang-server-F123c'))):
  try:runs.append(o.run(case,binary,cache,False,hook=hook))
  finally:macro.write_bytes(saved)
 a,b=runs;equal=a['outcome']==b['outcome']=='success' and o.comparable(a)==o.comparable(b);trace=(out/f'{name}-cache.tsv').read_text() if (out/f'{name}-cache.tsv').exists() else '';row=dict(name=name,native=a,prototype=b,equal=equal,trace=trace,nativeEnvelopes=instances[-2].envelopes,prototypeEnvelopes=instances[-1].envelopes);report.append(row);(out/'macro-controls.json').write_text(json.dumps(report,separators=(',',':'))+'\n');print(name,a['outcome'],b['outcome'],equal,flush=True);assert equal,(a.get('error'),b.get('error'));assert instances[-2].envelopes==instances[-1].envelopes;assert '\thit\t' in trace
 if kind!='steady':assert '\tinvalidated\t' in trace or kind=='config-watch'
print('Macro steady/watch/config/unsaved-overlay controls passed',flush=True)
