from pathlib import Path
import subprocess,sys,json,time
p=Path(__file__).resolve().parent;stages=[]
# Off retained exact ordered oracle; enabled/forced retain all fields and duplicate
# diagnostic counts, normalizing only the diagnostic-entry array order.
commands=[('off oracle',['validate_F123c.py','off']),('on oracle',['validate_F123c_canonical.py','on']),('forced oracle',['validate_F123c_canonical.py','forced']),('complete gates',['full_gates_F123c.py'])]
for i,(name,args) in enumerate(commands):
 start=time.monotonic();print('START',name,flush=True)
 with (p/f'final-correctness-{i}.log').open('w') as f:r=subprocess.run([sys.executable,str(p/args[0]),*args[1:]],stdout=f,stderr=subprocess.STDOUT)
 stages.append(dict(name=name,returncode=r.returncode,seconds=time.monotonic()-start));(p/'final-correctness.json').write_text(json.dumps(stages,indent=2)+'\n');print('END',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
