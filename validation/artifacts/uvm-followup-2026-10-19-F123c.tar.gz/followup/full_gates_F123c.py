from pathlib import Path
import os,sys,subprocess,time,json
p=Path(__file__).resolve().parent;root=p.parent.parent;s=root/'source';build=root/'build-uvm';stages=[];tmp=p/'full-test-tmp';tmp.mkdir(exist_ok=True)
commands=[('macro freshness',[sys.executable,str(p/'controls_F123c.py')],s),('replacement failure',[sys.executable,str(p/'rollback_F123c.py')],s),('bounded cache',[sys.executable,str(p/'pressure_F123c.py')],s),('complete ctest',['/opt/homebrew/bin/ctest','--test-dir',str(build),'--output-on-failure','--no-tests=error','-j2'],s),('complete sdk',[str(build/'bin/unittests')],build/'external/slang/tests/unittests'),('python system',[sys.executable,'-m','pytest','tests/system','--binary',str(p/'slang-server-F123c'),'-q'],s),('python measurement',[sys.executable,'-m','pytest','tests/method_scope','-q'],s)]
for i,(name,command,cwd) in enumerate(commands):
 print('START',name,flush=True);start=time.monotonic()
 with (p/f'gate-{i:02}.log').open('w') as f:r=subprocess.run(command,cwd=cwd,env=dict(os.environ,TMPDIR=str(tmp)),stdout=f,stderr=subprocess.STDOUT)
 stages.append(dict(name=name,command=command,cwd=str(cwd),returncode=r.returncode,seconds=time.monotonic()-start));(p/'gates-F123c.json').write_text(json.dumps(stages,indent=2)+'\n');print('END',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
