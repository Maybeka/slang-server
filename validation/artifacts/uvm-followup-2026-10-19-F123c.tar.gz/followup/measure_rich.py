from pathlib import Path
import ast,copy,hashlib,json,random,statistics,sys,os,time,traceback,threading
home=Path(__file__).resolve().parent;p=home.parent/'uvm-engineering-2026-10-19';out=home/'performance'
sys.path.insert(0,str(home.parent/'full-performance-2026-10-19'));import evaluate as e
e.out=p;base=e.configuration
for key in os.environ:assert not key.startswith('SLANG_UVM_'),key
def configuration(project,cell):
 cfg=base(project,cell);cfg['experimentalUvmPrefixCache']=cell.get('prefix',False);return cfg
e.configuration=configuration
arms={'old-on':(p/'product-next/slang-server-v4',True),'new-on':(home/'slang-server-F123c',True),'new-off':(home/'slang-server-F123c',False)}
binaries={a:b for a,(b,_) in arms.items()};binary=home/'slang-server-F123c'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def plan(name,schedule,scope,**extra):
 value=dict(scope=scope,schedule=schedule,binaries={a:dict(path=str(b),sha256=sha(b),prefix=f) for a,(b,f) in arms.items()},driverSha256=sha(Path(__file__)),helperSha256=sha(home.parent/'full-performance-2026-10-19/evaluate.py'),catalogSha256=sha(p/'workloads.json'),projectsSha256=sha(p/'projects.json'),**extra)
 with (out/(name+'-plan.json')).open('x') as f:json.dump(value,f,indent=2)
 for project in e.PROJECTS.values():
  for name,h in project['files'].items():assert sha(p/project['root']/name)==h,name
 return value
def guard(cell,r):
 log=(p/e.PROJECTS[e.CASES[cell['case']]['project']]['root']/'server.stderr').read_text(errors='replace')
 r['isolatedDiagnosticCommit']='Committed isolated diagnostic snapshot' in log
 if not r['isolatedDiagnosticCommit'] or any(x in log for x in ['Using sequential diagnostics','Diagnostic worker rejected job','Diagnostics are running sequentially']):r['outcome']='diagnostic-fallback'
 return r
scope='Fresh sequential processes, unchanged fixed corpus; mirrored shuffled 3-arm blocks n20 per arm/cell. All outliers/failures retained without replacement. No trace/status/sampler or concurrent compilation/tests. Warm filesystem; cold includes process/startup/first query. p95 descriptive only.'
macro=copy.deepcopy(e.CASES['W01-compare']);macro['id']='M-steady'
for state in macro['states']:state['completion']=dict(anchor='`uvm_object_utils(spi_seq_item)',token='`uvm_object_utils')
e.CASES[macro['id']]=macro
source=(p/'time_shared_guards.py').read_text();fn='def run(cell):'+source.split('def run(cell):',1)[1].split("\nassert not (out/'rich-timing-results.jsonl')",1)[0]
fn=fn.replace('e.configuration(project,dict(enabled=False))',"e.configuration(project,dict(enabled=False,prefix=arms[cell['arm']][1]))").replace("e.EvalClient(binaries[cell['arm']],folder,extra_env={'SLANG_SERVER_UVM_PREFIX_CACHE':'1'})","e.EvalClient(binaries[cell['arm']],folder)")
fn=fn.replace("assert 'Using sequential diagnostics' not in stderr and 'Diagnostic worker rejected job' not in stderr","assert all(x not in stderr for x in ['Using sequential diagnostics','Diagnostic worker rejected job','Diagnostics are running sequentially']) and 'Committed isolated diagnostic snapshot' in stderr")
(out/'rich-runner.py').write_text(fn+'\n');exec(compile(fn,str(out/'rich-runner.py'),'exec'),globals());
rng=random.Random(2026101942);blocks=[]
for case in ['W01-compare','W09-ubus-config','W13-continuous','M-steady','W07-pss-multidoc','W08-ubus-task']:
 for block in range(10):
  order=list(arms);rng.shuffle(order);blocks.append([dict(case=case,arm=a,block=block) for a in order+order[::-1]])
rng.shuffle(blocks);schedule=[x for b in blocks for x in b];evidence=plan('rich',schedule,scope+' Completion and every returned candidate resolved before version diagnostics drain.')
with (out/'rich.jsonl').open('x') as f:
 for i,c in enumerate(schedule):
  r=run(c);r.update(c,index=i);f.write(json.dumps(r,separators=(',',':'))+'\n');f.flush();assert r['outcome']=='success',(c,r.get('error'))
  if (i+1)%30==0:print('rich',i+1,len(schedule),flush=True)
