from pathlib import Path
import ast,copy,hashlib,json,random,statistics,sys,os,time,traceback,threading
home=Path(__file__).resolve().parent;p=home.parent/'uvm-engineering-2026-10-19';out=home/'performance'
sys.path.insert(0,str(home.parent/'full-performance-2026-10-19'));import evaluate as e
e.out=p;base=e.configuration
for key in os.environ:assert not key.startswith('SLANG_UVM_'),key
def configuration(project,cell):
 cfg=base(project,cell);cfg['experimentalUvmPrefixCache']=cell.get('prefix',False);return cfg
e.configuration=configuration
arms={'old-on':(p/'product-next/slang-server-v4',True),'new-on':(home/'slang-server-F123c',True),'new-off':(home/'slang-server-F123c',False)}
binaries={a:b for a,(b,_) in arms.items()};binary=home/'slang-server-F123c'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def plan(name,schedule,scope,**extra):
 value=dict(scope=scope,schedule=schedule,binaries={a:dict(path=str(b),sha256=sha(b),prefix=f) for a,(b,f) in arms.items()},driverSha256=sha(Path(__file__)),helperSha256=sha(home.parent/'full-performance-2026-10-19/evaluate.py'),catalogSha256=sha(p/'workloads.json'),projectsSha256=sha(p/'projects.json'),**extra)
 with (out/(name+'-plan.json')).open('x') as f:json.dump(value,f,indent=2)
 for project in e.PROJECTS.values():
  for name,h in project['files'].items():assert sha(p/project['root']/name)==h,name
 return value
def guard(cell,r):
 log=(p/e.PROJECTS[e.CASES[cell['case']]['project']]['root']/'server.stderr').read_text(errors='replace')
 r['isolatedDiagnosticCommit']='Committed isolated diagnostic snapshot' in log
 if not r['isolatedDiagnosticCommit'] or any(x in log for x in ['Using sequential diagnostics','Diagnostic worker rejected job','Diagnostics are running sequentially']):r['outcome']='diagnostic-fallback'
 return r
scope='Fresh sequential processes, unchanged fixed corpus; mirrored shuffled 3-arm blocks n20 per arm/cell. All outliers/failures retained without replacement. No trace/status/sampler or concurrent compilation/tests. Warm filesystem; cold includes process/startup/first query. p95 descriptive only.'
# Observe the epoch already present in the selected completion item. This adds
# no server trace, status request, witness request or memory sampler to timings.
text=(home.parent/'full-performance-2026-10-19/evaluate.py').read_text();node=next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name=='run');fn=ast.get_source_segment(text,node)
key="                item=next(x for x in result if x['label']==s['completion']['token'])";assert key in fn
fn=fn.replace(key,key+"\n                payload=item.get('data');row['completionEpoch']=payload.get('contextEpoch') if isinstance(payload,dict) else None",1)
(out/'long-runner.py').write_text(fn+'\n');exec(compile(fn,str(out/'long-runner.py'),'exec'),e.__dict__)

rng=random.Random(2026101944);schedule=[]
for rep in range(3):
 cases=['W13-continuous','W07-pss-multidoc','W08-ubus-task'];rng.shuffle(cases)
 for case in cases:
  order=list(arms);rng.shuffle(order);schedule.extend(dict(case=case,rep=rep,arm=a) for a in order)
evidence=plan('long',schedule,'1000-edit completion burst sessions, three arms n3 each case. Existing completion opaque epochs observe natural retirement; no trace/status/sampler. Initial/final diagnostics drained, complete ordinary completion/cached query/selected resolve. All samples retained.',cycles=1000)
with (out/'long.jsonl').open('x') as f:
 for i,c in enumerate(schedule):
  b,prefix=arms[c['arm']];r=guard(c,e.run(dict(case=c['case'],method='completion',prefix=prefix,enabled=False,diagnostics='burst'),binary=b,status=False,cycles=1000))
  epochs=[x.get('completionEpoch') for x in r['rows']];bounds=[j for j in range(1,len(epochs)) if epochs[j]!=epochs[j-1]]
  if prefix:assert epochs and all(isinstance(x,int) for x in epochs) and bounds,(c,epochs[:3])
  else:assert all(x is None for x in epochs)
  r.update(c,index=i,retirementSteps=bounds);f.write(json.dumps(r,separators=(',',':'))+'\n');f.flush();assert r['outcome']=='success',r.get('error');print('long',i+1,len(schedule),c,'retirements',len(bounds),flush=True)
