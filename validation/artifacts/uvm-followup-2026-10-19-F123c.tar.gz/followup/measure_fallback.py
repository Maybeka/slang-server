from pathlib import Path
import ast,copy,hashlib,json,random,statistics,sys,os,time,traceback,threading
home=Path(__file__).resolve().parent;p=home.parent/'uvm-engineering-2026-10-19';out=home/'performance'
sys.path.insert(0,str(home.parent/'full-performance-2026-10-19'));import evaluate as e
e.out=p;base=e.configuration
for key in os.environ:assert not key.startswith('SLANG_UVM_'),key
def configuration(project,cell):
 cfg=base(project,cell);cfg['experimentalUvmPrefixCache']=cell.get('prefix',False);return cfg
e.configuration=configuration
arms={'old-on':(p/'product-next/slang-server-v4',True),'new-on':(home/'slang-server-F123c',True),'new-off':(home/'slang-server-F123c',False)}
binaries={a:b for a,(b,_) in arms.items()};binary=home/'slang-server-F123c'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def plan(name,schedule,scope,**extra):
 value=dict(scope=scope,schedule=schedule,binaries={a:dict(path=str(b),sha256=sha(b),prefix=f) for a,(b,f) in arms.items()},driverSha256=sha(Path(__file__)),helperSha256=sha(home.parent/'full-performance-2026-10-19/evaluate.py'),catalogSha256=sha(p/'workloads.json'),projectsSha256=sha(p/'projects.json'),**extra)
 with (out/(name+'-plan.json')).open('x') as f:json.dump(value,f,indent=2)
 for project in e.PROJECTS.values():
  for name,h in project['files'].items():assert sha(p/project['root']/name)==h,name
 return value
def guard(cell,r):
 log=(p/e.PROJECTS[e.CASES[cell['case']]['project']]['root']/'server.stderr').read_text(errors='replace')
 r['isolatedDiagnosticCommit']='Committed isolated diagnostic snapshot' in log
 if not r['isolatedDiagnosticCommit'] or any(x in log for x in ['Using sequential diagnostics','Diagnostic worker rejected job','Diagnostics are running sequentially']):r['outcome']='diagnostic-fallback'
 return r
scope='Fresh sequential processes, unchanged fixed corpus; mirrored shuffled 3-arm blocks n20 per arm/cell. All outliers/failures retained without replacement. No trace/status/sampler or concurrent compilation/tests. Warm filesystem; cold includes process/startup/first query. p95 descriptive only.'
baseConfig=base;Parent=e.EvalClient;cell={}
class Client(Parent):
 def __init__(self,*args,**kwargs):self.step=0;super().__init__(*args,**kwargs)
 def rpc(self,method,params,notifications=()):
  if method=='textDocument/definition' and notifications:
   if self.step==1 and cell['variant'] in ('library-watch','config-watch'):
    if cell['variant']=='library-watch':changed=folder/'uvm/base/uvm_object_globals.svh';changed.write_bytes(savedLibrary+b'\n// performance invalidation\n')
    else:
     changed=folder/'.slang/server.json';cfg=json.loads(changed.read_text());cfg['flags']+=' -DUVM_PERFORMANCE_RELOAD=1';changed.write_text(json.dumps(cfg))
    notifications=[dict(method='workspace/didChangeWatchedFiles',params=dict(changes=[dict(uri=changed.as_uri(),type=2)])),*notifications]
   self.step+=1
  return super().rpc(method,params,notifications)
e.EvalClient=Client

variants=['tail-timescale','tail-resetall','macro-override','nonprefix-order','library-watch','config-watch'];rng=random.Random(2026101943);blocks=[]
for variant in variants:
 for block in range(10):
  order=list(arms);rng.shuffle(order);blocks.append([dict(variant=variant,arm=a,block=block) for a in order+order[::-1]])
rng.shuffle(blocks);schedule=[x for b in blocks for x in b];evidence=plan('fallback',schedule,scope+' Six unsupported/invalidation variants. Watch event batching includes foreground reload cost.')
with (out/'fallback.jsonl').open('x') as f:
 for i,cell in enumerate(schedule):
  case=copy.deepcopy(e.CASES['W08-ubus-task' if cell['variant']=='nonprefix-order' else 'W01-compare']);project=e.PROJECTS[case['project']];folder=p/project['root'];pkg=folder/'uvm/uvm_pkg.sv';savedPkg=pkg.read_bytes();filelist=folder/'design.f';savedList=filelist.read_bytes();library=folder/'uvm/base/uvm_object_globals.svh';savedLibrary=library.read_bytes();case['id']='fallback-'+cell['variant'];e.CASES[case['id']]=case
  try:
   if cell['variant']=='tail-timescale':pkg.write_bytes(savedPkg+b'\n`timescale 1ns/1ps\n')
   elif cell['variant']=='tail-resetall':pkg.write_bytes(savedPkg+b'\n`resetall\n')
   elif cell['variant']=='macro-override':
    last=(folder/case['target']).read_text().splitlines()[-1];case['states'][1]['operations'].append(dict(old=last,new=last+'\n`undef UVM_MACROS_SVH\n`define UVM_MACROS_SVH\n'))
   elif cell['variant']=='nonprefix-order':
    text=savedList.decode().replace('uvm/uvm.sv\nexamples/ubus_tb_top.sv','examples/ubus_tb_top.sv\nuvm/uvm.sv');assert text!=savedList.decode();filelist.write_text(text)
   binary,prefix=arms[cell['arm']];assert sha(binary)==evidence['binaries'][cell['arm']]['sha256'];r=e.run(dict(case=case['id'],method='definition',prefix=prefix,enabled=False,diagnostics='drained'),binary=binary,status=False);log=(folder/'server.stderr').read_text(errors='replace');r['isolatedDiagnosticCommit']='Committed isolated diagnostic snapshot' in log
   if any(s in log for s in ['Using sequential diagnostics','Diagnostic worker rejected job','Diagnostics are running sequentially']) or not r['isolatedDiagnosticCommit']:r['outcome']='diagnostic-fallback'
  finally:pkg.write_bytes(savedPkg);filelist.write_bytes(savedList);library.write_bytes(savedLibrary)
  r.update(cell,index=i);f.write(json.dumps(r,separators=(',',':'))+'\n');f.flush();assert r['outcome']=='success',(cell,r.get('error'))
  if (i+1)%30==0:print('fallback',i+1,'/',len(schedule),flush=True)
print('Fallback/invalidation timing completed',flush=True)
