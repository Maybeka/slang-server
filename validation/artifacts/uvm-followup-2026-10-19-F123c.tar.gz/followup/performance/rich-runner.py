def run(cell):
 case=e.CASES[cell['case']];project=e.PROJECTS[case['project']];folder=p/project['root'];cfg=folder/'.slang/server.json';saved=cfg.read_bytes();cfg.write_text(json.dumps(e.configuration(project,dict(enabled=False,prefix=arms[cell['arm']][1]))));original=(folder/case['target']).read_bytes().decode();uri=(folder/case['target']).as_uri();previous=original;client=None;rows=[];started=time.perf_counter_ns()
 try:
  client=e.EvalClient(binaries[cell['arm']],folder)
  for name in case['extraOpen']:
   file=folder/name;client.notify('textDocument/didOpen',dict(textDocument=dict(uri=file.as_uri(),version=1,languageId='systemverilog',text=file.read_bytes().decode())))
  for i,s in enumerate(case['states']):
   text=e.transform(original,s['operations']);version=i+1;notices=[dict(method='textDocument/didOpen',params=dict(textDocument=dict(uri=uri,version=version,languageId='systemverilog',text=text)))] if i==0 else [e.range_change(uri,version,previous,text,case.get('positionEncoding','utf-16'))]
   items,begin,end=client.rpc('textDocument/completion',e.params(uri,text,s['completion']),notices);envelope={k:v for k,v in items.items() if k!='items'} if isinstance(items,dict) else None;items=items['items'] if isinstance(items,dict) else items;assert items and any(x['label']==s['completion']['token'] for x in items)
   requests=[];last=end
   for item in items:
    value,b,z=client.rpc('completionItem/resolve',item);assert value['label']==item['label'];requests.append(dict(kind=item.get('kind'),label=item['label'],ms=(z-b)/1e6));last=z
   message,diag=e.diag_wait(client,uri,version);assert any(d.get('severity')==1 for d in message['params']['diagnostics'])==s['expectError'];step=dict(step=i,primaryMs=(end-begin)/1e6,primaryBeginNs=begin,primaryEndNs=end,completionEnvelope=envelope,resolveCount=len(requests),resolveSumMs=sum(x['ms'] for x in requests),indexedKindResolveSumMs=sum(x['ms'] for x in requests if x['kind'] in (9,21)),lastResolveNs=last,diagnosticNs=diag,diagnosticFromEditMs=(diag-begin)/1e6,requests=requests);rows.append(step);previous=text
  stderr=(folder/'server.stderr').read_text(errors='replace');assert all(x not in stderr for x in ['Using sequential diagnostics','Diagnostic worker rejected job','Diagnostics are running sequentially']) and 'Committed isolated diagnostic snapshot' in stderr
  return dict(outcome='success',rows=rows,coldFirstPrimaryMs=(rows[0]['primaryEndNs']-started)/1e6,firstStageResolveMs=rows[0]['resolveSumMs'],firstEditResolveMs=rows[1]['resolveSumMs'],allResolveSumMs=sum(x['resolveSumMs'] for x in rows),editResolveSumMs=sum(x['resolveSumMs'] for x in rows[1:]),editPrimarySumMs=sum(x['primaryMs'] for x in rows[1:]),coldToFinalDiagnosticMs=(rows[-1]['diagnosticNs']-started)/1e6,coldToAllQueriesAndDiagnosticsMs=(max(rows[-1]['diagnosticNs'],rows[-1]['lastResolveNs'])-started)/1e6)
 except Exception as error:return dict(outcome='error',error=repr(error),traceback=traceback.format_exc(),rows=rows)
 finally:
  if client:
   try:client.close()
   except Exception:client.process.kill();client.process.wait()
  cfg.write_bytes(saved)
