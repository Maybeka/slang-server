from pathlib import Path
import ast,copy,hashlib,json,random,statistics,sys,os,time,traceback,threading
home=Path(__file__).resolve().parent;p=home.parent/'uvm-engineering-2026-10-19';out=home/'performance'
sys.path.insert(0,str(home.parent/'full-performance-2026-10-19'));import evaluate as e
e.out=p;base=e.configuration
for key in os.environ:assert not key.startswith('SLANG_UVM_'),key
def configuration(project,cell):
 cfg=base(project,cell);cfg['experimentalUvmPrefixCache']=cell.get('prefix',False);return cfg
e.configuration=configuration
arms={'old-on':(p/'product-next/slang-server-v4',True),'new-on':(home/'slang-server-F123c',True),'new-off':(home/'slang-server-F123c',False)}
binaries={a:b for a,(b,_) in arms.items()};binary=home/'slang-server-F123c'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def plan(name,schedule,scope,**extra):
 value=dict(scope=scope,schedule=schedule,binaries={a:dict(path=str(b),sha256=sha(b),prefix=f) for a,(b,f) in arms.items()},driverSha256=sha(Path(__file__)),helperSha256=sha(home.parent/'full-performance-2026-10-19/evaluate.py'),catalogSha256=sha(p/'workloads.json'),projectsSha256=sha(p/'projects.json'),**extra)
 with (out/(name+'-plan.json')).open('x') as f:json.dump(value,f,indent=2)
 for project in e.PROJECTS.values():
  for name,h in project['files'].items():assert sha(p/project['root']/name)==h,name
 return value
def guard(cell,r):
 log=(p/e.PROJECTS[e.CASES[cell['case']]['project']]['root']/'server.stderr').read_text(errors='replace')
 r['isolatedDiagnosticCommit']='Committed isolated diagnostic snapshot' in log
 if not r['isolatedDiagnosticCommit'] or any(x in log for x in ['Using sequential diagnostics','Diagnostic worker rejected job','Diagnostics are running sequentially']):r['outcome']='diagnostic-fallback'
 return r
scope='Fresh sequential processes, unchanged fixed corpus; mirrored shuffled 3-arm blocks n20 per arm/cell. All outliers/failures retained without replacement. No trace/status/sampler or concurrent compilation/tests. Warm filesystem; cold includes process/startup/first query. p95 descriptive only.'

import memory as m
schedule=[]
for rep in range(3):
 for case in ['W13-continuous','W07-pss-multidoc','W08-ubus-task']:
  for method in ['completion','definition']:
   order=list(arms)
   if rep%2:order.reverse()
   for a in order:schedule.append(dict(stage='short',rep=rep,case=case,method=method,arm=a,diagnostics='drained',cycles=None))
for case in ['W13-continuous','W07-pss-multidoc','W08-ubus-task']:
 for a in arms:schedule.append(dict(stage='long-burst',rep=0,case=case,method='completion',arm=a,diagnostics='burst',cycles=1000))
 for a in arms:schedule.append(dict(stage='long-drained',rep=0,case=case,method='definition',arm=a,diagnostics='drained',cycles=500))
 for a in ['new-on']:schedule.append(dict(stage='idle',rep=0,case=case,method='definition',arm=a,diagnostics='drained',cycles=None))
evidence=plan('memory',schedule,'Separate libproc 20ms RSS runs, no latency conclusions. Short n3; long n1; parent+family peaks, shared pages counted multiple times and 20ms peaks can be missed. 1000 completion burst / 500 definition drained edits. 3 final+6s idle marks demonstrate worker eviction. No general RSS bound.')
with (out/'memory.jsonl').open('x') as f:
 for i,c in enumerate(schedule):
  b,prefix=arms[c['arm']];sampler=m.Sampler()
  def observe(client,step):
   sampler.observe(client,step);last=c['cycles']+1 if c['cycles'] is not None else len(e.CASES[c['case']]['states'])
   if step==last:
    sampler.marks.append(dict(step=step,phase='final',serverPid=client.process.pid,seconds=time.monotonic()-sampler.started,rss=m.rss(client.process.pid)))
    if c['stage']=='idle':
     time.sleep(6);sampler.marks.append(dict(step=step,phase='idle6s',serverPid=client.process.pid,seconds=time.monotonic()-sampler.started,rss=m.rss(client.process.pid)))
  thread=threading.Thread(target=sampler.loop);thread.start()
  try:r=guard(c,e.run(dict(case=c['case'],method=c['method'],prefix=prefix,enabled=False,diagnostics=c['diagnostics']),binary=b,status=False,observer=observe,cycles=c['cycles']))
  finally:sampler.stop.set();thread.join()
  if sampler.limit:r['outcome']='budget-exceeded'
  r.update(c,index=i,memory=dict(intervalMs=20,samples=sampler.samples,marks=sampler.marks,peakFamilyRss=max(x['familyRss'] for x in sampler.samples),limit=sampler.limit));f.write(json.dumps(r,separators=(',',':'))+'\n');f.flush();print('memory',i+1,len(schedule),c['stage'],c['case'],c['arm'],r['outcome'],flush=True);assert r['outcome'] in ('success','budget-exceeded'),r.get('error')
