from pathlib import Path
import collections,hashlib,json,math,random,statistics
p=Path(__file__).resolve().parent;out=p/'performance';rng=random.Random(2026101945)
def stats(v):
 v=sorted(v);assert v
 return dict(n=len(v),p50=statistics.median(v),mean=statistics.mean(v),p95=v[math.ceil(.95*len(v))-1],max=max(v),min=min(v))
def load(name,n):
 rows=[json.loads(x) for x in (out/(name+'.jsonl')).read_text().splitlines()];assert len(rows)==n,(name,len(rows));assert all(r['outcome']=='success' for r in rows),(name,collections.Counter(r['outcome'] for r in rows));return rows
def cold(r):
 a,b=r['rows'][0],r['rows'][-1];start=a['primaryEndNs']-a['startupThroughFirstResponseMs']*1e6
 r['coldFirstMs']=a['startupThroughFirstResponseMs'];r['coldToFinalDiagnosticMs']=(b['primaryBeginNs']+b['diagnosticFromEditMs']*1e6-start)/1e6
 r['firstDiagnosticMs']=a['diagnosticFromEditMs'];r['firstEditDiagnosticMs']=r['rows'][1].get('diagnosticFromEditMs')
def summarize(rows,keys,metrics,arms):
 groups=collections.defaultdict(list)
 for r in rows:groups[tuple(r[k] for k in keys)].append(r)
 result=[]
 for k,rs in sorted(groups.items()):
  item=dict(zip(keys,k));item['arms']={a:{m:stats([r[m] for r in rs if r['arm']==a]) for m in metrics} for a in arms};item['paired']={}
  for baseline in [a for a in arms if a!='new-on']:
   candidate='new-on' if 'new-on' in arms else 'reuse'
   if baseline==candidate:continue
   comparisons={}
   for m in metrics:
    blocks=sorted({r['block'] for r in rs});ds=[statistics.mean(r[m] for r in rs if r['block']==b and r['arm']==candidate)-statistics.mean(r[m] for r in rs if r['block']==b and r['arm']==baseline) for b in blocks]
    boot=sorted(statistics.mean(rng.choices(ds,k=len(ds))) for _ in range(4000));comparisons[m]=dict(blocks=len(ds),meanDifferenceMs=statistics.mean(ds),bootstrap95Ms=[boot[99],boot[3899]])
   item['paired'][baseline]=comparisons
  result.append(item)
 return result
basic=load('timing',600)
for r in basic:cold(r)
rich=load('rich',360);fallback=load('fallback',360)
for r in fallback:cold(r)
component=load('component',48)
# Independent component contrast uses the same complete-block estimator.
for r in component:cold(r)
componentGroups=[]
for case in sorted({r['case'] for r in component}):
 rs=[r for r in component if r['case']==case];row=dict(case=case,arms={a:{m:stats([r[m] for r in rs if r['arm']==a]) for m in ['firstEditMs','sequenceWithDiagnosticsMs','coldToFinalDiagnosticMs']} for a in ['reuse','persistent-native']});componentGroups.append(row)
long=load('long',27);longGroups=[]
for case in sorted({r['case'] for r in long}):
 for arm in ['old-on','new-on','new-off']:
  rs=[r for r in long if r['case']==case and r['arm']==arm];sessions=[]
  for r in rs:
   cold(r);bounds=set(r['retirementSteps']);edits=r['rows'][1:];sessions.append(dict(rep=r['rep'],retirements=len(bounds),retirementSteps=sorted(bounds),allEditsMs=stats([x['primaryMs'] for x in edits]),retirementMs=stats([r['rows'][i]['primaryMs'] for i in bounds]) if bounds else None,ordinaryMs=stats([x['primaryMs'] for i,x in enumerate(r['rows']) if i and i not in bounds]),editResponseSumMs=r['editResponseSumMs'],coldToFinalDiagnosticMs=r['coldToFinalDiagnosticMs']))
  longGroups.append(dict(case=case,arm=arm,sessions=sessions))
memory=load('memory',75);memGroups=[]
for r in memory:
 m=r['memory'];pid=str(r['serverPid']);final=next(x for x in m['marks'] if x.get('phase')=='final');r['peakFamilyMiB']=m['peakFamilyRss']/2**20;r['peakParentMiB']=max(x['pids'].get(pid) or 0 for x in m['samples'])/2**20;r['finalParentMiB']=final['rss']/2**20
 near=min(m['samples'],key=lambda x:abs(x['seconds']-final['seconds']));r['finalFamilyMiB']=near['familyRss']/2**20;r['finalFamilySampleDeltaMs']=(near['seconds']-final['seconds'])*1000
 for mark in m['marks']:
  if mark.get('phase')=='idle6s':
   near=min(m['samples'],key=lambda x:abs(x['seconds']-mark['seconds']));r['idleParentMiB']=mark['rss']/2**20;r['idleFamilyMiB']=near['familyRss']/2**20
for stage,case,method in sorted({(r['stage'],r['case'],r['method']) for r in memory}):
 rs=[r for r in memory if (r['stage'],r['case'],r['method'])==(stage,case,method)];metrics=['peakFamilyMiB','peakParentMiB','finalParentMiB','finalFamilyMiB']+(['idleParentMiB','idleFamilyMiB'] if stage=='idle' else [])
 memGroups.append(dict(stage=stage,case=case,method=method,arms={a:{m:stats([r[m] for r in rs if r['arm']==a]) for m in metrics} for a in sorted({r['arm'] for r in rs})}))
report=dict(candidate=json.loads((p/'candidate-F123c.json').read_text()),counts=dict(timing=600,rich=360,fallback=360,long=27,memory=75,component=48,pilot=64,totalFinalCandidateComparative=1470,allResolveResponses=sum(sum(s['resolveCount'] for s in r['rows']) for r in rich)),primary=summarize(basic,['stage','case','method'],['coldFirstMs','firstEditMs','editResponseSumMs','coldToFinalDiagnosticMs','recoveryMs','firstDiagnosticMs','cachedRepeatSumMs','resolveSumMs'],['old-on','new-on','new-off']),rich=summarize(rich,['case'],['coldFirstPrimaryMs','firstStageResolveMs','firstEditResolveMs','allResolveSumMs','editResolveSumMs','editPrimarySumMs','coldToFinalDiagnosticMs','coldToAllQueriesAndDiagnosticsMs'],['old-on','new-on','new-off']),fallback=summarize(fallback,['variant'],['coldFirstMs','firstEditMs','editResponseSumMs','coldToFinalDiagnosticMs','recoveryMs'],['old-on','new-on','new-off']),component=componentGroups,long=longGroups,memory=memGroups,inference='n20 per ordinary arm/cell in 10 mirrored six-process shuffled blocks. Bootstrap resamples 10 block mean differences, new-on minus comparator, 4000 draws; exploratory multiple comparisons without correction, not median/tail bounds. Component n8; short memory n3, long memory n1. Memory 20ms family RSS sums shared pages repeatedly, may miss peaks; memory-run latency excluded. Filesystem warm, fresh processes, all failures/outliers retained without replacement.')
(out/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')
for r in report['primary']:
 print(r['stage'],r['case'],r['method'],{a:{m:round(r['arms'][a][m]['p50'],2) for m in ['coldFirstMs','firstEditMs','coldToFinalDiagnosticMs']} for a in ['old-on','new-on','new-off']})
print('all measurements analyzed')
