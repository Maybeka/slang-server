from pathlib import Path
import hashlib,json,subprocess
p=Path(__file__).resolve().parent;s=p.parent.parent/'source';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
candidate=json.loads((p/'candidate-F123c.json').read_text());assert sha(Path(candidate['binary']))==candidate['sha256']
manifest=json.loads((s/'restoration/main-sdk.json').read_text());assert sha(s/'restoration/slang.patch')==manifest['patch_sha256']
for name,h in manifest['files'].items():assert sha(s/'external/slang'/name)==h,name
for folder in [s,s/'external/slang']:subprocess.run(['git','diff','--check'],cwd=folder,check=True)
files=subprocess.check_output(['git','ls-files','src','include','tests','CMakeLists.txt','cmake','restoration'],cwd=s,text=True).splitlines();files.append('include/util/UvmPhaseTrace.h');files=sorted(set(f for f in files if (s/f).is_file()))
source={f:sha(s/f) for f in files}
record=dict(candidateSha256=candidate['sha256'],sdkFilesVerified=len(manifest['files']),restorationPatchSha256=manifest['patch_sha256'],sourceFiles=source,compiler=subprocess.check_output(['/opt/homebrew/opt/llvm/bin/clang++','--version'],text=True),buildType='Release',sdkTestsEnabled=True,scope='Final source/static/hash audit after full acceptance and measurements. No C++ source changes after candidate freeze; only documentation/evidence added. Source includes separately preserved dirty SDK via restoration manifest.')
(p/'final-audit.json').write_text(json.dumps(record,indent=2)+'\n');print('final static source/SDK/binary audit passed',len(files),'source files')
