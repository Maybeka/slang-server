"""Readiness replay. Instrumentation/extra queries make these non-benchmark runs."""
from pathlib import Path
import copy,hashlib,json,re,sys,time,traceback
from urllib.parse import urlparse,unquote
out=Path(__file__).resolve().parent;task=out.parent.parent
sys.path.insert(0,str(task/'source/tests/method_scope'))
from protocol import Client

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def position(text,offset,encoding="utf-16"):
    start=text.rfind('\n',0,offset)+1
    return dict(line=text.count('\n',0,offset),character=len(text[start:offset].encode('utf-8')) if encoding=='utf-8' else len(text[start:offset].encode('utf-16-le'))//2)
def scope_range(text,scope):
    if not scope:return 0,len(text)
    assert text.count(scope)==1,(scope,'ambiguous scope')
    begin=text.index(scope);end=text.index('endclass' if scope.startswith('class ') else 'endfunction',begin)
    return begin,end

def transform(original,operations):
    text=original
    for op in operations:
        if 'lineEndings' in op:
            assert op['lineEndings']=='CRLF';text=text.replace('\r\n','\n').replace('\n','\r\n');continue
        a,b=scope_range(text,op.get('scope'));part=text[a:b]
        assert op['old'] in part,op
        if not op.get('scope'):assert part.count(op['old'])==1,op
        text=text[:a]+part.replace(op['old'],op['new'])+text[b:]
    return text

def token_range(text,spec):
    a,b=scope_range(text,spec.get('scope'));part=text[a:b];assert part.count(spec['anchor'])==1,spec
    anchor_start=a+part.index(spec['anchor']);matches=list(re.finditer(r'(?<!\w)'+re.escape(spec['token'])+r'(?!\w)',spec['anchor']))
    assert matches,spec;match=matches[-1] if spec.get('last') else matches[0]
    return anchor_start+match.start(),anchor_start+match.end()

def params(uri,text,spec,encoding="utf-16"):
    a,b=token_range(text,spec)
    return dict(textDocument=dict(uri=uri),position=position(text,a+max(1,(b-a)//2),encoding))

class EncodingClient(Client):
    def __init__(self,*args,encoding='utf-16',**kwargs):
        self.encoding=encoding
        super().__init__(*args,**kwargs)
    def send(self,messages):
        messages=copy.deepcopy(messages)
        if self.encoding=='utf-8':
            for m in messages:
                if m.get('method')=='initialize':m['params']['capabilities']['general']={'positionEncodings':['utf-8']}
        return super().send(messages)
    def request(self,method,params,changes=()):
        result=super().request(method,params,changes)
        if method=='initialize':
            assert result[0]['capabilities'].get('positionEncoding','utf-16')==self.encoding
        return result

def range_change(uri,version,old,new,encoding):
    a=0
    while a<min(len(old),len(new)) and old[a]==new[a]:a+=1
    suffix=0
    while suffix<min(len(old)-a,len(new)-a) and old[len(old)-1-suffix]==new[len(new)-1-suffix]:suffix+=1
    # LSP positions cannot address the middle of a CRLF line ending.
    while a>0 and (old[a-1:a+1]=='\r\n' or new[a-1:a+1]=='\r\n'):a-=1
    while suffix>0 and (old[len(old)-suffix-1:len(old)-suffix+1]=='\r\n' or new[len(new)-suffix-1:len(new)-suffix+1]=='\r\n'):suffix-=1
    end=len(old)-suffix
    return {'method':'textDocument/didChange','params':{'textDocument':{'uri':uri,'version':version},'contentChanges':[{'range':{'start':position(old,a,encoding),'end':position(old,end,encoding)},'text':new[a:len(new)-suffix]}]}}

class Normalizer:
    def __init__(self,state,open_texts):
        self.sources={x['buffer']:x for x in state['sources']};self.docs={x['uri']:x for x in state['documents']};self.open_texts=open_texts;self.ids={};self.opaque=set()
    def identity(self,id):
        if id in self.ids:return self.ids[id]
        w=self.sources.get(id)
        if w is None:self.opaque.add(id);return id
        assert w['latest'],('stale physical source',id,w['uri'])
        if w['uri'] in self.docs:
            expected=self.open_texts[w['uri']];version=self.docs[w['uri']]['version']
        else:
            expected=Path(unquote(urlparse(w['uri']).path)).read_bytes().decode();version='disk'
        assert w['bytes']==expected+'\0',('bytes differ',w['uri'])
        result='source:'+w['uri']+':'+str(version)+':'+hashlib.sha256(expected.encode()).hexdigest();self.ids[id]=result;return result
    def value(self,item):
        if isinstance(item,dict):
            result={k:self.value(v) for k,v in item.items()}
            if {'bufferId','documentUri','symbolName'}<=item.keys():
                result['bufferId']=self.identity(item['bufferId'])
                if item.get('receiverBufferId') is not None:result['receiverBufferId']=self.identity(item['receiverBufferId'])
            return result
        if isinstance(item,list):return [self.value(v) for v in item]
        return item

def run(case,project,binary,enabled):
    root=out/project['root'];config=root/'.slang/server.json';saved=config.read_bytes();cfg=json.loads(saved);cfg['experimentalMethodScopeOverlay']=enabled;config.write_text(json.dumps(cfg))
    target=root/case['target'];original=target.read_bytes().decode();uri=target.as_uri();client=None;rows=[];started=time.monotonic();open_texts={};encoding=case.get('positionEncoding','utf-16');previous=original
    try:
        client=EncodingClient(binary,root,encoding=encoding)
        for name in case['extraOpen']:
            p=root/name;u=p.as_uri();t=p.read_bytes().decode();open_texts[u]=t
            client.notify('textDocument/didOpen',dict(textDocument=dict(uri=u,version=1,languageId='systemverilog',text=t)))
        for index,s in enumerate(case['states']):
            text=transform(original,s['operations']);version=index+1;open_texts[uri]=text
            notifications=[dict(method='textDocument/didOpen',params=dict(textDocument=dict(uri=uri,version=1,languageId='systemverilog',text=text)))] if index==0 else [range_change(uri,version,previous,text,encoding)]
            dp=params(uri,text,s['query'],encoding);cp=params(uri,text,s['completion'],encoding)
            links,_=client.request('textDocument/definition',dp,notifications)
            items,_=client.request('textDocument/completion',cp)
            assert items,('empty completion',s['id'])
            label=s['completion']['token'];assert any(i['label']==label for i in items),('missing completion',s['id'],label,[i['label'] for i in items][:20])
            if s['declaration']:
                a,b=token_range(text,s['declaration']);expected=dict(start=position(text,a,encoding),end=position(text,b,encoding))
                assert len(links)==1 and links[0]['targetUri']==uri and links[0]['targetSelectionRange']==expected,('wrong definition',s['id'],expected,links)
            selected=sorted({0,len(items)-1,*[i for i,x in enumerate(items) if x['label']==label]})
            resolved=[client.request('completionItem/resolve',items[i])[0] for i in selected]
            diag,_=client.wait(lambda m:m.get('method')=='textDocument/publishDiagnostics' and m['params'].get('uri')==uri and m['params'].get('version')==version)
            diagnostics=diag['params']['diagnostics'];has_error=any(d.get('severity')==1 for d in diagnostics)
            assert has_error==s['expectError'],('unexpected diagnostics',s['id'],diagnostics)
            state=client.state();assert state.get('parserUnits') is None
            n=Normalizer(state,open_texts)
            row=dict(state=s['id'],version=version,textSha256=hashlib.sha256(text.encode()).hexdigest(),textBytes=len(text.encode()),definition=n.value(links),completion=n.value(items),selectedResolveIndices=selected,resolved=n.value(resolved),diagnostics=diagnostics,status={k:state[k] for k in ('active','accepted','decline')})
            # Same-generation repeated requests must preserve the full ordered result.
            repeat,_=client.request('textDocument/completion',cp);assert n.value(repeat)==row['completion'],('no-edit repeat changed',s['id'])
            row.update(physicalWitnesses=len(n.ids),opaqueHandlesComparedExactly=len(n.opaque),noEditRepeatEqual=True);rows.append(row);previous=text
        return dict(enabled=enabled,outcome='success',elapsedSeconds=time.monotonic()-started,rows=rows)
    except Exception as error:
        return dict(enabled=enabled,outcome='error',error=repr(error),traceback=traceback.format_exc(),elapsedSeconds=time.monotonic()-started,rows=rows)
    finally:
        if client:
            try:client.close()
            except Exception:client.process.kill()
        config.write_bytes(saved)

def main():
    output=out/(sys.argv[1] if len(sys.argv)>1 else 'readiness-v1.json');assert not output.exists()
    catalog=json.loads((out/'workloads.json').read_text());projects={p['id']:p for p in json.loads((out/'projects.json').read_text())};binary=task/'build/bin/slang-server'
    assert sha(binary)=='83ee074544b350b523d4c2d63782d213312a8e46963e097f02e7f36390ffe44b'
    report=dict(schema=1,catalogSha256=sha(out/'workloads.json'),driverSha256=sha(Path(__file__)),binarySha256=sha(binary),purpose='readiness, extra probes and selected resolves; no performance inference',results=[])
    for c in catalog['cases']:
        project=projects[c['project']]
        for name,expected in project['files'].items():assert sha(out/project['root']/name)==expected,(c['id'],name)
        results=[run(c,project,binary,enabled) for enabled in (False,True)]
        equal=None
        if all(r['outcome']=='success' for r in results):
            def bodies(r):return [{k:v for k,v in x.items() if k not in ('status','physicalWitnesses','opaqueHandlesComparedExactly')} for x in r['rows']]
            equal=bodies(results[0])==bodies(results[1])
        report['results'].append(dict(case=c['id'],project=c['project'],nativeEqualsExperimental=equal,runs=results))
        output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(c['id'],[r['outcome'] for r in results],'equal',equal,flush=True)
    report['summary']=dict(cases=len(report['results']),successfulBoth=sum(x['nativeEqualsExperimental'] is True for x in report['results']),failedOrDifferent=[x['case'] for x in report['results'] if x['nativeEqualsExperimental'] is not True]);output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
if __name__=='__main__':main()
