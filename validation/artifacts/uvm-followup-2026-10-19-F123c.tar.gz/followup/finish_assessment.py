from pathlib import Path
import json,time,subprocess,sys
p=Path(__file__).resolve().parent
while True:
 try:stages=json.loads((p/'measurement-stages.json').read_text())
 except (FileNotFoundError,json.JSONDecodeError):stages=[]
 if any(x['returncode'] for x in stages):raise SystemExit('measurement stage failed')
 if stages and stages[-1]['stage']=='memory':break
 time.sleep(1)
assert len(stages)==5
c=p/'candidate-F123c.json';candidate=json.loads(c.read_text());candidate['status']='Final frozen candidate; full correctness and all preregistered comparative measurement stages succeeded';c.write_text(json.dumps(candidate,indent=2)+'\n')
for script in ['measure_phases.py','final_audit.py','analyze_measurements.py','publish_evidence.py','write_report.py']:
 print('START',script,flush=True)
 with (p/(script+'.log')).open('w') as f:r=subprocess.run([sys.executable,str(p/script)],stdout=f,stderr=subprocess.STDOUT)
 print('END',script,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
print('Assessment evidence generated; human-facing conclusion review and main publication remain',flush=True)
