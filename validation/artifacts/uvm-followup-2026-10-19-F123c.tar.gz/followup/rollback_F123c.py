from pathlib import Path
import copy,json,sys
p=Path('/Users/xn/Documents/Codex/2026-10-19/handoff-md-package-include/untracked/uvm-engineering-2026-10-19');q=p/'product-next';out=Path('/Users/xn/Documents/Codex/2026-10-19/handoff-md-package-include/untracked/uvm-followup-2026-10-19/replacement-failure-F123c');out.mkdir(exist_ok=True);sys.path.insert(0,str(p.parent/'uvm-prefix-prototype-2026-10-19/v5'));import oracle as o

_originalComparable=o.comparable
def _semanticComparable(result):
 return [dict(row,diagnostics=sorted(row['diagnostics'],key=lambda d:__import__('json').dumps(d,sort_keys=True))) for row in _originalComparable(result)]
o.comparable=_semanticComparable
o.p=q;o.e.out=q;e=o.e;Parent=o.OracleClient;caseName=''
class Client(Parent):
 def __init__(self,*args,**kwargs):
  env=kwargs.get('extra_env',{}).copy();enabled='SLANG_SERVER_UVM_PREFIX_CACHE' in env;cfg=args[1]/'.slang/server.json';value=json.loads(cfg.read_text());value['experimentalUvmPrefixCache']=enabled;cfg.write_text(json.dumps(value))
  if enabled:env.update(SLANG_UVM_GENERATION_EDIT_LIMIT='1',SLANG_UVM_GENERATION_TRACE=str(out/f'{caseName}.tsv'))
  kwargs['extra_env']=env;super().__init__(*args,**kwargs)
o.OracleClient=Client;report=[];assert not (out/'results.json').exists()
for caseName in ('W01-compare','W07-pss-multidoc','W08-ubus-task'):
 case=copy.deepcopy(e.CASES[caseName]);case['states'].append(copy.deepcopy(case['states'][1]));case['states'][-1]['id']='after-replacement-recovers';folder=q/e.PROJECTS[case['project']]['root'];file=folder/'design.f';saved=file.read_bytes()
 def hook(client,i,root):
  if i==0:file.write_text('deliberately_missing_replacement_source.sv\n')
  if i==2:file.write_bytes(saved)
 rows=[]
 for flag,binary in [(False,e.BINARY),(True,Path('/Users/xn/Documents/Codex/2026-10-19/handoff-md-package-include/untracked/uvm-followup-2026-10-19/slang-server-F123c'))]:
  try:rows.append(o.run(case,binary,flag,False,hook))
  finally:file.write_bytes(saved)
 a,b=rows;trace=(out/f'{caseName}.tsv').read_text();equal=a['outcome']==b['outcome']=='success' and o.comparable(a)==o.comparable(b);stale=o.public(a.get('staleResolves'))==o.public(b.get('staleResolves'));report.append(dict(case=caseName,native=a,prototype=b,equal=equal,staleEqual=stale,trace=trace));(out/'results.json').write_text(json.dumps(report,separators=(',',':'))+'\n');print('rollback',caseName,a['outcome'],b['outcome'],equal,stale,flush=True);assert equal and stale,(a.get('error'),b.get('error'));assert '\treplacement-failed\t' in trace and '\tretired\t' in trace
