from pathlib import Path
import subprocess,json,os,sys
p=Path(__file__).resolve().parent;root=p.parent.parent;out=p/'product-next';kind=sys.argv[1];tag=sys.argv[2];assert kind in ('server','sdk');tmp=out/'test-tmp';tmp.mkdir(exist_ok=True);log=out/f'{kind}-tests-{tag}.log';assert not log.exists();binary=root/'build-uvm/bin'/('server_unittests' if kind=='server' else 'unittests');cwd=root/'source' if kind=='server' else root/'build-uvm/external/slang/tests/unittests'
with log.open('w') as f:r=subprocess.run([str(binary),*sys.argv[3:]],cwd=cwd,env=dict(os.environ,TMPDIR=str(tmp)),stdout=f,stderr=subprocess.STDOUT)
(out/f'{kind}-tests-{tag}.json').write_text(json.dumps(dict(returncode=r.returncode,cwd=str(cwd),filters=sys.argv[3:]),indent=2)+'\n');print(kind,tag,r.returncode,flush=True);raise SystemExit(r.returncode)
