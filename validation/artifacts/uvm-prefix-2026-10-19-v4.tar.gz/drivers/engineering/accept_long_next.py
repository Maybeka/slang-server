from pathlib import Path
import hashlib,json,os,subprocess,time
p=Path(__file__).resolve().parent;root=p.parent.parent;q=p/'product-next';python=root/'source/.venv/bin/python';binary=q/'slang-server-v4';expected=json.loads((q/'candidate-v4.json').read_text())['sha256'];stages=[];path=q/'long-acceptance-progress.json';assert not path.exists()
for i,(name,script) in enumerate([('fallback and invalidation','fallback_next.py'),('long ordinary latency','long_latency_next.py'),('separate memory','memory_next.py')]):
 assert hashlib.sha256(binary.read_bytes()).hexdigest()==expected
 print('START',name,flush=True);start=time.monotonic();log=q/f'long-accept-{i}.log'
 with log.open('w') as f:r=subprocess.run([str(python),str(p/script)],cwd=root,stdout=f,stderr=subprocess.STDOUT)
 stages.append(dict(name=name,returncode=r.returncode,seconds=time.monotonic()-start,log=str(log)));path.write_text(json.dumps(dict(candidateSha256=expected,status='running' if r.returncode==0 else 'failed',stages=stages),indent=2)+'\n');print('END',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
path.write_text(json.dumps(dict(candidateSha256=expected,status='all measurement stages complete; analysis and final audit pending',stages=stages),indent=2)+'\n')
