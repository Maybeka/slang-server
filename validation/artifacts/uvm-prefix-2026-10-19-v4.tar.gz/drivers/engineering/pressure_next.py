from pathlib import Path
import json,sys,time
p=Path(__file__).resolve().parent;out=p/'product-next';folder=out/'pressure-project';folder.mkdir(exist_ok=True);(folder/'.slang').mkdir(exist_ok=True);(folder/'.slang/server.json').write_text(json.dumps(dict(indexGlobs=['*.sv'],indexingThreads=1,flags='--threads 1',experimentalMethodScopeOverlay=False)))
for i in range(65):(folder/f'pcache{i:02}.sv').write_text(f'module pcache{i:02}; endmodule\n')
(folder/'query.sv').write_text('// index resolve context\n')
big=folder/'pcache_big.sv'
if not big.exists():big.write_bytes(b' '*(65*1024*1024)+b'module pcache_big; endmodule\n')
sys.path.insert(0,str(p.parent/'full-performance-2026-10-19'));import evaluate as e
results=[];assert not (out/'pressure.json').exists()
for arm,binary in [('baseline',out/'slang-server-v4'),('candidate',out/'slang-server-v4')]:
 env={'SLANG_SERVER_UVM_PREFIX_CACHE':'1'}
 if arm=='candidate':env['SLANG_UVM_RESOLVE_CACHE_TRACE']=str(out/'pressure-cache.tsv')
 cfg=json.loads((folder/'.slang/server.json').read_text());cfg['experimentalUvmPrefixCache']=arm=='candidate';(folder/'.slang/server.json').write_text(json.dumps(cfg))
 client=e.EvalClient(binary,folder,extra_env=env);items=[]
 try:
  deadline=time.monotonic()+30
  while True:
   found,_,_=client.rpc('workspace/symbol',dict(query='pcache'))
   if len(found)==66:break
   assert time.monotonic()<deadline,('index not ready',len(found));time.sleep(.05)
  names=[f'pcache{i:02}' for i in range(65)]+['pcache00','pcache64','pcache_big','pcache_big']
  for name in names:
   value,_,_=client.rpc('completionItem/resolve',dict(label=name,kind=9,data=(folder/'query.sv').as_uri()));assert value.get('documentation'),name;items.append(value)
  results.append(dict(arm=arm,results=items))
 finally:client.close()
trace=(out/'pressure-cache.tsv').read_text();rows=[x.split('\t') for x in trace.splitlines()];assert results[0]['results']==results[1]['results'];assert sum(r[1]=='miss' and r[-1].endswith('pcache00.sv') for r in rows)==2;assert rows[-3][1]=='hit' and rows[-3][-1].endswith('pcache64.sv');assert [r[1] for r in rows[-2:]]==['oversize','oversize'];assert max(int(r[2]) for r in rows if r[1]!='oversize')<=64*1024*1024
(out/'pressure.json').write_text(json.dumps(dict(equal=True,runs=results,trace=trace,checks=['65 small roots evict LRU at 64 entries','MRU survives eviction','65 MiB root parsed twice and never retained','All native public module resolve payloads identical']),separators=(',',':'))+'\n');print('PASS: 64-entry eviction, 64 MiB oversize bypass, native payload parity',flush=True)
