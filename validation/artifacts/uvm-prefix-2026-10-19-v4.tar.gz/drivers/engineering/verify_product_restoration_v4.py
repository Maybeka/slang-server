from pathlib import Path
import subprocess,tarfile,io,json,hashlib
p=Path(__file__).resolve().parent;root=p.parent.parent;s=root/'source';out=p/'product-integration';folder=out/'restoration-check-v4';assert not folder.exists();folder.mkdir()
archive=subprocess.check_output(['git','-C',str(s/'external/slang'),'archive','HEAD'])
with tarfile.open(fileobj=io.BytesIO(archive)) as t:t.extractall(folder,filter='data')
# git archive applies export-subst; restore literal checkout bytes before testing a checkout patch.
(folder/'.git_archival.txt').write_bytes(subprocess.check_output(['git','-C',str(s/'external/slang'),'show','HEAD:.git_archival.txt']))
r=subprocess.run(['git','apply','--check',str(s/'restoration/slang.patch')],cwd=folder,capture_output=True,text=True);assert r.returncode==0,r.stderr
subprocess.run(['git','apply',str(s/'restoration/slang.patch')],cwd=folder,check=True)
m=json.loads((s/'restoration/main-sdk.json').read_text());bad=[name for name,sha in m['files'].items() if not (folder/name).exists() or hashlib.sha256((folder/name).read_bytes()).hexdigest()!=sha];result=dict(base=m['base_commit'],patchSha256=hashlib.sha256((s/'restoration/slang.patch').read_bytes()).hexdigest(),filesVerified=len(m['files']),mismatches=bad,scope='Fresh SDK git archive, clean patch check and apply, then all retained file hashes; no build/test claim')
(out/'restoration-check-v4.json').write_text(json.dumps(result,indent=2)+'\n');assert not bad,bad;print('Fresh restoration patch applied; verified',len(m['files']),'SDK file hashes')
