from pathlib import Path
import collections,json,math,random,statistics
p=Path(__file__).resolve().parent/'product-next/performance';rng=random.Random(2026101916)
def stats(values):
 s=sorted(values);return dict(n=len(s),p50=statistics.median(s),mean=statistics.mean(s),p95=s[max(0,math.ceil(.95*len(s))-1)],max=max(s))
def summarize(rows,keys,arm,metrics,baseline,candidate):
 groups=collections.defaultdict(list)
 for r in rows:groups[tuple(r[k] for k in keys)].append(r)
 result=[]
 for key,group in sorted(groups.items()):
  row=dict(zip(keys,key));row['arms']={str(a):{m:stats([r[m] for r in group if r[arm]==a]) for m in metrics} for a in [baseline,candidate]};paired={}
  for m in metrics:
   blocks=sorted({r['block'] for r in group});ds=[statistics.mean(r[m] for r in group if r['block']==b and r[arm]==candidate)-statistics.mean(r[m] for r in group if r['block']==b and r[arm]==baseline) for b in blocks];boot=sorted(statistics.mean(rng.choices(ds,k=len(ds))) for _ in range(4000));paired[m]=dict(blocks=len(ds),meanDifferenceMs=statistics.mean(ds),bootstrap95Ms=[boot[99],boot[3899]])
  row['paired']=paired;result.append(row)
 return result
basic=[json.loads(x) for x in (p/'timing-results.jsonl').read_text().splitlines()];assert len(basic)==400 and all(r['outcome']=='success' for r in basic)
for r in basic:
 first,last=r['rows'][0],r['rows'][-1];start=first['primaryEndNs']-first['startupThroughFirstResponseMs']*1e6;r['coldFirstMs']=first['startupThroughFirstResponseMs'];r['coldToFinalDiagnosticMs']=(last['primaryBeginNs']+last['diagnosticFromEditMs']*1e6-start)/1e6
primary=summarize(basic,['stage','case','method'],'cache',['coldFirstMs','firstEditMs','editResponseSumMs','coldToFinalDiagnosticMs','recoveryMs','cachedRepeatSumMs','resolveSumMs'],False,True)
rich=[json.loads(x) for x in (p/'rich-timing-results.jsonl').read_text().splitlines()];assert len(rich)==240 and all(r['outcome']=='success' for r in rich)
resolved=summarize(rich,['case'],'arm',['coldFirstPrimaryMs','firstStageResolveMs','firstEditResolveMs','editResolveSumMs','allResolveSumMs','editPrimarySumMs','coldToFinalDiagnosticMs','coldToAllQueriesAndDiagnosticsMs'],'off','on')
report=dict(candidateSha256=json.loads((p/'timing-plan.json').read_text())['binarySha256'],primaryProcesses=len(basic),allResolveProcesses=len(rich),allResolveResponses=sum(sum(s['resolveCount'] for s in r['rows']) for r in rich),primary=primary,resolve=resolved,inference='n20 each arm/cell, 10 balanced four-process blocks. Bootstrap intervals resample block mean differences, on minus off; descriptive p95 at n20 is not a p99/tail guarantee. Multiple metrics, no multiplicity correction. All failures/outliers kept; no replacements. Positive isolated diagnostics checked. Long sessions/memory separately assessed.')
(p/'latency-analysis.json').write_text(json.dumps(report,indent=2)+'\n')
for r in resolved:print(r['case'],{a:{m:round(r['arms'][a][m]['p50'],2) for m in ['firstStageResolveMs','editResolveSumMs','coldToAllQueriesAndDiagnosticsMs']} for a in ['off','on']})
