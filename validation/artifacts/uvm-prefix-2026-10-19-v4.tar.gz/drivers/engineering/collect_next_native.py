from pathlib import Path
import json,sys,hashlib
p=Path(__file__).resolve().parent;q=p/'product-next';v=p.parent/'uvm-prefix-prototype-2026-10-19/v5';sys.path.insert(0,str(v));import oracle as o
o.p=q;o.e.out=q;e=o.e;dest=q/'native-oracle.json';assert not dest.exists();rows=[]
cases=[c for c in e.CASES.values() if c['id']!='W12-encoding-lines'];cases.append(json.loads((v/'uvm-owned-case.json').read_text()))
for case in cases:
 a=o.run(case,e.BINARY,False,False);rows.append(dict(case=case['id'],native=a));dest.write_text(json.dumps(rows,separators=(',',':'))+'\n');print(case['id'],a['outcome'],flush=True);assert a['outcome']=='success',a.get('error')
(q/'native-reference.json').write_text(json.dumps(dict(binary=str(e.BINARY),sha256=hashlib.sha256(e.BINARY.read_bytes()).hexdigest(),cases=len(rows),scope='Fresh native full-public oracle on isolated source-hash-matched corpus; no latency acceptance'),indent=2)+'\n')
