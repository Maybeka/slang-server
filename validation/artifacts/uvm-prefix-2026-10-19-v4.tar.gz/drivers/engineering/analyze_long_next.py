from pathlib import Path
import collections,json,math,random,statistics
p=Path(__file__).resolve().parent/'product-next/performance'
def stats(values):
 s=sorted(values);return dict(n=len(s),median=statistics.median(s),mean=statistics.mean(s),p95=s[max(0,math.ceil(.95*len(s))-1)],max=max(s))
def load(name):return [json.loads(x) for x in (p/name).read_text().splitlines()]
def cold(r):
 a,b=r['rows'][0],r['rows'][-1];return (b['primaryBeginNs']+b['diagnosticFromEditMs']*1e6-(a['primaryEndNs']-a['startupThroughFirstResponseMs']*1e6))/1e6
fallback=load('fallback.jsonl');assert len(fallback)==240 and all(r['outcome']=='success' for r in fallback);groups=collections.defaultdict(list)
for r in fallback:r['coldToFinalDiagnosticMs']=cold(r);groups[r['variant'],r['prefix']].append(r)
fsummary=[dict(variant=k[0],enabled=k[1],metrics={m:stats([r[m] for r in rows]) for m in ['firstEditMs','editResponseSumMs','recoveryMs','coldToFinalDiagnosticMs']}) for k,rows in sorted(groups.items())]
long=load('long-latency.jsonl');assert len(long)==18 and all(r['outcome']=='success' for r in long);groups=collections.defaultdict(list)
for r in long:r['coldToFinalDiagnosticMs']=cold(r);groups[r['case'],r['prefix']].append(r)
lsummary=[]
for (case,enabled),rows in sorted(groups.items()):
 retirement=[r['rows'][i]['primaryMs'] for r in rows for i in r['retirementSteps']];lsummary.append(dict(case=case,enabled=enabled,processes=len(rows),metrics={m:stats([r[m] for r in rows]) for m in ['editResponseSumMs','coldToFinalDiagnosticMs','sequenceWithDiagnosticsMs']},perProcessPrimary=[stats([x['primaryMs'] for x in r['rows'][1:]]) for r in rows],retirementCounts=[len(r['retirementSteps']) for r in rows],retirementPrimaryMs=stats(retirement) if retirement else None))
memory=load('memory.jsonl');assert len(memory)==len(json.loads((p/'memory-plan.json').read_text())['schedule']);groups=collections.defaultdict(list)
for r in memory:groups[r['stage'],r['case'],r['method'],r['arm']].append(r)
msummary=[]
for key,rows in sorted(groups.items()):
 ends=[r['memory']['marks'][-1]['rss']/2**20 for r in rows if r['memory']['marks'] and r['memory']['marks'][-1]['rss'] is not None];msummary.append(dict(stage=key[0],case=key[1],method=key[2],arm=key[3],outcomes=dict(collections.Counter(r['outcome'] for r in rows)),peakFamilyMiB=stats([r['memory']['peakFamilyRss']/2**20 for r in rows]),endParentMiB=stats(ends) if ends else None,retirementCounts=[sum(len(x['events']) for x in r['retirements']) for r in rows],retiredParentMiB=[[x['rss']/2**20 for x in r['retirements'] if x['rss'] is not None] for r in rows]))
report=dict(fallbackProcesses=len(fallback),fallback=fsummary,longLatencyProcesses=len(long),longLatency=lsummary,memoryProcesses=len(memory),memory=msummary,limits='Fallback n20 each arm/variant. Long ordinary latency n3 each arm/case; retirement p95/max descriptive over actual epochs returned in ordinary completion data. Sampled memory 20ms may miss peaks and family RSS double-counts shared pages; short n3 and long n1 per arm. Budget-exceeded runs retained. No unlimited-session or arbitrary-workload RSS guarantee.')
(p/'long-analysis.json').write_text(json.dumps(report,indent=2)+'\n')
for x in lsummary:print('long',x['case'],x['enabled'],round(x['metrics']['coldToFinalDiagnosticMs']['median'],2),x['retirementCounts'],x['retirementPrimaryMs'])
for x in msummary:
 if x['stage']!='short':print('memory',x['stage'],x['case'],x['arm'],x['outcomes'],x['endParentMiB'])
