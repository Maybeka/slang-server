from pathlib import Path
import hashlib,json,sys,threading,time
p=Path(__file__).resolve().parent;q=p/'product-next';out=q/'performance';sys.path.insert(0,str(p.parent/'full-performance-2026-10-19'));import memory as m
e=m.e;e.out=p;binary=q/'slang-server-v4';base=e.configuration

def configuration(project,cell):
 cfg=base(project,cell);cfg['experimentalUvmPrefixCache']=cell.get('prefix',False);return cfg
e.configuration=configuration
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();schedule=[]
for rep in range(3):
 for case in ['W13-continuous','W07-pss-multidoc','W08-ubus-task']:
  for method in ['completion','definition']:
   for arm in (['off','on'] if rep%2==0 else ['on','off']):schedule.append(dict(stage='short',rep=rep,case=case,method=method,arm=arm,diagnostics='drained',cycles=None))
# Measure the component tradeoff and the whole product against native independently.
for case in ['W13-continuous','W07-pss-multidoc','W08-ubus-task']:
 for arm in ['off','prefix-only','on']:schedule.append(dict(stage='long-burst',rep=0,case=case,method='completion',arm=arm,diagnostics='burst',cycles=1000))
 for arm in ['prefix-only','on']:schedule.append(dict(stage='long-drained',rep=0,case=case,method='definition',arm=arm,diagnostics='drained',cycles=500))
plan=dict(binary=str(binary),sha256=sha(binary),driverSha256=sha(Path(__file__)),schedule=schedule,scope='Separate sampled RSS, never mixed into latency matrix. 20ms libproc process-family and parent RSS, shared pages counted repeatedly and peaks can be missed. Short n3 per arm/case/method; long n1 with many natural retirements, original unchanged workload states. Source table retirement trace captured only here. No claim of an infinite-session or arbitrary-workload process RSS bound.')
assert not (out/'memory-plan.json').exists();(out/'memory-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
with (out/'memory.jsonl').open('x') as f:
 for i,cell in enumerate(schedule):
  assert sha(binary)==plan['sha256'];sampler=m.Sampler();trace=out/f"memory-{i:02}-retirement.tsv";assert not trace.exists();events=[];seen=0
  def observe(client,step):
   global seen
   sampler.observe(client,step)
   finalStep=cell['cycles']+1 if cell['cycles'] is not None else len(e.CASES[cell['case']]['states'])
   if step==finalStep and not any(x['step']==step for x in sampler.marks):sampler.marks.append(dict(step=step,serverPid=client.process.pid,seconds=time.monotonic()-sampler.started,rss=m.rss(client.process.pid)))
   lines=trace.read_text().splitlines() if trace.exists() else []
   if len(lines)>seen:events.append(dict(step=step,events=lines[seen:],rss=m.rss(client.process.pid)));seen=len(lines)
  env={'SLANG_UVM_GENERATION_TRACE':str(trace)}
  if cell['arm']=='prefix-only':env['SLANG_UVM_GENERATION_DISABLE']='1'
  thread=threading.Thread(target=sampler.loop);thread.start()
  try:r=e.run(dict(case=cell['case'],method=cell['method'],prefix=cell['arm']!='off',enabled=False,diagnostics=cell['diagnostics']),binary=binary,extra_env=env,status=False,observer=observe,cycles=cell['cycles'])
  finally:sampler.stop.set();thread.join()
  if sampler.limit:r['outcome']='budget-exceeded'
  r.update(cell,index=i,retirements=events,memory=dict(intervalMs=20,samples=sampler.samples,marks=sampler.marks,peakFamilyRss=max(x['familyRss'] for x in sampler.samples),limit=sampler.limit));f.write(json.dumps(r,separators=(',',':'))+'\n');f.flush();print('memory',i+1,'/',len(schedule),cell['stage'],cell['case'],cell['arm'],r['outcome'],flush=True);assert r['outcome'] in ('success','budget-exceeded'),r.get('error')
print('Separate memory assessment completed',flush=True)
