from pathlib import Path
import hashlib,json,random,sys,os
p=Path(__file__).resolve().parent;q=p/'product-next';out=q/'performance';out.mkdir(exist_ok=True);sys.path.insert(0,str(p.parent/'full-performance-2026-10-19'));import evaluate as e
e.out=p;binary=q/'slang-server-v4';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();base=e.configuration
for key in os.environ:assert not key.startswith('SLANG_UVM_'),key
def configuration(project,cell):
 cfg=base(project,cell);cfg['experimentalUvmPrefixCache']=cell.get('prefix',False);return cfg
e.configuration=configuration
rng=random.Random(2026101913);schedule=[]
for stage,cases,mode in [('drained',['W01-compare','W07-pss-multidoc','W08-ubus-task','W13-continuous'],'drained'),('burst',['W13-continuous'],'burst')]:
 blocks=[]
 for case in cases:
  for method in ('completion','definition'):
   for block in range(10):
    order=[False,True,True,False] if rng.randrange(2) else [True,False,False,True];blocks.append([dict(stage=stage,case=case,method=method,block=block,cache=arm,diagnostics=mode) for arm in order])
 rng.shuffle(blocks);schedule.extend(c for b in blocks for c in b)
plan=dict(binary=str(binary),binarySha256=sha(binary),driverSha256=sha(Path(__file__)),helperSha256=sha(p.parent/'full-performance-2026-10-19/evaluate.py'),catalogSha256=sha(p/'workloads.json'),projectsSha256=sha(p/'projects.json'),seed=2026101913,schedule=schedule,scope='Exact frozen integrated candidate, same binary Config false/true, old overlay and fast cwd disabled, fresh process and warm filesystem. n20 each arm/cell, balanced ABBA/BAAB. No traces/status/sampler in latency sequence; failures/outliers retained without replacement. Positive isolated diagnostic-worker commitment required.')
assert not (out/'timing-plan.json').exists();(out/'timing-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
for project in e.PROJECTS.values():
 for name,h in project['files'].items():assert sha(p/project['root']/name)==h,name
with (out/'timing-results.jsonl').open('x') as f:
 for i,cell in enumerate(schedule):
  assert sha(binary)==plan['binarySha256'];r=e.run(dict(case=cell['case'],method=cell['method'],prefix=cell['cache'],enabled=False,diagnostics=cell['diagnostics']),binary=binary,status=False)
  log=(p/e.PROJECTS[e.CASES[cell['case']]['project']]['root']/'server.stderr').read_text(errors='replace');bad=any(s in log for s in ['Using sequential diagnostics','Diagnostic worker rejected job','Diagnostics are running sequentially']);r['isolatedDiagnosticCommit']='Committed isolated diagnostic snapshot' in log
  if bad or not r['isolatedDiagnosticCommit']:r['outcome']='diagnostic-fallback'
  r.update(cell,index=i);f.write(json.dumps(r,separators=(',',':'))+'\n');f.flush();assert r['outcome']=='success',(cell,r.get('error'),log[-1000:])
  if (i+1)%20==0:print('latency',i+1,'/',len(schedule),flush=True)
print('Latency matrix completed',flush=True)
