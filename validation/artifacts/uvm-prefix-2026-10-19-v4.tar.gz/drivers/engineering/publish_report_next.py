from pathlib import Path
import hashlib, io, json, platform, subprocess, tarfile

p = Path(__file__).resolve().parent
root = p.parent.parent
s = root / 'source'
q = p / 'product-next'
perf = q / 'performance'
def read(path): return json.loads(path.read_text())
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def records(path): return [json.loads(x) for x in path.read_text().splitlines()]
def dump(path, obj): path.write_text(json.dumps(obj, indent=2) + '\n')
candidate = read(q / 'candidate-v4.json')
assert digest(Path(candidate['binary'])) == candidate['sha256']
assert digest(root / 'build-uvm/bin/slang-server') == candidate['sha256']
assert all(x['returncode'] == 0 for x in read(q / 'long-acceptance-progress.json')['stages'])
assert len(read(q / 'long-acceptance-progress.json')['stages']) == 3
latency = read(perf / 'latency-analysis.json')
long = read(perf / 'long-analysis.json')
assert (latency['primaryProcesses'], latency['allResolveProcesses'], long['fallbackProcesses'],
        long['longLatencyProcesses'], long['memoryProcesses']) == (400, 240, 240, 18, 51)
memory = records(perf / 'memory.jsonl')
assert all(x['outcome'] == 'success' for x in memory)

# Summaries deliberately exclude completion/documentation bodies from local projects.
oracles = {}
for arm in ['off', 'on', 'forced']:
    data = read(q / f'oracle-{arm}-v4/oracle.json')
    assert len(data) == 15 and all(x['equal'] and x['staleEqual'] for x in data)
    oracles[arm] = [dict(case=x['case'], equal=x['equal'], staleEqual=x['staleEqual'],
        resolvedItems=sum(len(r.get('resolved', [])) for r in x['prototype']['rows']),
        mechanism=x['mechanism']) for x in data]
dump(q / 'oracle-summary-v4.json', oracles)
controls = {}
for name, path in [('macros',q/'macro-controls-v4/macro-controls.json'),
                   ('replacement',q/'replacement-failure-v4/results.json')]:
    rows = read(path)
    assert all(x['equal'] and x.get('staleEqual',True) for x in rows)
    controls[name] = [{k:v for k,v in x.items() if k in ['case','name','equal','staleEqual','trace']}
                      for x in rows]
pressure = read(q/'pressure.json'); assert pressure['equal']
controls['pressure'] = dict(equal=True,documents=len(pressure['runs'][0]['results']))
dump(q/'controls-summary-v4.json',controls)

projects = read(p / 'projects.json')
for project in projects:
    for name, sha in project['files'].items():
        assert digest(p / project['root'] / name) == sha, (project['id'], name)
dump(q / 'input-integrity-v4.json', dict(equal=True, files=sum(len(x['files']) for x in projects),
    scope='All frozen timing-corpus files, including filelists and UVM, match the preregistered inventory after all measurement stages.'))
sdk = read(s/'restoration/main-sdk.json')
assert not [name for name,sha in sdk['files'].items() if digest(s/'external/slang'/name)!=sha]
dump(q/'final-static-audit.json',dict(format=dict(command='clang-format --dry-run --Werror',files=20,exitCode=0),
    whitespace=dict(productExitCode=0,sdkExitCode=0),liveSdkFilesMatched=len(sdk['files']),
    defaultFlag='experimentalUvmPrefixCache=false',
    publication='Not covered by this pre-publication static audit; recorded separately after push.'))

files = []
def add(path, name):
    assert path.is_file(), path
    files.append((path, name))
for name in ['timing-plan.json', 'timing-results.jsonl', 'rich-timing-plan.json',
             'rich-timing-results.jsonl', 'fallback-plan.json', 'fallback.jsonl',
             'long-latency-plan.json', 'long-latency.jsonl', 'memory-plan.json',
             'memory.jsonl', 'latency-analysis.json', 'long-analysis.json',
             'rich-runner.py', 'long-runner.py']:
    add(perf / name, 'performance/' + name)
for path in sorted(perf.glob('memory-*-retirement.tsv')):
    add(path, 'performance/' + path.name)
for name in ['acceptance-progress.json', 'long-acceptance-progress.json',
             'candidate-v4.json', 'oracle-summary-v4.json', 'controls-summary-v4.json', 'input-integrity-v4.json', 'final-static-audit.json',
             'server-tests-full.json', 'server-tests-full.log', 'server-tests-depth.json',
             'server-tests-depth.log', 'sdk-tests-v2.log']:
    add(q / name, 'acceptance/' + name)
for arm in ['off','on','forced']:
    for path in sorted((q/f'oracle-{arm}-v4').glob('*.tsv')):
        add(path,f'acceptance/oracle-{arm}/'+path.name)
for path in sorted(q.glob('accept-*.log')) + sorted(q.glob('long-accept-*.log')):
    add(path, 'acceptance/' + path.name)
for name in ['accept_next.py', 'accept_long_next.py', 'latency_next.py', 'rich_next.py',
             'fallback_next.py', 'long_latency_next.py', 'memory_next.py',
             'analyze_next.py', 'analyze_long_next.py', 'validate_next.py',
             'validate_next_v4.py', 'control_next_v4.py', 'rollback_next_v4.py',
             'pressure_next.py', 'collect_next_native.py', 'test_next.py', 'time_shared_guards.py',
             'verify_product_restoration_v4.py', 'publish_report_next.py']:
    add(p / name, 'drivers/engineering/' + name)
for name in ['evaluate.py', 'memory.py']:
    add(p.parent / 'full-performance-2026-10-19' / name, 'drivers/full-performance/' + name)
add(p.parent / 'uvm-prefix-prototype-2026-10-19/v5/oracle.py', 'drivers/prototype/v5/oracle.py')
for name in ['transport-tests.log', 'python-tests.log', 'restoration-check-v4.json',
             'long-memory-1000-analysis.json']:
    add(p / 'product-integration' / name, 'acceptance/' + name)
add(p / 'projects.json', 'inputs/projects.json')
manifest = {name: dict(sha256=digest(path), bytes=path.stat().st_size) for path, name in files}
archive = s / 'validation/artifacts/uvm-prefix-2026-10-19-v4.tar.gz'
with tarfile.open(archive, 'w:gz') as out:
    for path, name in files: out.add(path, arcname=name, recursive=False)
    blob = (json.dumps(manifest, indent=2) + '\n').encode()
    entry = tarfile.TarInfo('manifest.json'); entry.size = len(blob)
    out.addfile(entry, io.BytesIO(blob))
with tarfile.open(archive) as check:
    for name, meta in manifest.items():
        assert hashlib.sha256(check.extractfile(name).read()).hexdigest() == meta['sha256']

changes = subprocess.check_output(['git', 'diff', '--name-only'], cwd=s, text=True).splitlines()
product_sources = [x for x in changes if x.startswith(('src/', 'include/', 'restoration/',
    'clients/', 'tests/')) and (s / x).is_file()]
product_sources.append('tests/cpp/UvmPrefixTests.cpp')
report = dict(schemaVersion=1,
    scope='Mac real UVM parsed-prefix engineering acceptance; Config off/on comparison within the same frozen ordinary binary; static language-server workloads, not simulator or production-design acceptance',
    identity=dict(parentCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip(),
        platform=platform.platform(), candidate=candidate,
        originalNativeSha256=digest(root/'build/bin/slang-server'),
        sdk=read(p/'product-integration/restoration-check-v4.json'),
        productSourceSha256={name:digest(s/name) for name in product_sources}),
    projects=[{k:v for k,v in x.items() if k!='files'} for x in projects],
    acceptance=dict(stages=read(q/'acceptance-progress.json')['stages'],
        measurementStages=read(q/'long-acceptance-progress.json')['stages'],
        ctest=613, sdkCases=2561, sdkAssertions=23611, systemPython=8,
        measurementAndLuaPython=7, transport=35,
        specialized=dict(cases=3,assertions=169), oracleCasesPerArm=15,
        oracleArms=['off','on','forced-retirement'],
        oracleResolvedItemsPerArm={a:sum(x['resolvedItems'] for x in cases) for a,cases in oracles.items()},
        independentCommands=[
            dict(command=[str(root/'build-uvm/bin/unittests')],
                 cwd=str(root/'build-uvm/external/slang/tests/unittests'),
                 logSha256=digest(q/'sdk-tests-v2.log'),
                 scope='SDK source unchanged between this full SDK run and frozen v4; final restoration hashes verify its inputs'),
            dict(command=[str(s/'.venv/bin/python'),'-m','pytest','tests/method_scope','-q'],
                 cwd=str(s),logSha256=digest(p/'product-integration/python-tests.log'),
                 scope='independent measurement and Lua contracts, unchanged by subsequent candidate revisions'),
            dict(command=['bash','tests/transport/run-diagnostic-transport-tests.sh'],
                 cwd=str(s),logSha256=digest(p/'product-integration/transport-tests.log'),
                 scope='independent transport sources unchanged by subsequent candidate revisions')],
        inputIntegrity=read(q/'input-integrity-v4.json'),
        staticAudit=read(q/'final-static-audit.json'),
        controls=['steady/config-watch/library-watch/unsaved-library macro freshness',
            'failed replacement preserves old context and unsaved text, then recovers, SPI/PSS/UBUS',
            '64-entry LRU eviction and 65 MiB oversized bypass, 69 native-equal documents',
            'single logical unit, physical ancestry, enum previews, source-token lifetime',
            '8 threads / 40 extraction and bind operations without borrowed-node mutation',
            'wrapper warnings allowed; macro/conditional/lint effects and truncated include rejected']),
    latency=latency, longAndMemory=long,
    limitations=['Fresh processes and warm filesystem; no cache flush, CPU pinning or frequency control; other apps not stopped.',
        'No builds, tests or RSS sampling concurrent with ordinary latency measurements. Memory is a separate instrumented replay.',
        'n20 each ordinary short cell, paired balanced block inference; n3 long latency, n3 short memory, n1 long memory. p95/max are descriptive, not tail guarantees.',
        'Native W12 UTF16 query issue predates the candidate and is excluded; negotiated UTF8 and CRLF alternatives are included.',
        'Independent diagnostic workers continue full native parsing; default-off correctness matches original Native, but timing compares Config off/on in current binary.',
        'Local educational SPI/PSS plus official UVM 1.2 UBUS are not production designs; no simulation, GUI editor or new Linux acceptance.',
        'The 20ms RSS sampler can miss peaks; process-family sums count shared pages repeatedly; threshold bounds source generations, not arbitrary process RSS.',
        'Completion memory sessions resolve only the selected item; every-candidate resolve latency is separately measured and is not an RSS measurement of the fully populated resolver cache.',
        'Project source files and complete oracle response bodies stay local. Archived drivers require the original local fixture layout and private workload specifications.',
        'No cross-process or on-disk serialization implemented; old prototype/old retirement measurements are retained separately and do not establish final-candidate performance. Earlier long-memory scripts did not record an explicit last-step RSS mark; final-candidate measurements fix that marker.'],
    nextStrategies=[
        dict(priority=1,strategy='Stop capturing unused prefix state after permanent native fallback and in diagnostic-only workers',
            reason='Macro override and unsupported tail directives still cost about 35–40 ms per short sequence; cold first response costs 6–9 ms.',status='proposed, not implemented or measured'),
        dict(priority=2,strategy='Reduce retirement boundary reconstruction and overlapping owners while preserving unsaved documents and epochs',
            reason='Whole sessions improve but natural retirement still has ~94 ms maximum observed query latency.',status='further work requires new frozen candidate and long-session replay'),
        dict(priority=3,strategy='Reduce native diagnostic snapshot/parse costs with a separately validated immutable library representation',
            reason='Workers still do native parsing; parent-only caching cannot remove this end-to-end component.',status='research only; do not reuse mutable AST or source IDs across workers')],
    evidence=dict(archive=str(archive.relative_to(s)),sha256=digest(archive),bytes=archive.stat().st_size,
        members=len(manifest)+1,verified=True,rawProcesses=949,allOutcomes='success'))
dump(s/'validation/macos-uvm-prefix-2026-10-19.json', report)
names = {'W01-compare':'SPI', 'W13-continuous':'SPI (10 edits)',
         'W07-pss-multidoc':'PSS', 'W08-ubus-task':'UBUS task',
         'W09-ubus-config':'UBUS config', 'M-steady':'Macro control'}
def label(case): return names.get(case, case)
def pair(row, metric):
    a = row['arms']; keys = ('False','True') if 'False' in a else ('off','on')
    return ' / '.join(f"{a[k][metric]['p50']:.2f}" for k in keys)
lines = ['# Mac UVM prefix acceptance, 2026-10-19', '',
    'The opt-in parsed-prefix implementation improves first and repeated edits in',
    'the measured SPI/PSS/UBUS workloads. It also shares compatible library parses',
    'during resolution and retires source generations. Cold first response,',
    'unsupported fallback and retirement spikes remain real costs. The setting',
    '`experimentalUvmPrefixCache` remains **default false**.', '',
    'This is an in-process library artifact, with no disk serialization. The',
    '[design and eligibility rules](../docs/features/uvm-prefix-cache.md) describe',
    'ownership, exact-context checks, fixed external macros and native fallback.', '',
    '## Inputs and acceptance', '',
    'All performance comparisons below use Config off/on in the same frozen',
    f"ordinary binary, SHA256 `{candidate['sha256']}`. The source starts from",
    '`73f82dc`; the [machine-readable report](macos-uvm-prefix-2026-10-19.json)',
    'records the actual changed-source hashes and commands. The earlier immutable',
    'Native binary is used independently for correctness, not as a paired timing arm.', '',
    'The corpus contains the local educational SPI/PSS laboratory (209 files and',
    '77,665 inventory lines per configuration) and official UVM 1.2 UBUS (172 files,',
    '78,866 inventory lines). UVM is pinned at',
    '`71f30a7473118b3cea582d7673c3af8e161fce71`. Original HDL text, ordered',
    'roots, include paths, fixed flags and tops are preserved. These inventories',
    'include unreached files. This is static language-server acceptance, without',
    'VCS runtime/debug/DPI linking or simulation, and does not represent production',
    'design scale. All 590 inventory files still match after the measurements.', '',
    '- CTest **613/613**; SDK **2,561 cases / 23,611 assertions**.',
    '- Python system **8**, measurement/Lua **7**, transport **35**, all pass.',
    '- Specialized guards: **169 assertions / 3 cases**, including concurrent',
    '  extraction/binding, immutable ancestry/preview links and source-token lifetime.',
    '- Each of off/on/forced-retirement matches the original Native public',
    '  completion order, definition, every resolve and selected stale responses',
    '  in 15 cases (14 real editing scenarios plus a UVM-owned case).',
    '- Macro freshness under config/library watches and unsaved library overlays,',
    '  replacement failure/recovery and bounded-cache pressure pass.',
    '- Clean SDK patch application matches all **708** retained file hashes.', '',
    'The native W12 UTF16 query issue predates this candidate and remains excluded;',
    'negotiated UTF8 and CRLF alternatives are included. No new Linux or GUI-editor',
    'acceptance is claimed.', '',
    '## First and repeated queries', '',
    'Values are medians in **ms**, **off / on**, n=20 per arm/cell. Cold first',
    'response includes initialization and the initial query. Edit response sums',
    'exclude that initial query and include recovery. The whole interval begins',
    'at cold startup and ends with the final versioned diagnostic notification.',
    'The table drains diagnostics after each state; SPI continuous uses ten edits,',
    'the other cases use edit plus restore. Burst cases remain in the JSON report.', '',
    '| Case / query | Cold first response | First edit | Edit response sum | Cold to final diagnostic |',
    '|---|---:|---:|---:|---:|']
for row in latency['primary']:
    if row['stage'] != 'drained': continue
    lines.append('| ' + label(row['case'])+' / '+row['method']+' | '+ ' | '.join(pair(row,m) for m in
        ['coldFirstMs','firstEditMs','editResponseSumMs','coldToFinalDiagnosticMs'])+' |')
lines += ['', 'Cold first response costs about **6–9 ms**. First edits drop from roughly',
    '**49–53 ms to 16–20 ms**. This is suffix parsing and native semantic analysis,',
    'not arbitrary constant-time editing. Diagnostic workers still perform native',
    'full parsing, so their cost remains in the whole-session results.', '',
    '## Every completion resolve', '',
    'These separate n=20 cells resolve every returned candidate at every state;',
    f"all **{latency['allResolveResponses']:,}** resolve requests succeed. Medians in ms, off / on.", '',
    '| Case | Initial all-resolve sum | Edit all-resolve sum | Cold to all queries and diagnostics |',
    '|---|---:|---:|---:|']
for row in latency['resolve']:
    lines.append('| '+label(row['case'])+' | '+' | '.join(pair(row,m) for m in
        ['firstStageResolveMs','editResolveSumMs','coldToAllQueriesAndDiagnosticsMs'])+' |')
lines += ['', 'SPI and UBUS config reach the shared library path, including the verified',
    'transparent UBUS wrapper. PSS and UBUS task do not gain materially from resolve',
    'cache hits themselves; their whole-session saving comes mainly from edits.', '',
    '## Invalidation and fallback', '',
    'All 240 processes succeed. Each variant has n=20 per arm, with watched-file',
    'notifications included in the measured sequence. Medians in ms, off / on.', '',
    '| Variant | First edit | Restore | Cold to final diagnostic |',
    '|---|---:|---:|---:|']
for variant in sorted({r['variant'] for r in long['fallback']}):
    a = {r['enabled']:r for r in long['fallback'] if r['variant']==variant}
    cells = [' / '.join(f"{a[k]['metrics'][m]['median']:.2f}" for k in [False,True])
        for m in ['firstEditMs','recoveryMs','coldToFinalDiagnosticMs']]
    lines.append('| '+variant+' | '+' | '.join(cells)+' |')
lines += ['', 'Config/library watch sequences improve and nonprefix root ordering is near',
    'parity. Source macro override, tail resetall and tail timescale preserve native',
    'results but add about **35–40 ms** over these short sequences. That penalty',
    'is included in acceptance and is one reason to keep the experiment opt-in.', '',
    '## Thousand-edit ordinary latency', '',
    'Three fresh processes per arm/case, 1,000 completion edits each. Every step',
    'also repeats completion and resolves a selected item; initial/final diagnostics',
    'are drained. No status probes, trace output or RSS sampler runs in these cells.',
    'Retirement boundaries come from normal opaque generation data returned by',
    'completion. Total seconds are per-process medians, off / on.', '',
    '| Case | Whole sequence (s) | On retirements per run | On boundary p95 / max (ms) |',
    '|---|---:|---:|---:|']
for case in sorted({r['case'] for r in long['longLatency']}):
    a = {r['enabled']:r for r in long['longLatency'] if r['case']==case}; b=a[True]['retirementPrimaryMs']
    total=' / '.join(f"{a[k]['metrics']['sequenceWithDiagnosticsMs']['median']/1000:.2f}" for k in [False,True])
    lines.append(f"| {label(case).replace(' (10 edits)','')} | {total} | {a[True]['retirementCounts']} | {b['p95']:.2f} / {b['max']:.2f} |")
lines += ['', 'The measured whole-session gain includes the retirement work. A roughly',
    '**94 ms** observed boundary maximum is still substantially above ordinary',
    'edited-query latency. These small samples do not establish a tail guarantee.', '',
    '## Separate memory replay', '',
    'RSS is sampled every 20 ms through libproc. Parent RSS at the final observed',
    'query and peak simultaneous process-family RSS are separate metrics. Family',
    'sums include diagnostic workers and count shared pages repeatedly; short',
    'worker peaks may be missed. Memory timings are excluded from latency inference.', '',
    'Completion memory sessions resolve a selected item. The every-candidate resolve',
    'matrix above is separate and does not establish its fully populated cache RSS.', '',
    'Short drained sessions use n=3 per arm/query. Medians in MiB, off / on.', '',
    '| Case / query | Final parent RSS | Peak family RSS |',
    '|---|---:|---:|']
for case in sorted({r['case'] for r in long['memory']}):
    for method in ['completion','definition']:
        a={r['arm']:r for r in long['memory'] if r['stage']=='short' and r['case']==case and r['method']==method}
        cells=[' / '.join(f"{a[k][m]['median']:.2f}" for k in ['off','on']) for m in ['endParentMiB','peakFamilyMiB']]
        lines.append('| '+label(case)+' / '+method+' | '+' | '.join(cells)+' |')
lines += ['', 'Long burst sessions use 1,000 completion edits and n=1 per arm/case.',
    '`prefix-only` disables generation retirement while retaining prefix reuse.',
    'Long drained sessions use 500 definition edits, comparing prefix-only and on;',
    'there is no native drained arm in this memory matrix. All final-step marks',
    'are explicit. MiB, individual observations:', '',
    '| Session / case / arm | Final parent RSS | Peak family RSS | Retirements |',
    '|---|---:|---:|---:|---:|']
for row in long['memory']:
    if row['stage']=='short': continue
    lines.append(f"| {row['stage']} / {label(row['case']).replace(' (10 edits)','')} / {row['arm']} | {row['endParentMiB']['median']:.2f} | {row['peakFamilyMiB']['median']:.2f} | {row['retirementCounts'][0]} |")
lines += ['', 'The JSON retains RSS at every observed retirement as well as per-process',
    'query distributions and all outcomes. Repeated natural retirements show the',
    'behavior over these sessions; the source-generation threshold is not a bound',
    'on arbitrary process RSS. Earlier prototype/retirement observations remain',
    'separate. Their missing explicit final-step marker was corrected in this matrix.', '',
    '## Decision and next optimization priorities', '',
    'Retain the implementation behind the opt-in flag: unchanged UVM prefix sharing,',
    'one native initial parent parse, compatible resolve reuse and context retirement',
    'all pass correctness acceptance and improve the supported whole sessions.',
    'Do not enable it globally: cold-start overhead, unsupported-input penalties',
    'and retirement spikes remain workload-dependent costs.', '',
    '1. Stop creating unused prefix checkpoints after a permanent fallback and in',
    '   diagnostic-only workers. Target the measured fallback penalty and cold cost;',
    '   validate with a new frozen binary and the same complete off/on matrix.',
    '2. Reduce replacement reconstruction and overlapping owners at retirement.',
    '   Preserve unsaved text, rollback behavior and stale-handle generation checks;',
    '   require lower boundary latency without losing the measured RSS reduction.',
    '3. Investigate immutable library data for diagnostic workers separately.',
    '   The current parent cache does not remove their native parse. Cross-process',
    '   source-location ownership and complete diagnostic equivalence need proof.', '',
    'These follow-up strategies are proposed, not additional implemented gains.', '',
    '## Evidence and statistical limits', '',
    f"All **949** performance/memory processes succeed. The [raw archive]({report['evidence']['archive'].removeprefix('validation/')})",
    f"is {report['evidence']['bytes']:,} bytes, SHA256",
    f"`{report['evidence']['sha256']}`; every archived member was read back and hash-verified.",
    'It contains plans, exact drivers, per-request timings, RSS samples, mechanism',
    'summaries and test logs. Project sources and full oracle response bodies remain',
    'local. Drivers preserve the local fixture layout; they are not a standalone',
    'public reproduction of the private educational project.', '',
    'Short timing cells use ten balanced four-process ABBA/BAAB blocks. Exploratory',
    '95% intervals in JSON resample block mean differences (on minus off), not',
    'medians. n=20 p95 and long-session maxima are descriptive; there is no p99,',
    'tail or multiplicity-adjusted claim. No failures/outliers were removed.',
    'Fresh processes used a warm filesystem without CPU pinning/frequency control;',
    'other apps were not stopped. Builds, tests and sampling were separated from',
    'ordinary latency runs.', '']
(s/'validation/macos-uvm-prefix-2026-10-19.md').write_text('\n'.join(lines))
print('Report and verified raw archive:', archive.stat().st_size, 'bytes;', len(manifest), 'hashed members')
