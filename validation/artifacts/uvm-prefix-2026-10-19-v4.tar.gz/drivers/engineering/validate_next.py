from pathlib import Path
import json,sys,hashlib
p=Path(__file__).resolve().parent;q=p/'product-next';mode=sys.argv[1];assert mode in ('off','on','forced');out=q/('oracle-'+mode);out.mkdir(exist_ok=True);v=p.parent/'uvm-prefix-prototype-2026-10-19/v5';sys.path.insert(0,str(v));import oracle as o
o.p=q;o.e.out=q;e=o.e;Parent=o.OracleClient;caseName='';clients=[]
class Client(Parent):
 def __init__(self,*args,**kwargs):
  env=kwargs.get('extra_env',{}).copy();self.enabled=mode!='off';self.events=[];self.lastParse=0;self.lastCache=0;self.parse=out/f'{caseName}-parse.tsv';self.cache=out/f'{caseName}-cache.tsv'
  cfg=args[1]/'.slang/server.json';settings=json.loads(cfg.read_text());settings['experimentalUvmPrefixCache']=self.enabled;cfg.write_text(json.dumps(settings))
  if self.enabled:
   assert not self.parse.exists() and not self.cache.exists();env.update(SLANG_UVM_PARSE_TRACE=str(self.parse),SLANG_UVM_RESOLVE_CACHE_TRACE=str(self.cache))
   if mode=='forced':env.update(SLANG_UVM_GENERATION_EDIT_LIMIT='1',SLANG_UVM_GENERATION_TRACE=str(out/f'{caseName}-generation.tsv'))
  clients.append(self);kwargs['extra_env']=env;super().__init__(*args,**kwargs)
 def request(self,method,params,notifications=()):
  result=super().request(method,params,notifications)
  if self.enabled:
   pid=str(self.process.pid)+'\t';parses=[x for x in self.parse.read_text().splitlines() if x.startswith(pid)] if self.parse.exists() else [];cache=[x for x in self.cache.read_text().splitlines() if x.startswith(pid)] if self.cache.exists() else [];a=parses[self.lastParse:];b=cache[self.lastCache:]
   if a or b:self.events.append(dict(method=method,label=params.get('label') if isinstance(params,dict) else None,parse=a,cache=b))
   self.lastParse=len(parses);self.lastCache=len(cache)
  return result
o.OracleClient=Client
assert not (out/'oracle.json').exists();baseline=json.loads((q/'native-oracle.json').read_text());references={r['case']:r['native'] for r in baseline};cases=[c for c in e.CASES.values() if c['id']!='W12-encoding-lines'];cases.append(json.loads((v/'uvm-owned-case.json').read_text()));rows=[]
for case in cases:
 caseName=case['id'];a=references[caseName];b=o.run(case,q/'slang-server',mode!='off',False);equal=a['outcome']==b['outcome']=='success' and o.comparable(a)==o.comparable(b);stale=o.public(a.get('staleResolves'))==o.public(b.get('staleResolves'));rows.append(dict(case=caseName,nativeReference='../native-oracle.json',prototype=b,equal=equal,staleEqual=stale,mechanism=clients[-1].events));(out/'oracle.json').write_text(json.dumps(rows,separators=(',',':'))+'\n');print(mode,caseName,b['outcome'],equal,stale,flush=True);assert equal and stale,b.get('error')
(out/'candidate.json').write_text(json.dumps(dict(binary=str(q/'slang-server'),sha256=hashlib.sha256((q/'slang-server').read_bytes()).hexdigest(),mode=mode,nativeReferenceSha256=hashlib.sha256((q/'native-oracle.json').read_bytes()).hexdigest(),cases=len(rows)),indent=2)+'\n')
