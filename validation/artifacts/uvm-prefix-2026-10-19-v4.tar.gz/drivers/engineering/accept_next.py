from pathlib import Path
import subprocess,os,json,time,hashlib
p=Path(__file__).resolve().parent;root=p.parent.parent;q=p/'product-next';python=root/'source/.venv/bin/python';tmp=q/'test-tmp';tmp.mkdir(exist_ok=True);env=dict(os.environ,TMPDIR=str(tmp));binary=q/'slang-server-v4';expected=json.loads((q/'candidate-v4.json').read_text())['sha256'];stages=[];assert not (q/'acceptance-progress.json').exists()
commands=[
 ('default-off oracle',[str(python),str(p/'validate_next_v4.py'),'off'],root),
 ('default-on oracle',[str(python),str(p/'validate_next_v4.py'),'on'],root),
 ('macro freshness',[str(python),str(p/'control_next_v4.py')],root),
 ('replacement failure',[str(python),str(p/'rollback_next_v4.py')],root),
 ('cache pressure',[str(python),str(p/'pressure_next.py')],root),
 ('complete build',['/opt/homebrew/bin/cmake','--build',str(root/'build-uvm'),'-j2'],root),
 ('complete ctest',['/opt/homebrew/bin/ctest','--test-dir',str(root/'build-uvm'),'--output-on-failure','-j2'],root),
 ('python system',[str(python),'-m','pytest','tests/system','--binary',str(binary),'-q'],root/'source'),
 ('latency matrix',[str(python),str(p/'latency_next.py')],root),
 ('full resolve matrix',[str(python),str(p/'rich_next.py')],root)]
for i,(name,args,cwd) in enumerate(commands):
 assert hashlib.sha256(binary.read_bytes()).hexdigest()==expected
 print('START',name,flush=True);start=time.monotonic();log=q/f'accept-{i:02}.log'
 with log.open('w') as f:r=subprocess.run(args,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 stages.append(dict(name=name,returncode=r.returncode,seconds=time.monotonic()-start,log=str(log),command=args));(q/'acceptance-progress.json').write_text(json.dumps(dict(status='running' if r.returncode==0 else 'failed',candidateSha256=expected,stages=stages),indent=2)+'\n');print('END',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
(q/'acceptance-progress.json').write_text(json.dumps(dict(status='completed functional and latency stages; memory and final audit pending',candidateSha256=expected,stages=stages),indent=2)+'\n')
