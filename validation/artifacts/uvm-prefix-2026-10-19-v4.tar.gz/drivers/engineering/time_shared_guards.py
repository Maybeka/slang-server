from pathlib import Path
import copy,hashlib,json,random,sys,time,traceback
p=Path(__file__).resolve().parent;out=p/'resolve-cache-shared-guards';sys.path.insert(0,str(p.parent/'full-performance-2026-10-19'));import evaluate as e;e.out=p
macro=copy.deepcopy(e.CASES['W01-compare']);macro['id']='M-steady'
for s in macro['states']:s['completion']=dict(anchor='`uvm_object_utils(spi_seq_item)',token='`uvm_object_utils')
e.CASES[macro['id']]=macro
binaries={'prefix':p/'resolve-cache-owned-v2/slang-server-prototype','resolve':out/'slang-server-prototype'};rng=random.Random(2026101912);blocks=[]
for case,n in [('W01-compare',8),('W09-ubus-config',8),('W13-continuous',8),('M-steady',8),('W07-pss-multidoc',4),('W08-ubus-task',4)]:
 for block in range(n//2):
  order=['prefix','resolve','resolve','prefix'] if rng.randrange(2) else ['resolve','prefix','prefix','resolve'];blocks.append([dict(case=case,arm=a,block=block) for a in order])
rng.shuffle(blocks);schedule=[c for b in blocks for c in b];sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();assert not (out/'rich-timing-plan.json').exists();(out/'rich-timing-plan.json').write_text(json.dumps(dict(seed=2026101912,schedule=schedule,binaries={a:dict(path=str(b),sha256=sha(b)) for a,b in binaries.items()},driverSha256=sha(Path(__file__)),helperSha256=sha(p.parent/'full-performance-2026-10-19/evaluate.py'),scope='Exploratory direct-prefix reuse isolation: BOTH arms enable shared/captured prefix and the same bounded exact-context resolver cache; prefix arm is previous separately parsed artifact candidate; resolve arm shares matching captured prefix, method overlay off, strict CWD. Fresh ordinary processes; request-paced completion then resolve EVERY returned candidate, drain version diagnostics per edit. n8 per main arm/case; n4 PSS/UBUS no-cache-hit controls. ABBA/BAAB balanced blocks. No trace, sampler or status requests in sequence. Failures and outliers retained; no tail/acceptance claim from n4/8.'),indent=2)+'\n')
def run(cell):
 case=e.CASES[cell['case']];project=e.PROJECTS[case['project']];folder=p/project['root'];cfg=folder/'.slang/server.json';saved=cfg.read_bytes();cfg.write_text(json.dumps(e.configuration(project,dict(enabled=False))));original=(folder/case['target']).read_bytes().decode();uri=(folder/case['target']).as_uri();previous=original;client=None;rows=[];started=time.perf_counter_ns()
 try:
  client=e.EvalClient(binaries[cell['arm']],folder,extra_env={'SLANG_SERVER_UVM_PREFIX_CACHE':'1'})
  for name in case['extraOpen']:
   file=folder/name;client.notify('textDocument/didOpen',dict(textDocument=dict(uri=file.as_uri(),version=1,languageId='systemverilog',text=file.read_bytes().decode())))
  for i,s in enumerate(case['states']):
   text=e.transform(original,s['operations']);version=i+1;notices=[dict(method='textDocument/didOpen',params=dict(textDocument=dict(uri=uri,version=version,languageId='systemverilog',text=text)))] if i==0 else [e.range_change(uri,version,previous,text,case.get('positionEncoding','utf-16'))]
   items,begin,end=client.rpc('textDocument/completion',e.params(uri,text,s['completion']),notices);envelope={k:v for k,v in items.items() if k!='items'} if isinstance(items,dict) else None;items=items['items'] if isinstance(items,dict) else items;assert items and any(x['label']==s['completion']['token'] for x in items)
   requests=[];last=end
   for item in items:
    value,b,z=client.rpc('completionItem/resolve',item);assert value['label']==item['label'];requests.append(dict(kind=item.get('kind'),label=item['label'],ms=(z-b)/1e6));last=z
   message,diag=e.diag_wait(client,uri,version);assert any(d.get('severity')==1 for d in message['params']['diagnostics'])==s['expectError'];step=dict(step=i,primaryMs=(end-begin)/1e6,primaryBeginNs=begin,primaryEndNs=end,completionEnvelope=envelope,resolveCount=len(requests),resolveSumMs=sum(x['ms'] for x in requests),indexedKindResolveSumMs=sum(x['ms'] for x in requests if x['kind'] in (9,21)),lastResolveNs=last,diagnosticNs=diag,diagnosticFromEditMs=(diag-begin)/1e6,requests=requests);rows.append(step);previous=text
  stderr=(folder/'server.stderr').read_text(errors='replace');assert 'Using sequential diagnostics' not in stderr and 'Diagnostic worker rejected job' not in stderr
  return dict(outcome='success',rows=rows,coldFirstPrimaryMs=(rows[0]['primaryEndNs']-started)/1e6,firstStageResolveMs=rows[0]['resolveSumMs'],firstEditResolveMs=rows[1]['resolveSumMs'],allResolveSumMs=sum(x['resolveSumMs'] for x in rows),editResolveSumMs=sum(x['resolveSumMs'] for x in rows[1:]),editPrimarySumMs=sum(x['primaryMs'] for x in rows[1:]),coldToFinalDiagnosticMs=(rows[-1]['diagnosticNs']-started)/1e6,coldToAllQueriesAndDiagnosticsMs=(max(rows[-1]['diagnosticNs'],rows[-1]['lastResolveNs'])-started)/1e6)
 except Exception as error:return dict(outcome='error',error=repr(error),traceback=traceback.format_exc(),rows=rows)
 finally:
  if client:
   try:client.close()
   except Exception:client.process.kill();client.process.wait()
  cfg.write_bytes(saved)
assert not (out/'rich-timing-results.jsonl').exists()
with (out/'rich-timing-results.jsonl').open('w') as f:
 for i,c in enumerate(schedule):
  r=run(c);r.update(c,index=i);f.write(json.dumps(r,separators=(',',':'))+'\n');f.flush()
  if (i+1)%8==0:print(i+1,'/',len(schedule),r['outcome'],flush=True)
print('Whole resolve-chain timing completed',flush=True)
