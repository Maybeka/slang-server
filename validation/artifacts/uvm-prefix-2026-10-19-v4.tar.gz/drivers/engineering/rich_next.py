from pathlib import Path
import copy,hashlib,json,random,sys,time,traceback,os
p=Path(__file__).resolve().parent;q=p/'product-next';out=q/'performance';sys.path.insert(0,str(p.parent/'full-performance-2026-10-19'));import evaluate as e
e.out=p;binary=q/'slang-server-v4';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();base=e.configuration
for key in os.environ:assert not key.startswith('SLANG_UVM_'),key
def configuration(project,cell):
 cfg=base(project,cell);cfg['experimentalUvmPrefixCache']=cell.get('prefix',False);return cfg
e.configuration=configuration
macro=copy.deepcopy(e.CASES['W01-compare']);macro['id']='M-steady'
for state in macro['states']:state['completion']=dict(anchor='`uvm_object_utils(spi_seq_item)',token='`uvm_object_utils')
e.CASES[macro['id']]=macro
source=(p/'time_shared_guards.py').read_text();fn='def run(cell):'+source.split('def run(cell):',1)[1].split("\nassert not (out/'rich-timing-results.jsonl')",1)[0]
fn=fn.replace('e.configuration(project,dict(enabled=False))',"e.configuration(project,dict(enabled=False,prefix=cell['arm']=='on'))").replace("e.EvalClient(binaries[cell['arm']],folder,extra_env={'SLANG_SERVER_UVM_PREFIX_CACHE':'1'})","e.EvalClient(binary,folder)")
fn=fn.replace("assert 'Using sequential diagnostics' not in stderr and 'Diagnostic worker rejected job' not in stderr","assert all(x not in stderr for x in ['Using sequential diagnostics','Diagnostic worker rejected job','Diagnostics are running sequentially']) and 'Committed isolated diagnostic snapshot' in stderr")
(out/'rich-runner.py').write_text(fn+'\n');exec(compile(fn,str(out/'rich-runner.py'),'exec'),globals());rng=random.Random(2026101914);blocks=[]
for case in ['W01-compare','W09-ubus-config','W13-continuous','M-steady','W07-pss-multidoc','W08-ubus-task']:
 for block in range(10):
  order=['off','on','on','off'] if rng.randrange(2) else ['on','off','off','on'];blocks.append([dict(case=case,arm=a,block=block) for a in order])
rng.shuffle(blocks);schedule=[x for b in blocks for x in b];plan=dict(seed=2026101914,binary=str(binary),binarySha256=sha(binary),driverSha256=sha(Path(__file__)),runnerSha256=sha(out/'rich-runner.py'),helperSha256=sha(p.parent/'full-performance-2026-10-19/evaluate.py'),schedule=schedule,scope='Exact integrated frozen candidate, same binary Config false/true. Fresh processes, completion plus EVERY returned candidate resolve, every-version diagnostics drained and isolated-worker commit checked. n20 each arm/case in balanced ABBA/BAAB blocks. No trace/status/sampler; failures and outliers retained without replacement.')
assert not (out/'rich-timing-plan.json').exists();(out/'rich-timing-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
with (out/'rich-timing-results.jsonl').open('x') as f:
 for i,cell in enumerate(schedule):
  assert sha(binary)==plan['binarySha256'];r=run(cell);r.update(cell,index=i);f.write(json.dumps(r,separators=(',',':'))+'\n');f.flush();assert r['outcome']=='success',(cell,r.get('error'))
  if (i+1)%12==0:print('rich',i+1,'/',len(schedule),flush=True)
print('Full all-resolve matrix completed',flush=True)
