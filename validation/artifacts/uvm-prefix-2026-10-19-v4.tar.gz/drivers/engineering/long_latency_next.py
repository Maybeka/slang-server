from pathlib import Path
import ast,copy,hashlib,json,random,statistics,sys
p=Path(__file__).resolve().parent;q=p/'product-next';out=q/'performance';sys.path.insert(0,str(p.parent/'full-performance-2026-10-19'));import evaluate as e
e.out=p;binary=q/'slang-server-v4';base=e.configuration

def configuration(project,cell):
 cfg=base(project,cell);cfg['experimentalUvmPrefixCache']=cell.get('prefix',False);return cfg
e.configuration=configuration
# Observe the epoch already present in the selected completion item. This adds
# no server trace, status request, witness request or memory sampler to timings.
text=(p.parent/'full-performance-2026-10-19/evaluate.py').read_text();node=next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name=='run');fn=ast.get_source_segment(text,node)
key="                item=next(x for x in result if x['label']==s['completion']['token'])";assert key in fn
fn=fn.replace(key,key+"\n                payload=item.get('data');row['completionEpoch']=payload.get('contextEpoch') if isinstance(payload,dict) else None",1)
(out/'long-runner.py').write_text(fn+'\n');exec(compile(fn,str(out/'long-runner.py'),'exec'),e.__dict__)
rng=random.Random(2026101915);schedule=[]
for rep in range(3):
 cases=['W13-continuous','W07-pss-multidoc','W08-ubus-task'];rng.shuffle(cases)
 for case in cases:
  arms=[False,True] if (rep+cases.index(case))%2==0 else [True,False]
  schedule.extend(dict(case=case,rep=rep,prefix=arm) for arm in arms)
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();plan=dict(binary=str(binary),sha256=sha(binary),driverSha256=sha(Path(__file__)),runnerSha256=sha(out/'long-runner.py'),schedule=schedule,cycles=1000,scope='Uninstrumented same-binary Config off/on 1000-edit completion burst sessions, n3 per arm/case, paired alternating order. Each step does completion, cached repeat, selected resolve. Initial/final diagnostics drained; actual retirement boundaries inferred ONLY from the normal selected-item opaque contextEpoch already returned by the product. No status/trace/sampler. Failures/outliers retained.')
assert not (out/'long-latency-plan.json').exists();(out/'long-latency-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
with (out/'long-latency.jsonl').open('x') as f:
 for i,cell in enumerate(schedule):
  assert sha(binary)==plan['sha256'];r=e.run(dict(case=cell['case'],method='completion',prefix=cell['prefix'],enabled=False,diagnostics='burst'),binary=binary,status=False,cycles=1000)
  epochs=[x.get('completionEpoch') for x in r['rows']];bounds=[j for j in range(1,len(epochs)) if epochs[j]!=epochs[j-1]]
  if cell['prefix']:assert epochs and all(isinstance(x,int) for x in epochs) and bounds,(cell,epochs[:3])
  else:assert all(x is None for x in epochs)
  r.update(cell,index=i,retirementSteps=bounds);f.write(json.dumps(r,separators=(',',':'))+'\n');f.flush();assert r['outcome']=='success',r.get('error');print('long latency',i+1,'/',len(schedule),cell,'retirements',len(bounds),flush=True)
print('Long ordinary-query latency completed',flush=True)
