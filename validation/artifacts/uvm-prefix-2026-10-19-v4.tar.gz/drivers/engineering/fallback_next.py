from pathlib import Path
import copy,hashlib,json,random,sys
p=Path(__file__).resolve().parent;q=p/'product-next';out=q/'performance';sys.path.insert(0,str(p.parent/'full-performance-2026-10-19'));import evaluate as e
e.out=p;binary=q/'slang-server-v4';baseConfig=e.configuration;Parent=e.EvalClient;cell={}
def configuration(project,value):
 cfg=baseConfig(project,value);cfg['experimentalUvmPrefixCache']=value.get('prefix',False);return cfg
e.configuration=configuration
class Client(Parent):
 def __init__(self,*args,**kwargs):self.step=0;super().__init__(*args,**kwargs)
 def rpc(self,method,params,notifications=()):
  if method=='textDocument/definition' and notifications:
   if self.step==1 and cell['variant'] in ('library-watch','config-watch'):
    if cell['variant']=='library-watch':changed=folder/'uvm/base/uvm_object_globals.svh';changed.write_bytes(savedLibrary+b'\n// performance invalidation\n')
    else:
     changed=folder/'.slang/server.json';cfg=json.loads(changed.read_text());cfg['flags']+=' -DUVM_PERFORMANCE_RELOAD=1';changed.write_text(json.dumps(cfg))
    notifications=[dict(method='workspace/didChangeWatchedFiles',params=dict(changes=[dict(uri=changed.as_uri(),type=2)])),*notifications]
   self.step+=1
  return super().rpc(method,params,notifications)
e.EvalClient=Client
variants=['tail-timescale','tail-resetall','macro-override','nonprefix-order','library-watch','config-watch'];rng=random.Random(2026101917);blocks=[]
for variant in variants:
 for block in range(10):
  order=[False,True,True,False] if rng.randrange(2) else [True,False,False,True];blocks.append([dict(variant=variant,block=block,prefix=arm) for arm in order])
rng.shuffle(blocks);schedule=[x for b in blocks for x in b];sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();plan=dict(binary=str(binary),sha256=sha(binary),driverSha256=sha(Path(__file__)),schedule=schedule,scope='Same frozen binary Config off/on, n20 each arm per fallback/invalidation variant, balanced ABBA/BAAB. Ordinary exact definition plus cached repeat and every-version diagnostics. No status/trace/sampler. Watch events batched with the next change/query so foreground reload cost is included; total cold-to-final diagnostics also charged. Raw failures/outliers retained.')
assert not (out/'fallback-plan.json').exists();(out/'fallback-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
with (out/'fallback.jsonl').open('x') as f:
 for i,cell in enumerate(schedule):
  case=copy.deepcopy(e.CASES['W08-ubus-task' if cell['variant']=='nonprefix-order' else 'W01-compare']);project=e.PROJECTS[case['project']];folder=p/project['root'];pkg=folder/'uvm/uvm_pkg.sv';savedPkg=pkg.read_bytes();filelist=folder/'design.f';savedList=filelist.read_bytes();library=folder/'uvm/base/uvm_object_globals.svh';savedLibrary=library.read_bytes();case['id']='fallback-'+cell['variant'];e.CASES[case['id']]=case
  try:
   if cell['variant']=='tail-timescale':pkg.write_bytes(savedPkg+b'\n`timescale 1ns/1ps\n')
   elif cell['variant']=='tail-resetall':pkg.write_bytes(savedPkg+b'\n`resetall\n')
   elif cell['variant']=='macro-override':
    last=(folder/case['target']).read_text().splitlines()[-1];case['states'][1]['operations'].append(dict(old=last,new=last+'\n`undef UVM_MACROS_SVH\n`define UVM_MACROS_SVH\n'))
   elif cell['variant']=='nonprefix-order':
    text=savedList.decode().replace('uvm/uvm.sv\nexamples/ubus_tb_top.sv','examples/ubus_tb_top.sv\nuvm/uvm.sv');assert text!=savedList.decode();filelist.write_text(text)
   assert sha(binary)==plan['sha256'];r=e.run(dict(case=case['id'],method='definition',prefix=cell['prefix'],enabled=False,diagnostics='drained'),binary=binary,status=False);log=(folder/'server.stderr').read_text(errors='replace');r['isolatedDiagnosticCommit']='Committed isolated diagnostic snapshot' in log
   if any(s in log for s in ['Using sequential diagnostics','Diagnostic worker rejected job','Diagnostics are running sequentially']) or not r['isolatedDiagnosticCommit']:r['outcome']='diagnostic-fallback'
  finally:pkg.write_bytes(savedPkg);filelist.write_bytes(savedList);library.write_bytes(savedLibrary)
  r.update(cell,index=i);f.write(json.dumps(r,separators=(',',':'))+'\n');f.flush();assert r['outcome']=='success',(cell,r.get('error'))
  if (i+1)%20==0:print('fallback',i+1,'/',len(schedule),flush=True)
print('Fallback/invalidation timing completed',flush=True)
