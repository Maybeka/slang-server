from pathlib import Path
import copy,json,sys,traceback
p=Path(__file__).resolve().parent;sys.path.insert(0,str(p.parent.parent/'full-performance-2026-10-19'));import evaluate as e
from replay import Normalizer

e.out=p
class OracleClient(e.EncodingClient):pass

def run(case,binary,cache,trace=True,hook=None):
 project=e.PROJECTS[case['project']];root=p/project['root'];config=root/'.slang/server.json';saved=config.read_bytes();cfg=copy.deepcopy(project['config']);cfg['experimentalMethodScopeOverlay']=False;config.write_text(json.dumps(cfg));client=None;rows=[];uri=(root/case['target']).as_uri();original=(root/case['target']).read_bytes().decode();previous=original;open_texts={};env={}
 if cache:env['SLANG_SERVER_UVM_PREFIX_CACHE']='1'
 if trace:
  env.update(SLANG_UVM_CACHE_TRACE=str(p/f"{case['id']}-{cache}-cache.tsv"),SLANG_UVM_PARSE_TRACE=str(p/f"{case['id']}-{cache}-parse.tsv"))
 try:
  client=OracleClient(binary,root,encoding=case.get('positionEncoding','utf-16'),extra_env=env)
  for name in case['extraOpen']:
   q=root/name;open_texts[q.as_uri()]=q.read_bytes().decode();client.notify('textDocument/didOpen',dict(textDocument=dict(uri=q.as_uri(),version=1,languageId='systemverilog',text=open_texts[q.as_uri()])))
  old_item=None;stale=[]
  for i,s in enumerate(case['states']):
   text=e.transform(original,s['operations']);open_texts[uri]=text;version=i+1;encoding=case.get('positionEncoding','utf-16');notices=[dict(method='textDocument/didOpen',params=dict(textDocument=dict(uri=uri,version=version,languageId='systemverilog',text=text)))] if i==0 else [e.range_change(uri,version,previous,text,encoding)]
   definition,_=client.request('textDocument/definition',e.params(uri,text,s['query'],encoding),notices)
   a,b=e.token_range(text,s['declaration']);assert len(definition)==1 and definition[0]['targetUri']==uri and definition[0]['targetSelectionRange']==dict(start=e.position(text,a,encoding),end=e.position(text,b,encoding)),('wrong exact definition',s['id'])
   items,_=client.request('textDocument/completion',e.params(uri,text,s['completion'],encoding));assert items and any(x['label']==s['completion']['token'] for x in items)
   resolved=[client.request('completionItem/resolve',x)[0] for x in items]
   diagnostic,_=e.diag_wait(client,uri,version);assert any(d.get('severity')==1 for d in diagnostic['params']['diagnostics'])==s['expectError']
   state=client.state();normal=Normalizer(state,open_texts)
   repeated,_=client.request('textDocument/completion',e.params(uri,text,s['completion'],encoding));assert repeated==items
   rows.append(dict(state=s['id'],definition=normal.value(definition),completion=normal.value(items),resolved=normal.value(resolved),diagnostics=diagnostic['params']['diagnostics'],opaque=list(normal.opaque)))
   if old_item:
    try:value,_=client.request('completionItem/resolve',old_item);stale.append(dict(state=s['id'],result=normal.value(value)))
    except Exception as ex:stale.append(dict(state=s['id'],error=str(ex)))
   old_item=next(x for x in items if x['label']==s['completion']['token']);previous=text
   if hook:hook(client,i,root)
  stderr=(root/'server.stderr').read_text(errors='replace');assert 'Using sequential diagnostics' not in stderr and 'Diagnostic worker rejected job' not in stderr,'diagnostic fallback'
  return dict(outcome='success',rows=rows,staleResolves=stale,serverPid=client.process.pid)
 except Exception as ex:return dict(outcome='error',error=repr(ex),traceback=traceback.format_exc(),rows=rows)
 finally:
  if client:
   try:client.close()
   except Exception:client.process.kill();client.process.wait()
  config.write_bytes(saved)

def public(v):
 if isinstance(v,dict):return {k:public(x) for k,x in v.items() if k!='data'}
 if isinstance(v,list):return [public(x) for x in v]
 return v
def comparable(r):return [public({k:v for k,v in row.items() if k!='opaque'}) for row in r['rows']]
if __name__=='__main__':
 path=p/'oracle.json';assert not path.exists();report=[]
 for case in e.CASES.values():
  if case['id']=='W12-encoding-lines':continue
  a=run(case,e.BINARY,False,False);off=run(case,p/'slang-server-prototype',False);b=run(case,p/'slang-server-prototype',True)
  result=dict(case=case['id'],native=a,defaultOff=off,defaultOffEqual=a['outcome']==off['outcome']=='success' and comparable(a)==comparable(off),staleEqual=public(a.get('staleResolves'))==public(b.get('staleResolves')),prototype=b,equal=a['outcome']==b['outcome']=='success' and comparable(a)==comparable(b));report.append(result);path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(case['id'],a['outcome'],b['outcome'],result['equal'],b.get('error',''),flush=True)
