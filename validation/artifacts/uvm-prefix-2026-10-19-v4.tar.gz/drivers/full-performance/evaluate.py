"""Ordinary-binary latency evaluation. No status/witness command inside measured sequence."""
from pathlib import Path
import copy,hashlib,json,queue,random,sys,time,traceback
out=Path(__file__).resolve().parent;task=out.parent.parent
sys.path.insert(0,str(out.parent/'real-workloads-2026-10-19'))
from replay import EncodingClient,transform,params,range_change,token_range,position
sys.path.insert(0,str(task/'source/tests/method_scope'))
from protocol import RpcError

BINARY=task/'build/bin/slang-server'
SHA='83ee074544b350b523d4c2d63782d213312a8e46963e097f02e7f36390ffe44b'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
CATALOG=json.loads((out/'workloads.json').read_text());CASES={c['id']:c for c in CATALOG['cases']};PROJECTS={p['id']:p for p in json.loads((out/'projects.json').read_text())}

class EvalClient(EncodingClient):
    def rpc(self,method,params,notifications=()):
        self.serial+=1;rid=self.serial
        start=self.send([*notifications,dict(id=rid,method=method,params=params)])
        message,end=self.wait(lambda m:m.get('id')==rid)
        if 'error' in message:raise RpcError(message)
        return message.get('result'),start,end

def diag_wait(client,uri,version):
    return client.wait(lambda m:m.get('method')=='textDocument/publishDiagnostics' and m['params'].get('uri')==uri and m['params'].get('version')==version)

def configuration(project,cell):
    config=copy.deepcopy(project['config']);config['experimentalMethodScopeOverlay']=cell.get('enabled',False);config['fastCwdSnapshotChecks']=cell.get('fastCwd',False);return config

def steps(case,cycles=None):
    if cycles is None:return case['states']
    original=case['states'][0];edited=case['states'][1]
    return [original]+[dict(edited if n%2 else original,id=f'continuous-{n}') for n in range(1,cycles+1)]

def run(cell,binary=BINARY,extra_env=None,status=True,observer=None,cycles=None):
    case=CASES[cell['case']];project=PROJECTS[case['project']];root=out/project['root'];config=root/'.slang/server.json';saved=config.read_bytes();config.write_text(json.dumps(configuration(project,cell)))
    encoding=case.get('positionEncoding','utf-16');uri=(root/case['target']).as_uri();original=(root/case['target']).read_bytes().decode();sequence=steps(case,cycles);previous=original;client=None;rows=[];start=time.perf_counter_ns();scope=dict(case=cell['case'],method=cell['method'],enabled=cell.get('enabled',False),fastCwd=cell.get('fastCwd',False),diagnostics=cell.get('diagnostics','drained'));outcome='success'
    try:
        client=EvalClient(binary,root,encoding=encoding,extra_env=extra_env)
        if observer:observer(client,0)
        for name in case['extraOpen']:
            p=root/name;client.notify('textDocument/didOpen',dict(textDocument=dict(uri=p.as_uri(),version=1,languageId='systemverilog',text=p.read_bytes().decode())))
        sequence_start=time.perf_counter_ns()
        for i,s in enumerate(sequence):
            text=transform(original,s['operations']);version=i+1
            notifications=[dict(method='textDocument/didOpen',params=dict(textDocument=dict(uri=uri,version=1,languageId='systemverilog',text=text)))] if i==0 else [range_change(uri,version,previous,text,encoding)]
            query=params(uri,text,s['completion'] if cell['method']=='completion' else s['query'],encoding)
            result,begin,end=client.rpc('textDocument/'+cell['method'],query,notifications)
            primary_ms=(end-begin)/1e6
            assert result,('empty response',s['id'])
            if cell['method']=='definition':
                a,b=token_range(text,s['declaration']);expected=dict(start=position(text,a,encoding),end=position(text,b,encoding))
                assert len(result)==1 and result[0]['targetUri']==uri and result[0]['targetSelectionRange']==expected,('wrong definition',s['id'],result)
            else:assert any(x['label']==s['completion']['token'] for x in result),('missing expected label',s['id'])
            row=dict(step=i,state=s['id'],version=version,primaryMs=primary_ms,primaryBeginNs=begin,primaryEndNs=end,primaryItems=len(result))
            if i==0:row['startupThroughFirstResponseMs']=(end-start)/1e6
            repeated,rb,re=client.rpc('textDocument/'+cell['method'],query)
            assert repeated==result,('same-generation repeated result changed',s['id'])
            row['cachedRepeatMs']=(re-rb)/1e6
            if cell['method']=='completion':
                item=next(x for x in result if x['label']==s['completion']['token'])
                resolved,rs,rr=client.rpc('completionItem/resolve',item)
                assert resolved.get('label')==item['label']
                row['resolveMs']=(rr-rs)/1e6;row['resolvedDocumentationBytes']=len(json.dumps(resolved.get('documentation'),ensure_ascii=False).encode())
            if scope['diagnostics']=='drained' or i==0 or i==len(sequence)-1:
                message,received=diag_wait(client,uri,version);diagnostics=message['params']['diagnostics']
                assert any(d.get('severity')==1 for d in diagnostics)==s['expectError'],('unexpected diagnostics',s['id'],diagnostics)
                row['diagnosticFromEditMs']=(received-begin)/1e6;row['diagnosticCount']=len(diagnostics)
            rows.append(row);previous=text
            if observer:observer(client,i+1)
        end_sequence=time.perf_counter_ns()
        totals=dict(sequenceWithDiagnosticsMs=(end_sequence-sequence_start)/1e6,editResponseSumMs=sum(r['primaryMs'] for r in rows[1:]),allPrimarySumMs=sum(r['primaryMs'] for r in rows),firstEditMs=rows[1]['primaryMs'],recoveryMs=rows[-1]['primaryMs'],cachedRepeatSumMs=sum(r['cachedRepeatMs'] for r in rows),resolveSumMs=sum(r.get('resolveMs',0) for r in rows))
        state=None
        if status:
            value=client.state();assert value.get('parserUnits') is None,'timing binaries must have no parser counter';state={k:value[k] for k in ('active','accepted','decline')}
            assert not state['active'] and state['accepted']==0
        return dict(**scope,outcome=outcome,rows=rows,**totals,status=state,serverPid=client.process.pid)
    except Exception as error:
        outcome='timeout' if isinstance(error,queue.Empty) else 'cancelled' if isinstance(error,RpcError) and error.code==-32800 else 'crash' if isinstance(error,(EOFError,BrokenPipeError)) else 'error'
        return dict(**scope,outcome=outcome,error=repr(error),traceback=traceback.format_exc(),rows=rows,serverReturncode=client.process.poll() if client else None,stderrTail=(root/'server.stderr').read_text(errors='replace')[-8192:] if (root/'server.stderr').exists() else '')
    finally:
        if client:
            try:client.close()
            except Exception:
                if client.process.poll() is None:client.process.kill();client.process.wait()
        config.write_bytes(saved)

def make_plan():
    path=out/'latency-plan.json';assert not path.exists();rng=random.Random(2026101901);schedule=[]
    eligible=[c['id'] for c in CATALOG['cases'] if c['id']!='W12-encoding-lines']
    def blocks(stage,cases,n,fast=False,mode='drained'):
        result=[]
        for case in cases:
            for method in ('completion','definition'):
                for block in range(n//2):
                    order=[False,True,True,False] if rng.randrange(2)==0 else [True,False,False,True]
                    result.append([dict(stage=stage,case=case,method=method,block=block,enabled=False if fast else arm,fastCwd=arm if fast else False,diagnostics=mode) for arm in order])
        rng.shuffle(result)
        return [cell for block in result for cell in block]
    schedule+=blocks('matrix',eligible,100)
    selected=['W01-compare','W07-pss-multidoc','W08-ubus-task','W13-continuous']
    schedule+=blocks('burst',selected,20,mode='burst')
    schedule+=blocks('cwd-ablation',['W01-compare','W03-local-add-remove','W07-pss-multidoc','W08-ubus-task'],20,fast=True)
    plan=dict(schema=1,seed=2026101901,binary=dict(path=str(BINARY),sha256=sha(BINARY)),catalogSha256=sha(out/'workloads.json'),projectsSha256=sha(out/'projects.json'),driverSha256=sha(Path(__file__)),helperSha256={str(p):sha(p) for p in (out.parent/'real-workloads-2026-10-19/replay.py',task/'source/tests/method_scope/protocol.py')},schedule=schedule,scope='All 14 eligible cases n100 per primary/arm; n20 burst and fast-cwd ablations. Per-row primary batched with edit, cached repeat and matching resolve timed separately. Initial and final diagnostics waited; all diagnostics waited in drained mode. No state/witness request within sequence. Cold means fresh process, filesystem cache not flushed.',excluded=[dict(case='W12-encoding-lines',reason='known native UTF-16 correctness failure; retained separately, never counted as a successful timing sample')],cwdAblationContract='Opt-in weaker CWD lifetime contract, fixed process cwd and ancestors; does not justify changing the strict default. No file freshness checks disabled.',outcomePolicy='Keep all failures; never replace failed runs; only successful measurements get latency summaries. Failure denominators reported.')
    path.write_text(json.dumps(plan,indent=2)+'\n');print('Frozen',len(schedule),'fresh-process cells')

def main():
    if sys.argv[1]=='plan':make_plan();return
    if sys.argv[1]=='pilot':
        assert not (out/'pilot.json').exists();rows=[]
        for case in ('W01-compare','W07-pss-multidoc','W08-ubus-task','W14-negotiated-utf8'):
            for method in ('completion','definition'):
                row=run(dict(case=case,method=method,enabled=True,diagnostics='drained'));rows.append(row);print(case,method,row['outcome'],flush=True)
        (out/'pilot.json').write_text(json.dumps(rows,indent=2)+'\n');return
    plan=json.loads((out/'latency-plan.json').read_text());assert sha(BINARY)==plan['binary']['sha256']==SHA;assert sha(Path(__file__))==plan['driverSha256'];assert sha(out/'workloads.json')==plan['catalogSha256'];assert sha(out/'projects.json')==plan['projectsSha256']
    for name,h in plan['helperSha256'].items():assert sha(Path(name))==h
    for project in PROJECTS.values():
        for name,h in project['files'].items():assert sha(out/project['root']/name)==h
    output=out/'latency-results.jsonl';assert not output.exists()
    with output.open('w') as f:
        for i,cell in enumerate(plan['schedule']):
            result=run(cell);result.update(cell);result['index']=i
            f.write(json.dumps(result,separators=(',',':'))+'\n');f.flush()
            if (i+1)%40==0:print(i+1,'/',len(plan['schedule']),cell['stage'],result['outcome'],flush=True)
    print('Completed all predeclared cells',flush=True)
if __name__=='__main__':main()
