"""Separate ordinary-binary RSS sampling; never mixed into latency samples."""
import ctypes as c,errno,json,os,resource,sys,threading,time
from pathlib import Path
import evaluate as e
lib=c.CDLL('/usr/lib/libproc.dylib',use_errno=True)
class Task(c.Structure):
 _fields_=[(n,c.c_uint64) for n in ('virtual','resident','user','system','threads_user','threads_system')]+[(f'i{i}',c.c_int32) for i in range(12)]
assert c.sizeof(Task)==96
lib.proc_pidinfo.argtypes=[c.c_int,c.c_int,c.c_uint64,c.c_void_p,c.c_int];lib.proc_listchildpids.argtypes=[c.c_int,c.c_void_p,c.c_int]
def children(pid):
 a=(c.c_int*128)();n=lib.proc_listchildpids(pid,a,c.sizeof(a));return list(a)[:max(0,min(n,128))]
def rss(pid):
 t=Task();n=lib.proc_pidinfo(pid,4,0,c.byref(t),96);return t.resident if n==96 else None
assert rss(os.getpid())>0
class Sampler:
 def __init__(self):self.stop=threading.Event();self.samples=[];self.marks=[];self.started=time.monotonic();self.limit=False
 def collect(self):
  pids=children(os.getpid());roots=list(pids)
  for pid in pids:
   for child in children(pid):
    if child not in pids:pids.append(child)
  values={str(p):rss(p) for p in pids};total=sum(v for v in values.values() if v is not None)
  row=dict(seconds=time.monotonic()-self.started,pids=values,roots=roots,familyRss=total,clientRss=rss(os.getpid()));self.samples.append(row)
  if total>3*1024**3 or row['seconds']>300:self.limit=True
 def loop(self):
  while not self.stop.is_set():self.collect();self.stop.wait(.02)
 def observe(self,client,step):
  if step in (0,1,2,11,51,101,201,501):self.marks.append(dict(step=step,serverPid=client.process.pid,seconds=time.monotonic()-self.started,rss=rss(client.process.pid)))
  if self.limit:raise RuntimeError('predeclared memory/time budget exceeded')
def run(cell,cycles=None):
 s=Sampler();thread=threading.Thread(target=s.loop);before=resource.getrusage(resource.RUSAGE_CHILDREN);thread.start()
 try:r=e.run(cell,status=False,observer=s.observe,cycles=cycles)
 finally:s.stop.set();thread.join()
 after=resource.getrusage(resource.RUSAGE_CHILDREN);r['memory']=dict(intervalMs=20,coverage='process family including diagnostic workers; simultaneous RSS sums shared pages; sampled peaks may miss true peaks',peakFamilyRss=max(x['familyRss'] for x in s.samples),peakClientRss=max(x['clientRss'] or 0 for x in s.samples),childUserSeconds=after.ru_utime-before.ru_utime,childSystemSeconds=after.ru_stime-before.ru_stime,marks=s.marks,samples=s.samples,cycles=cycles)
 if s.limit:r['outcome']='budget-exceeded'
 assert any(x['familyRss']>0 for x in s.samples)
 return r
if __name__=='__main__':
 path=e.out/'memory-results.jsonl';assert not path.exists()
 with path.open('w') as f:
  for rep in range(3):
   for case in e.CASES:
    if case=='W12-encoding-lines':continue
    for method in ('completion','definition'):
     for enabled in ((False,True) if rep%2==0 else (True,False)):
      r=run(dict(case=case,method=method,enabled=enabled,diagnostics='drained'));r.update(stage='memory-baseline',rep=rep);f.write(json.dumps(r)+'\n');f.flush();print(rep,case,method,enabled,r['outcome'],flush=True)
  for case in ('W13-continuous','W07-pss-multidoc','W08-ubus-task'):
   for enabled in (False,True):
    r=run(dict(case=case,method='definition',enabled=enabled,diagnostics='drained'),cycles=500);r.update(stage='memory-long-session');f.write(json.dumps(r)+'\n');f.flush();print('long',case,enabled,r['outcome'],flush=True)
