def run(cell,binary=BINARY,extra_env=None,status=True,observer=None,cycles=None):
    case=CASES[cell['case']];project=PROJECTS[case['project']];root=out/project['root'];config=root/'.slang/server.json';saved=config.read_bytes();config.write_text(json.dumps(configuration(project,cell)))
    encoding=case.get('positionEncoding','utf-16');uri=(root/case['target']).as_uri();original=(root/case['target']).read_bytes().decode();sequence=steps(case,cycles);previous=original;client=None;rows=[];start=time.perf_counter_ns();scope=dict(case=cell['case'],method=cell['method'],enabled=cell.get('enabled',False),fastCwd=cell.get('fastCwd',False),diagnostics=cell.get('diagnostics','drained'));outcome='success'
    try:
        client=EvalClient(binary,root,encoding=encoding,extra_env=extra_env)
        if observer:observer(client,0)
        for name in case['extraOpen']:
            p=root/name;client.notify('textDocument/didOpen',dict(textDocument=dict(uri=p.as_uri(),version=1,languageId='systemverilog',text=p.read_bytes().decode())))
        sequence_start=time.perf_counter_ns()
        for i,s in enumerate(sequence):
            text=transform(original,s['operations']);version=i+1
            notifications=[dict(method='textDocument/didOpen',params=dict(textDocument=dict(uri=uri,version=1,languageId='systemverilog',text=text)))] if i==0 else [range_change(uri,version,previous,text,encoding)]
            query=params(uri,text,s['completion'] if cell['method']=='completion' else s['query'],encoding)
            result,begin,end=client.rpc('textDocument/'+cell['method'],query,notifications)
            primary_ms=(end-begin)/1e6
            assert result,('empty response',s['id'])
            if cell['method']=='definition':
                a,b=token_range(text,s['declaration']);expected=dict(start=position(text,a,encoding),end=position(text,b,encoding))
                assert len(result)==1 and result[0]['targetUri']==uri and result[0]['targetSelectionRange']==expected,('wrong definition',s['id'],result)
            else:assert any(x['label']==s['completion']['token'] for x in result),('missing expected label',s['id'])
            row=dict(step=i,state=s['id'],version=version,primaryMs=primary_ms,primaryBeginNs=begin,primaryEndNs=end,primaryItems=len(result))
            if i==0:row['startupThroughFirstResponseMs']=(end-start)/1e6
            repeated,rb,re=client.rpc('textDocument/'+cell['method'],query)
            assert repeated==result,('same-generation repeated result changed',s['id'])
            row['cachedRepeatMs']=(re-rb)/1e6
            if cell['method']=='completion':
                item=next(x for x in result if x['label']==s['completion']['token'])
                payload=item.get('data');row['completionEpoch']=payload.get('contextEpoch') if isinstance(payload,dict) else None
                resolved,rs,rr=client.rpc('completionItem/resolve',item)
                assert resolved.get('label')==item['label']
                row['resolveMs']=(rr-rs)/1e6;row['resolvedDocumentationBytes']=len(json.dumps(resolved.get('documentation'),ensure_ascii=False).encode())
            if scope['diagnostics']=='drained' or i==0 or i==len(sequence)-1:
                message,received=diag_wait(client,uri,version);diagnostics=message['params']['diagnostics']
                assert any(d.get('severity')==1 for d in diagnostics)==s['expectError'],('unexpected diagnostics',s['id'],diagnostics)
                row['diagnosticFromEditMs']=(received-begin)/1e6;row['diagnosticCount']=len(diagnostics)
            rows.append(row);previous=text
            if observer:observer(client,i+1)
        end_sequence=time.perf_counter_ns()
        totals=dict(sequenceWithDiagnosticsMs=(end_sequence-sequence_start)/1e6,editResponseSumMs=sum(r['primaryMs'] for r in rows[1:]),allPrimarySumMs=sum(r['primaryMs'] for r in rows),firstEditMs=rows[1]['primaryMs'],recoveryMs=rows[-1]['primaryMs'],cachedRepeatSumMs=sum(r['cachedRepeatMs'] for r in rows),resolveSumMs=sum(r.get('resolveMs',0) for r in rows))
        state=None
        if status:
            value=client.state();assert value.get('parserUnits') is None,'timing binaries must have no parser counter';state={k:value[k] for k in ('active','accepted','decline')}
            assert not state['active'] and state['accepted']==0
        return dict(**scope,outcome=outcome,rows=rows,**totals,status=state,serverPid=client.process.pid)
    except Exception as error:
        outcome='timeout' if isinstance(error,queue.Empty) else 'cancelled' if isinstance(error,RpcError) and error.code==-32800 else 'crash' if isinstance(error,(EOFError,BrokenPipeError)) else 'error'
        return dict(**scope,outcome=outcome,error=repr(error),traceback=traceback.format_exc(),rows=rows,serverReturncode=client.process.poll() if client else None,stderrTail=(root/'server.stderr').read_text(errors='replace')[-8192:] if (root/'server.stderr').exists() else '')
    finally:
        if client:
            try:client.close()
            except Exception:
                if client.process.poll() is None:client.process.kill();client.process.wait()
        config.write_bytes(saved)
